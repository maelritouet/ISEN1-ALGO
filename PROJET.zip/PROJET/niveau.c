/* ============================================================
 *  niveau.c — Module niveau & caméra
 *
 *  Axe Y vers le HAUT (convention OpenGL/Gfxlib).
 *
 *  == SYSTÈME BLUEPRINT ==
 *  Chaque niveau est défini par un tableau de chaînes de 15×56
 *  caractères. Le parseur chargerNiveauDepuisBlueprint() lit ce
 *  tableau et place automatiquement plateformes, ennemis, pièces.
 *
 *  Légende des caractères :
 *    .  =  vide (air)
 *    S  =  spawn du joueur
 *    G  =  sortie / zone de victoire
 *    P  =  pièce d'or
 *
 *  --- BLOCS & TEXTURES ---
 *    X  =  lave (zone mortelle)
 *    #  =  plateforme solide dynamique (bords automatiques, herbe + terre)
 *    D  =  roche (rock.bmp)
 *    B  =  briques bleues (bluebricks.bmp)
 *    d  =  terre simple (dirt.bmp)
 *    g  =  terre + herbe (grassdirt.bmp)
 *    v  =  gravier (gravel.bmp)
 *    I  =  glace (ice.bmp)
 *    p  =  planches (planks.bmp)
 *    1  =  donjon violet 1 (purple_dongeon_tile_01.bmp)
 *    2  =  donjon violet 2 (purple_dongeon_tile_02.bmp)
 *    R  =  briques rouges (redbricks.bmp)
 *    s  =  sable (sand.bmp)
 *    W  =  neige (snow.bmp)
 *    T  =  pierre (stone.bmp)
 *    w  =  bois (wood.bmp)
 *
 *  --- ENNEMIS (système modulaire) ---
 *  Chaque type d'ennemi a son propre caractère ASCII :
 *    E  =  Chevalier Gobelin (TYPE_CHEVALIER_GOBELIN)
 *
 *  Pour ajouter un nouveau type d'ennemi :
 *    1. Définir TYPE_XXX dans jeu.h
 *    2. Choisir un caractère ASCII (ex: 'F', 'K', 'O'...)
 *    3. L'ajouter dans estCaractereEnnemi() et creerEnnemiDepuisType()
 *    4. Charger ses sprites dans rendu.c
 *    5. Le placer dans les blueprints de niveaux
 *
 *  Correspondance tile -> pixel (TILE_SIZE = 32) :
 *    colonne c, rangée r  →  x = c*32,  y = (BLUEPRINT_ROWS-1-r)*32
 *    (rangée 0 = haut de l'écran, rangée 14 = bas)
 *
 *  Pour ajouter un niveau :
 *    1. Déclarer static const char *blueprint_nX[BLUEPRINT_ROWS]
 *    2. Ajouter un case X dans initialiserNiveau()
 * ============================================================ */

#include <string.h>
#include <math.h>
#include "niveau.h"
#include "jeu.h"

/* ------------------------------------------------------------
 *  BLUEPRINT — Niveau 1 : Plaines médiévales
 *
 *  Structure (gauche → droite) :
 *   Zone A (cols  0-11) : départ, sol plein, plateformes basses
 *   Zone B (cols 12-15) : PRÉCIPICE 1 (fond mortel)
 *   Zone C (cols 16-27) : sol intermédiaire, plateformes hautes
 *   Zone D (cols 28-31) : PRÉCIPICE 2
 *   Zone E (cols 32-55) : section finale, sortie en haut à droite
 *
 *  Chaque rangée fait exactement BLUEPRINT_COLS (56) caractères.
 * ------------------------------------------------------------ */
static const char *blueprint_n2[BLUEPRINT_ROWS] = {
/*col:  00000000001111111111222222222233333333334444444444555555 */
/*col:  01234567890123456789012345678901234567890123456789012345 */
/*r00*/ "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB",
/*r01*/ "B......................................................B",
/*r02*/ "B...................PPPP...............................B",
/*r03*/ "B.......RRRR.......RRRRRR..........................R...B",
/*r04*/ "B...E.................................P................B",
/*r05*/ "B.RRRR...............................RRRR.....P........B",
/*r06*/ "B............RR...........E.E...............RRR....G...B",
/*r07*/ "B........................RRRRR....................11111B",
/*r08*/ "B..........RR.....RRRR.................................B",
/*r09*/ "BS.....E........................E......................B",
/*r10*/ "111111111111......11111111111111111........1111111111111",
/*r11*/ "222222222222XXXXXX22222222222222222XXXXXXXX2222222222222",
/*r12*/ "222222222222XXXXXX22222222222222222XXXXXXXX2222222222222",
/*r13*/ "222222222222XXXXXX22222222222222222XXXXXXXX2222222222222",
/*r14*/ "222222222222XXXXXX22222222222222222XXXXXXXX2222222222222",
};

static const char *blueprint_n1[BLUEPRINT_ROWS] = {
/*col:  00000000001111111111222222222233333333334444444444555555 */
/*col:  01234567890123456789012345678901234567890123456789012345 */
/*r00*/ "........................................................",
/*r01*/ "........................................................",
/*r02*/ "........................................................",
/*r03*/ "....PP......PP......................................PP..",
/*r04*/ "...###.....####.....................................####",
/*r05*/ ".........PP.........####.....PP.PP.PP.....PP.PP.....",
/*r06*/ ".......#####..................####.##......####.##....",
/*r07*/ "..PP.......................##............PP............P.",
/*r08*/ "..####..............####..............####...........###",
/*r09*/ "S.........M.........M..................M.......M....G...",
/*r10*/ "DDDDDDDDDDDD.....DDDDDDDDDDD.....DDDDDDDDDDD.....DDDDDDDD",
/*r11*/ "DDDDDDDDDDDD.....DDDDDDDDDDDXXXXXDDDDDDDDDDDXXXXXXDDDDDDDD",
/*r12*/ "DDDDDDDDDDDD.....DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD",
/*r13*/ "DDDDDDDDDDDD.....DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD",
/*r14*/ "DDDDDDDDDDDD.....DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD",
};
/* ------------------------------------------------------------
 *  estCaractereEnnemi — Vérifie si un caractère du blueprint
 *  représente un ennemi (tous types confondus).
 *
 *  Pour ajouter un type : ajouter son caractère ici.
 * ------------------------------------------------------------ */
static int estCaractereEnnemi(char ch)
{
    return (ch == 'E' || ch == 'M');  /* E = Chevalier Gobelin, M = Slime */
    /* Exemples futurs :
     * || ch == 'F'    // Ennemi volant
     * || ch == 'K'    // Squelette
     * || ch == 'O'    // Ogre
     */
}

/* ------------------------------------------------------------
 *  creerEnnemiDepuisType — Initialise un ennemi selon le
 *  caractère ASCII du blueprint.
 *
 *  Chaque type peut avoir sa propre taille, vitesse, et comportement.
 *  Pour ajouter un type : ajouter un case dans le switch.
 * ------------------------------------------------------------ */
static void creerEnnemiDepuisType(JeuEtat *jeu, char ch, float x, float y)
{
    if (jeu->nb_ennemis >= NB_ENNEMIS) return;

    /* Vitesses de patrouille cycliques pour varier les ennemis */
    static const float vitesses[] = { 1.5f, 2.0f, 2.5f, 2.0f, 1.8f, 2.3f };
    static const int nb_vitesses  = 6;

    float vb  = vitesses[jeu->nb_ennemis % nb_vitesses];
    int   dir = (jeu->nb_ennemis % 2 == 0) ? DIR_DROITE : DIR_GAUCHE;

    Ennemi *e = &jeu->ennemis[jeu->nb_ennemis];
    e->x           = x;
    e->y           = y;
    e->direction   = dir;
    e->vivant      = 1;
    e->attaque     = 0;
    e->en_charge   = 0;

    switch (ch)
    {
        case 'E': /* Chevalier Gobelin */
            e->type_ennemi = TYPE_CHEVALIER_GOBELIN;
            e->largeur     = 48;
            e->hauteur     = 48;
            e->vx_base     = vb;
            break;

        case 'M': /* Slime */
            e->type_ennemi = TYPE_SLIME;
            e->largeur     = 40; // The slime might be smaller, let's use 40x40.
            e->hauteur     = 40;
            e->vx_base     = vb * 0.75f; // Slime is slightly slower
            break;

        /* Pour ajouter un nouveau type :
         * case 'F':
         *     e->type_ennemi = TYPE_ENNEMI_VOLANT;
         *     e->largeur     = 32;
         *     e->hauteur     = 32;
         *     e->vx_base     = 3.0f;
         *     break;
         */

        default: /* Fallback : chevalier gobelin */
            e->type_ennemi = TYPE_CHEVALIER_GOBELIN;
            e->largeur     = 40;
            e->hauteur     = 40;
            e->vx_base     = vb;
            break;
    }

    e->vx = e->vx_base * (dir == DIR_DROITE ? 1.0f : -1.0f);
    jeu->nb_ennemis++;
}

/* ------------------------------------------------------------
 *  chargerNiveauDepuisBlueprint — Parseur générique
 *
 *  Parcourt le blueprint caractère par caractère :
 *  - Les runs de blocs identiques consécutifs sur une même rangée
 *    sont fusionnés en une seule Plateforme (économie de slots).
 *  - Le caractère d'origine est stocké dans p->type.
 *  - Les caractères d'ennemis créent un ennemi du type correspondant.
 *  - 'P' crée une pièce centrée dans le tile.
 *  - 'S' fixe la position de spawn du joueur.
 *  - 'G' fixe la zone de sortie (victoire).
 * ------------------------------------------------------------ */
static void chargerNiveauDepuisBlueprint(JeuEtat *jeu,
                                         const char **bp,
                                         int rows, int cols)
{
    int r, c;
    (void)cols; /* On utilise strlen pour supporter des largeurs variables */

    for (r = 0; r < rows; r++)
    {
        int largeur_ligne = (int)strlen(bp[r]); /* Largeur réelle de cette ligne */
        float y_tile = (float)(rows - 1 - r) * TILE_SIZE;

        c = 0;
        while (c < largeur_ligne)
        {
            char ch = bp[r][c];

            /* --- Plateforme ou zone mortelle : fusion des runs --- */
            /* Tout ce qui n'est pas air, ennemi, pièce, spawn, sortie est un bloc solide */
            if (ch != '.' && !estCaractereEnnemi(ch) && ch != 'P' && ch != 'S' && ch != 'G')
            {
                int c_start  = c;
                int mortelle = (ch == 'X') ? 1 : 0;
                while (c < largeur_ligne && bp[r][c] == ch)
                    c++;
                int largeur_tiles = c - c_start;

                if (jeu->nb_plateformes < NB_PLATEFORMES)
                {
                    Plateforme *p = &jeu->plateformes[jeu->nb_plateformes];
                    p->x       = (float)c_start * TILE_SIZE;
                    p->y       = y_tile;
                    p->largeur = (float)largeur_tiles * TILE_SIZE;
                    p->hauteur = (float)TILE_SIZE;
                    p->mortelle = mortelle;
                    p->type    = ch;
                    jeu->nb_plateformes++;
                }
                continue; /* c déjà avancé par le while interne */
            }

            /* --- Ennemi (tous types) --- */
            if (estCaractereEnnemi(ch))
            {
                creerEnnemiDepuisType(jeu, ch,
                                      (float)c * TILE_SIZE, y_tile);
            }

            /* --- Pièce --- */
            else if (ch == 'P' && jeu->nb_objets < NB_PIECES)
            {
                Objet *o = &jeu->objets[jeu->nb_objets];
                o->x        = (float)c * TILE_SIZE + (TILE_SIZE - 20) / 2.0f;
                o->y        = y_tile + TILE_SIZE * 0.3f;
                o->collectee = 0;
                o->type     = 0;
                o->largeur  = 20;
                o->hauteur  = 20;
                jeu->nb_objets++;
            }

            /* --- Spawn joueur --- */
            else if (ch == 'S')
            {
                jeu->joueur.x = (float)c * TILE_SIZE;
                jeu->joueur.y = y_tile;
                /* Sauvegarder le spawn pour les respawns après mort */
                jeu->spawn_x  = jeu->joueur.x;
                jeu->spawn_y  = jeu->joueur.y;
            }

            /* --- Zone de sortie --- */
            else if (ch == 'G')
            {
                jeu->sortie_x = (float)c * TILE_SIZE;
                jeu->sortie_y = y_tile;
            }

            c++;
        }
    }
}

/* ============================================================
 *  initialiserNiveau — Point d'entrée du module
 * ============================================================ */
void initialiserNiveau(JeuEtat *jeu)
{
    jeu->nb_plateformes = 0;
    jeu->nb_ennemis     = 0;
    jeu->nb_objets      = 0;
    jeu->camera_x       = 0.0f;
    jeu->sortie_x       = 0.0f;
    jeu->sortie_y       = 0.0f;
    jeu->spawn_x        = 0.0f;
    jeu->spawn_y        = 0.0f;

    switch (jeu->niveau_actuel)
    {
        case 1:
            chargerNiveauDepuisBlueprint(jeu,
                blueprint_n1, BLUEPRINT_ROWS, BLUEPRINT_COLS);
            break;

        case 2:
            chargerNiveauDepuisBlueprint(jeu,
                blueprint_n2, BLUEPRINT_ROWS, BLUEPRINT_COLS);
            break;

        default:
            chargerNiveauDepuisBlueprint(jeu,
                blueprint_n1, BLUEPRINT_ROWS, BLUEPRINT_COLS);
            break;
    }
}

/* ============================================================
 *  mettreAJourCamera — Caméra douce qui suit le joueur
 *
 *  Interpolation linéaire (lerp, facteur 0.12) :
 *  on déplace la caméra de 12% de l'écart restant → mouvement
 *  fluide qui se ralentit naturellement en approchant la cible.
 * ============================================================ */
void mettreAJourCamera(JeuEtat *jeu)
{
    Joueur *j = &jeu->joueur;

    float cible = j->x - LARGEUR_FENETRE / 2.0f + j->largeur / 2.0f;
    if (cible < 0.0f) cible = 0.0f;

    jeu->camera_x += (cible - jeu->camera_x) * 0.12f;

    if (jeu->camera_x < 0.0f) jeu->camera_x = 0.0f;
}

// ------------------------------------------------------------
//  getPlatformHitbox — Calcule la hitbox réelle d'une plateforme
//
//  Les sprites de plateformes ('#') ont des marges transparentes.
//  Cette fonction renvoie une boîte de collision plus petite et
//  centrée, correspondant à la partie visuellement "solide".
// ------------------------------------------------------------
void getPlatformHitbox(Plateforme *p, float *px, float *py, float *pw, float *ph)
{
    *px = p->x;
    *py = p->y;
    *pw = p->largeur;
    *ph = p->hauteur;

    if (p->type == '#')
    {
        /* Marge gauche/droite pour platform1 et platform3 */
        *px += 14.0f;
        *pw -= 28.0f;

        /* La partie solide fait ~36px de haut, centrée dans le tile de 64px.
         * (64 - 36) / 2 = 14px de marge en bas et en haut. */
        *py += 14.0f;
        *ph  = 36.0f;
    }
}