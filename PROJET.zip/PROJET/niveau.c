/* ============================================================
 *  niveau.c — Module niveau & caméra
 *
 *  Axe Y vers le HAUT (convention OpenGL/Gfxlib)
 *  Sol à y=50, hauteur=50  →  dessus du sol à y=100
 *  Joueur spawn à x=100, y=100 (posé sur le sol)
 *
 *  Physique du saut (FORCE_SAUT=14, GRAVITE=0.5) :
 *    Hauteur max = v²/(2g) = 14²/1 = 196 px au-dessus du pied.
 *    Depuis y=100 (sol), le pied monte jusqu'à y≈296.
 *    On garde une marge de ~20px → échelons max ≈ +160px entre
 *    le dessus de la plateforme de départ et le dessus de la cible.
 * ============================================================ */

#include <string.h>
#include "niveau.h"
#include "jeu.h"

/* ------------------------------------------------------------
 *  Macro utilitaire : ajoute une plateforme dans le tableau
 *  jeu->plateformes[] et incrémente jeu->nb_plateformes.
 *  px, py : coin bas-gauche
 *  pw, ph : largeur, hauteur
 *  mort   : 1 si zone mortelle, 0 sinon
 * ------------------------------------------------------------ */
#define AJOUT_PLAT(px, py, pw, ph, mort)                        \
    do {                                                        \
        int _i = jeu->nb_plateformes;                          \
        if (_i < NB_PLATEFORMES) {                             \
            jeu->plateformes[_i].x       = (float)(px);       \
            jeu->plateformes[_i].y       = (float)(py);       \
            jeu->plateformes[_i].largeur = (float)(pw);       \
            jeu->plateformes[_i].hauteur = (float)(ph);       \
            jeu->plateformes[_i].mortelle = (mort);           \
            jeu->nb_plateformes++;                             \
        }                                                       \
    } while(0)

/* ============================================================
 *  chargerNiveau1 — Niveau médiéval ~2800 px de large
 *
 *  Structure du parcours (gauche → droite) :
 *
 *   [ZONE A] x=0..600   : début, sol plein, plateformes basses
 *   [ZONE B] x=600..900 : PRECIPICE 1 (mortelle au fond)
 *   [ZONE C] x=900..1500: sol intermédiaire, plateformes moyennes
 *   [ZONE D] x=1500..1800: PRECIPICE 2 (mortelle au fond)
 *   [ZONE E] x=1800..2800: section finale, plateformes hautes
 *
 *  Toutes les plateformes ont été vérifiées atteignables :
 *    - saut depuis y=100 (sol) → pied joueur ≤ 270 (marge 26px)
 *    - enchaînements vérifié plateau par plateau
 * ============================================================ */
static void chargerNiveau1(JeuEtat *jeu)
{
    jeu->nb_plateformes = 0;

    /* --------------------------------------------------------
     *  ZONE A — Début (x=0..600)
     *  Sol continu, premières plateformes d'apprentissage
     * -------------------------------------------------------- */

    /* Sol zone A */
    AJOUT_PLAT(  0,  50, 600, 50, 0);   /* dessus à y=100 */

    /* Plateforme 1 : basse, facile — y=150 (dessus=170), saut de 70px */
    AJOUT_PLAT(200, 150, 180, 20, 0);   /* dessus à y=170 */

    /* Plateforme 2 : un peu plus haute — dessus=220, +50px vs plat1 */
    AJOUT_PLAT(420, 200, 150, 20, 0);   /* dessus à y=220 */

    /* --------------------------------------------------------
     *  ZONE B — PRECIPICE 1 (x=600..900)
     *  Trou de 300px. Fond mortel à y=0..50.
     *  Deux plateformes aériennes pour franchir le gouffre.
     * -------------------------------------------------------- */

    /* Zone mortelle au fond du précipice 1 */
    AJOUT_PLAT(600,   0, 300, 50, 1);   /* fond mortel */

    /* Plateforme aérienne A — au-dessus du gouffre */
    /* Depuis plat2 dessus=220, saut de 50px → dessus=270, OK */
    AJOUT_PLAT(620, 250, 120, 20, 0);   /* dessus à y=270 */

    /* Plateforme aérienne B */
    /* Depuis plat-A dessus=270, saut horizontal, même hauteur */
    AJOUT_PLAT(790, 230, 110, 20, 0);   /* dessus à y=250 */

    /* --------------------------------------------------------
     *  ZONE C — Section intermédiaire (x=900..1500)
     *  Sol continu, montée progressive
     * -------------------------------------------------------- */

    /* Sol zone C — légèrement surélevé pour varier */
    AJOUT_PLAT(900,  50, 600, 50, 0);   /* dessus à y=100 */

    /* Plateforme 5 — basse */
    AJOUT_PLAT(950, 150, 160, 20, 0);   /* dessus à y=170 */

    /* Plateforme 6 */
    AJOUT_PLAT(1160, 200, 140, 20, 0);  /* dessus à y=220 */

    /* Plateforme 7 — escalier montant */
    AJOUT_PLAT(1350, 250, 130, 20, 0);  /* dessus à y=270 */

    /* Plateforme 8 — plus haute, encore atteignable */
    /* Depuis plat7 dessus=270, on saute : 270 + 196 = 466 max pied */
    /* On met dessus=330 → y=310, confortable */
    AJOUT_PLAT(1240, 310, 160, 20, 0);  /* dessus à y=330 */

    /* Plateforme 9 — redescend un peu pour rythmer */
    AJOUT_PLAT(1060, 260, 140, 20, 0);  /* dessus à y=280 */

    /* --------------------------------------------------------
     *  ZONE D — PRECIPICE 2 (x=1500..1800)
     *  Trou de 300px, plus profond (fond à y=-50..50 mortel).
     *  Deux plateformes flottantes + une descente en escalier.
     * -------------------------------------------------------- */

    /* Zone mortelle au fond du précipice 2 */
    AJOUT_PLAT(1500,   0, 300, 50, 1);  /* fond mortel */

    /* Plateforme flottante C — depuis sol zone C dessus=100 */
    /* On fait sauter depuis plat8 dessus=330 → très accessible */
    AJOUT_PLAT(1520, 280, 100, 20, 0);  /* dessus à y=300 */

    /* Plateforme flottante D — même hauteur, saut horizontal */
    AJOUT_PLAT(1670, 260, 110, 20, 0);  /* dessus à y=280 */

    /* --------------------------------------------------------
     *  ZONE E — Section finale (x=1800..2800)
     *  Escalier montant en 3 marches claires, puis grand
     *  sol plat avant le mur du château (zone de sortie).
     *  Pas de plateformes qui se croisent ou se superposent.
     * -------------------------------------------------------- */

    /* Sol de liaison après le précipice 2 */
    AJOUT_PLAT(1800,  50, 150, 50, 0);  /* dessus à y=100 */

    /* Marche 1 — légère montée pour reprendre pied */
    AJOUT_PLAT(2000, 130, 160, 20, 0);  /* dessus à y=150 */

    /* Marche 2 — montée progressive */
    AJOUT_PLAT(2210, 200, 160, 20, 0);  /* dessus à y=220 */

    /* Marche 3 — dernière marche haute avant le palier final */
    /* Depuis marche 2 dessus=220 : max pied = 220+196 = 416 → dessus ≤ 276 ✓ */
    AJOUT_PLAT(2420, 250, 160, 20, 0);  /* dessus à y=270 */

    /* Grand sol plat d'arrivée — espace ouvert pour la zone de sortie */
    /* Accessible depuis marche 3 en redescendant ou via un petit saut */
    AJOUT_PLAT(2600,  50, 300, 50, 0);  /* dessus à y=100, large et dégagé */

    /* Mur du château (décor) — tout à droite, hors de la zone de jeu */
    AJOUT_PLAT(2900,  50,  80, 300, 0); /* mur loin, ne bloque pas la sortie */
}

/* ============================================================
 *  initialiserNiveau — Point d'entrée du module niveau
 *  Appelé depuis initialiserJeu() dans main.c.
 *  Structure switch pour faciliter l'ajout de niveaux futurs.
 * ============================================================ */
void initialiserNiveau(JeuEtat *jeu)
{
    /* Réinitialisation */
    jeu->nb_plateformes = 0;
    jeu->camera_x       = 0.0f;

    switch (jeu->niveau_actuel)
    {
        case 1:
            chargerNiveau1(jeu);
            break;

        /* Niveaux futurs :
         * case 2: chargerNiveau2(jeu); break;
         * case 3: chargerNiveau3(jeu); break;
         */

        default:
            /* Niveau inconnu : on charge quand même le niveau 1 */
            chargerNiveau1(jeu);
            break;
    }
}

/* ============================================================
 *  mettreAJourCamera — Caméra douce qui suit le joueur
 *
 *  Interpolation linéaire (lerp) : on déplace la caméra de
 *  20% de l'écart restant à chaque tick → mouvement fluide
 *  qui se ralentit naturellement quand on approche la cible.
 *
 *  Contrainte : camera_x >= 0 (pas de scroll à gauche du spawn)
 * ============================================================ */
void mettreAJourCamera(JeuEtat *jeu)
{
    Joueur *j = &jeu->joueur;

    /* Cible : centrer le joueur horizontalement dans la fenêtre */
    float cible = j->x - LARGEUR_FENETRE / 2.0f + j->largeur / 2.0f;

    /* Bloque la caméra à x=0 (bord gauche du niveau) */
    if (cible < 0.0f) cible = 0.0f;

    /* Interpolation douce (lerp factor = 0.12) */
    jeu->camera_x += (cible - jeu->camera_x) * 0.12f;

    /* Sécurité : pas de valeur négative */
    if (jeu->camera_x < 0.0f) jeu->camera_x = 0.0f;
}
