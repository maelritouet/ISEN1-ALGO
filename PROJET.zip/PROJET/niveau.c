/* ============================================================
 *  niveau.c — Module niveau & caméra
 *
 *  Axe Y vers le HAUT (convention OpenGL/Gfxlib).
 *
 *  == SYSTÈME BLUEPRINT ==
 *  Chaque niveau est défini par un tableau de chaînes de 15×56
 *  caractères. Le parseur chargerNiveauDepuisBlueprint() lit ce
 *  tableau et place automatiquement plateformes, ennemis, pièces.
 *
 *  Légende des caractères :
 *    .  =  vide (air)
 *    #  =  plateforme solide
 *    X  =  zone mortelle (précipice, piques…)
 *    S  =  spawn du joueur
 *    G  =  sortie / zone de victoire
 *    E  =  ennemi
 *    P  =  pièce d'or
 *
 *  Correspondance tile -> pixel (TILE_SIZE = 50) :
 *    colonne c, rangée r  →  x = c*50,  y = (BLUEPRINT_ROWS-1-r)*50
 *    (rangée 0 = haut de l'écran, rangée 14 = bas)
 *
 *  Pour ajouter un niveau :
 *    1. Déclarer static const char *blueprint_nX[BLUEPRINT_ROWS]
 *    2. Ajouter un case X dans initialiserNiveau()
 * ============================================================ */

#include <string.h>
#include <math.h>
#include "niveau.h"
#include "jeu.h"

/* ------------------------------------------------------------
 *  BLUEPRINT — Niveau 1 : Plaines médiévales
 *
 *  Structure (gauche → droite) :
 *   Zone A (cols  0-11) : départ, sol plein, plateformes basses
 *   Zone B (cols 12-15) : PRÉCIPICE 1 (fond mortel)
 *   Zone C (cols 16-27) : sol intermédiaire, plateformes hautes
 *   Zone D (cols 28-31) : PRÉCIPICE 2
 *   Zone E (cols 32-55) : section finale, sortie en haut à droite
 *
 *  Chaque rangée fait exactement BLUEPRINT_COLS (56) caractères.
 * ------------------------------------------------------------ */
static const char *blueprint_n1[BLUEPRINT_ROWS] = {
/*col:  00000000001111111111222222222233333333334444444444555555 */
/*col:  01234567890123456789012345678901234567890123456789012345 */
/*r00*/ "........................................................",
/*r01*/ "........................................................",
/*r02*/ "........................................................",
/*r03*/ "....PP......PP......................................PP..",
/*r04*/ "...###.....####.....................................####",
/*r05*/ ".........PP.........####.....PP.PP.PP.....PP.PP.....",
/*r06*/ ".......#####..................####.##......####.##....",
/*r07*/ "..PP.......................##............PP............P.",
/*r08*/ "..####..............####..............####...........###",
/*r09*/ "S.........E.........E..................E.......E....G...",
/*r10*/ "############.....###########.....###########.....#####",
/*r11*/ "DDDDDDDDDDDDXXXXXDDDDDDDDDDDXXXXXDDDDDDDDDDDXXXXXXDDDDDDDD",
/*r12*/ "DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD",
/*r13*/ "DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD",
/*r14*/ "DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD",
};

static const char *blueprint_n2[BLUEPRINT_ROWS] = {
/*col:  00000000001111111111222222222233333333334444444444555555 */
/*col:  01234567890123456789012345678901234567890123456789012345 */
/*r00*/ "........................................................",
/*r01*/ "........................................................",
/*r02*/ "........................................................",
/*r03*/ "....PP......PP......................................PP..",
/*r04*/ "...###.....####.....................................####",
/*r05*/ ".........PP.........####.....PP.PP.PP.....PP.PP.....",
/*r06*/ ".......#####..................####.##......####.##....",
/*r07*/ "..PP.......................##............PP............P.",
/*r08*/ "..####..............####..............####...........###",
/*r09*/ "S.........E.........E..................E.......E....G...",
/*r10*/ "############.....###########.....###########.....#####",
/*r11*/ "DDDDDDDDDDDDXXXXX###########XXXXX###########XXXXXX#####",
/*r12*/ "DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD",
/*r13*/ "DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD",
/*r14*/ "DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD",
};
/* ------------------------------------------------------------
 *  chargerNiveauDepuisBlueprint — Parseur générique
 *
 *  Parcourt le blueprint caractère par caractère :
 *  - Les runs de blocs identiques consécutifs sur une même rangée
 *    sont fusionnés en une seule Plateforme (économie de slots).
 *  - Le caractère d'origine est stocké dans p->type.
 *  - 'E' crée un ennemi avec une vitesse légèrement variée.
 *  - 'P' crée une pièce centrée dans le tile.
 *  - 'S' fixe la position de spawn du joueur.
 *  - 'G' fixe la zone de sortie (victoire).
 * ------------------------------------------------------------ */
static void chargerNiveauDepuisBlueprint(JeuEtat *jeu,
                                         const char **bp,
                                         int rows, int cols)
{
    int r, c;
    /* Vitesses de patrouille cycliques pour varier les ennemis */
    float vitesses[] = { 1.5f, 2.0f, 2.5f, 2.0f, 1.8f, 2.3f };
    int nb_vitesses  = 6;

    for (r = 0; r < rows; r++)
    {
        float y_tile = (float)(rows - 1 - r) * TILE_SIZE;

        c = 0;
        while (c < cols)
        {
            char ch = bp[r][c];

            /* --- Plateforme ou zone mortelle : fusion des runs --- */
            /* Tout ce qui n'est pas air, ennemi, pièce, spawn, sortie est un bloc solide */
            if (ch != '.' && ch != 'E' && ch != 'P' && ch != 'S' && ch != 'G')
            {
                int c_start  = c;
                int mortelle = (ch == 'X') ? 1 : 0;
                while (c < cols && bp[r][c] == ch)
                    c++;
                int largeur_tiles = c - c_start;

                if (jeu->nb_plateformes < NB_PLATEFORMES)
                {
                    Plateforme *p = &jeu->plateformes[jeu->nb_plateformes];
                    p->x       = (float)c_start * TILE_SIZE;
                    p->y       = y_tile;
                    p->largeur = (float)largeur_tiles * TILE_SIZE;
                    p->hauteur = (float)TILE_SIZE;
                    p->mortelle = mortelle;
                    p->type    = ch;
                    jeu->nb_plateformes++;
                }
                continue; /* c déjà avancé par le while interne */
            }

            /* --- Ennemi --- */
            if (ch == 'E' && jeu->nb_ennemis < NB_ENNEMIS)
            {
                float vb = vitesses[jeu->nb_ennemis % nb_vitesses];
                int   dir = (jeu->nb_ennemis % 2 == 0) ? DIR_DROITE : DIR_GAUCHE;
                Ennemi *e = &jeu->ennemis[jeu->nb_ennemis];
                e->x         = (float)c * TILE_SIZE;
                e->y         = y_tile;
                e->vx        = vb * (dir == DIR_DROITE ? 1.0f : -1.0f);
                e->vx_base   = vb;
                e->direction = dir;
                e->vivant    = 1;
                e->attaque   = 0;
                e->en_charge = 0;
                e->largeur   = 40;
                e->hauteur   = 40;
                jeu->nb_ennemis++;
            }

            /* --- Pièce --- */
            else if (ch == 'P' && jeu->nb_objets < NB_PIECES)
            {
                Objet *o = &jeu->objets[jeu->nb_objets];
                o->x        = (float)c * TILE_SIZE + (TILE_SIZE - 20) / 2.0f;
                o->y        = y_tile + TILE_SIZE * 0.3f;
                o->collectee = 0;
                o->type     = 0;
                o->largeur  = 20;
                o->hauteur  = 20;
                jeu->nb_objets++;
            }

            /* --- Spawn joueur --- */
            else if (ch == 'S')
            {
                jeu->joueur.x = (float)c * TILE_SIZE;
                jeu->joueur.y = y_tile;
            }

            /* --- Zone de sortie --- */
            else if (ch == 'G')
            {
                jeu->sortie_x = (float)c * TILE_SIZE;
                jeu->sortie_y = y_tile;
            }

            c++;
        }
    }
}

/* ============================================================
 *  initialiserNiveau — Point d'entrée du module
 * ============================================================ */
void initialiserNiveau(JeuEtat *jeu)
{
    jeu->nb_plateformes = 0;
    jeu->nb_ennemis     = 0;
    jeu->nb_objets      = 0;
    jeu->camera_x       = 0.0f;
    jeu->sortie_x       = 0.0f;
    jeu->sortie_y       = 0.0f;

    switch (jeu->niveau_actuel)
    {
        case 1:
            chargerNiveauDepuisBlueprint(jeu,
                blueprint_n1, BLUEPRINT_ROWS, BLUEPRINT_COLS);
            break;

        /* Ajouter ici les niveaux futurs :
         * case 2:
         *     chargerNiveauDepuisBlueprint(jeu,
         *         blueprint_n2, BLUEPRINT_ROWS, BLUEPRINT_COLS);
         *     break;
         */

        default:
            chargerNiveauDepuisBlueprint(jeu,
                blueprint_n1, BLUEPRINT_ROWS, BLUEPRINT_COLS);
            break;
    }
}

/* ============================================================
 *  mettreAJourCamera — Caméra douce qui suit le joueur
 *
 *  Interpolation linéaire (lerp, facteur 0.12) :
 *  on déplace la caméra de 12% de l'écart restant → mouvement
 *  fluide qui se ralentit naturellement en approchant la cible.
 * ============================================================ */
void mettreAJourCamera(JeuEtat *jeu)
{
    Joueur *j = &jeu->joueur;

    float cible = j->x - LARGEUR_FENETRE / 2.0f + j->largeur / 2.0f;
    if (cible < 0.0f) cible = 0.0f;

    jeu->camera_x += (cible - jeu->camera_x) * 0.12f;

    if (jeu->camera_x < 0.0f) jeu->camera_x = 0.0f;
}
