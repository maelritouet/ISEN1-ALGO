/* 
 *  niveau.c - Module niveau & caméra
 *
 *  Axe Y vers le HAUT (convention OpenGL/Gfxlib).
 *
 *  BLUEPRINT 
 *  Chaque niveau est défini par un tableau de chaînes de 15×56
 *  caractères. Le parseur chargerNiveauDepuisBlueprint() lit ce
 *  tableau et place automatiquement plateformes, ennemis, pièces.
 *
 *  LÉGENDE :
 *  S : Spawn du Joueur
 *  G : Sortie (Goal)
 *  P : Pièce
 *  X : Lave
 *
 *  --- Sols pleins 3 parties (horizontaux) ---
 *  = : Grass (3 parts)
 *  _ : Dirt (3 parts)
 *
 *  --- Plateformes 3 parties (hitbox réduite) ---
 *  # : Rock Platform (3 parts)
 *  - : Wood Platform (3 parts)
 *
 *  | : Column (Ceiling, Middle, Floor dessinés automatiquement)
 *
 *  --- Blocs Aléatoires ---
 *  D : Dungeon Tile (Variante choisie selon la coordonnée)
 *
 *  --- Autres éléments ---
 *  I : Ice
 *  R : Rock
 *  r : Small rock
 *  C : Chain
 *  B : Crate
 *  Y : Spike Ceiling
 *  y : Spike Floor
 *  < : Spike Left Wall
 *  > : Spike Right Wall
 *
 *  --- ENNEMIS ---
 *  E : Demon
 *  M : Slime Vert
 *  Z : Slime Rouge
 *  */

#include <stddef.h>
#include <string.h>
#include <math.h>
#include "niveau.h"
#include "jeu.h"
#include "blueprint.h"

static int estCaractereEnnemi(char ch)
{
    return (ch == 'E' || ch == 'M' || ch == 'Z');  
}


static void creerEnnemiDepuisType(JeuEtat *jeu, char ch, float x, float y)
{
    if (jeu->nb_ennemis >= NB_ENNEMIS) return;

    /* différentes vitesses de patrouille pour varier les selon ennemis */
    static const float vitesses[] = { 1.5f, 2.0f, 2.5f, 2.0f, 1.8f, 2.3f };
    static const int nb_vitesses  = 6;

    float vb  = vitesses[jeu->nb_ennemis % nb_vitesses];
    int   dir = (jeu->nb_ennemis % 2 == 0) ? DIR_DROITE : DIR_GAUCHE;

    Ennemi *e = &jeu->ennemis[jeu->nb_ennemis];
    e->x           = x;
    e->y           = y;
    e->direction   = dir;
    e->vivant      = 1;
    e->attaque     = 0;
    e->en_charge   = 0;

    switch (ch)
    {
        case 'E':
            e->type_ennemi = TYPE_DEMON;
            e->largeur     = 64;
            e->hauteur     = 64;
            e->vx_base     = vb;
            break;

        case 'M': 
            e->type_ennemi = TYPE_SLIME;
            e->largeur     = 40; 
            e->hauteur     = 40;
            e->vx_base     = vb * 0.75f; 
            break;

        case 'Z': 
            e->type_ennemi = TYPE_RED_SLIME;
            e->largeur     = 40;
            e->hauteur     = 40;
            e->vx_base     = vb * 1.5f; 
            break;

    
    }

    e->vx = e->vx_base * (dir == DIR_DROITE ? 1.0f : -1.0f);
    jeu->nb_ennemis++;
}

static void chargerNiveauDepuisBlueprint(JeuEtat *jeu,
                                         const char **bp,
                                         int rows, int cols)
{
    int r, c;
    (void)cols; 

    float max_largeur = 0.0f;

    for (r = 0; r < rows; r++)
    {
        int largeur_ligne = (int)strlen(bp[r]); /* Largeur réelle de cette ligne */
        float y_tile = (float)(rows - 1 - r) * TILE_SIZE;

        if (largeur_ligne * TILE_SIZE > max_largeur) max_largeur = largeur_ligne * TILE_SIZE;

        c = 0;
        while (c < largeur_ligne)
        {
            char ch = bp[r][c];

            // Colonne verticale | 
            if (ch == '|')
            {
                // Si on a déjà un '|' juste au-dessus dans le blueprint, cette case a déjà été 
                // fusionnée par la boucle d'au-dessus lors d'un passage précédent. On l'ignore. 
                if (r > 0 && bp[r-1][c] == '|') {
                    c++;
                    continue;
                }

                // sommet d'une colonne -> on cherche sa longueur vers le bas. 
                int r_end = r;
                while (r_end < rows && bp[r_end][c] == '|') {
                    r_end++;
                }
                int hauteur_tiles = r_end - r;

                if (jeu->nb_plateformes < NB_PLATEFORMES)
                {
                    Plateforme *p = &jeu->plateformes[jeu->nb_plateformes];
                    p->x       = (float)c * TILE_SIZE;
                    /* La coordonnée Y est celle du bloc le plus bas (r_end - 1) */
                    p->y       = (float)(rows - 1 - (r_end - 1)) * TILE_SIZE;
                    p->largeur = (float)TILE_SIZE;
                    p->hauteur = (float)hauteur_tiles * TILE_SIZE;
                    p->mortelle = 0;
                    p->type    = '|';
                    jeu->nb_plateformes++;
                }
                c++;
                continue;
            }

            // Plateforme horizontale ou zone mortelle : fusion des runs 
            if (ch != '.' && !estCaractereEnnemi(ch) && ch != 'P' && ch != 'S' && ch != 'G')
            {
                int c_start  = c;
                int mortelle = (ch == 'X' || ch == 'y' || ch == 'Y' || ch == '<' || ch == '>') ? 1 : 0;
                while (c < largeur_ligne && bp[r][c] == ch)
                    c++;
                int largeur_tiles = c - c_start;

                if (jeu->nb_plateformes < NB_PLATEFORMES)
                {
                    Plateforme *p = &jeu->plateformes[jeu->nb_plateformes];
                    p->x       = (float)c_start * TILE_SIZE;
                    p->y       = y_tile;
                    p->largeur = (float)largeur_tiles * TILE_SIZE;
                    p->hauteur = (float)TILE_SIZE;
                    p->mortelle = mortelle;
                    p->type    = ch;
                    jeu->nb_plateformes++;
                }
                continue; 
            }

            if (estCaractereEnnemi(ch))
            {
                creerEnnemiDepuisType(jeu, ch,
                                      (float)c * TILE_SIZE, y_tile);
            }

            else if (ch == 'P' && jeu->nb_objets < NB_PIECES)
            {
                Objet *o = &jeu->objets[jeu->nb_objets];
                o->x        = (float)c * TILE_SIZE + (TILE_SIZE - 20) / 2.0f;
                o->y        = y_tile + TILE_SIZE * 0.3f;
                o->collectee = 0;
                o->type     = 0;
                o->largeur  = 20;
                o->hauteur  = 20;
                jeu->nb_objets++;
            }
            //Spawn
            else if (ch == 'S')
            {
                jeu->joueur.x = (float)c * TILE_SIZE;
                jeu->joueur.y = y_tile;
                jeu->spawn_x  = jeu->joueur.x;
                jeu->spawn_y  = jeu->joueur.y;
            }

            else if (ch == 'G')
            {
                jeu->sortie_x = (float)c * TILE_SIZE;
                jeu->sortie_y = y_tile;
            }

            c++;
        }
    }

    jeu->largeur_niveau = max_largeur;
    jeu->hauteur_niveau = rows * TILE_SIZE;
}

void initialiserNiveau(JeuEtat *jeu)
{
    jeu->nb_plateformes = 0;
    jeu->nb_ennemis     = 0;
    jeu->nb_objets      = 0;
    jeu->camera_x       = 0.0f;
    jeu->camera_y       = 0.0f;
    jeu->sortie_x       = 0.0f;
    jeu->sortie_y       = 0.0f;
    jeu->spawn_x        = 0.0f;
    jeu->spawn_y        = 0.0f;

        int id = jeu->niveau_actuel;
    if (id < 0 || id > 8) id = 1;
    chargerNiveauDepuisBlueprint(jeu, tous_les_niveaux[id].lignes, tous_les_niveaux[id].nb_lignes, tous_les_niveaux[id].nb_colonnes);
}

void mettreAJourCamera(JeuEtat *jeu)
{
    Joueur *j = &jeu->joueur;

    float cible_x = j->x - LARGEUR_FENETRE / 2.0f + j->largeur / 2.0f;
    jeu->camera_x += (cible_x - jeu->camera_x) * 0.12f;

    // Zone Morte Verticale 
    // On ne déplace la caméra Y que si le joueur s'éloigne trop du centre
    float centre_ecran_y = jeu->camera_y + HAUTEUR_FENETRE / 2.0f;
    float centre_joueur_y = j->y + j->hauteur / 2.0f;
    float ecart_y = centre_joueur_y - centre_ecran_y;
    float deadzone_y = 150.0f;

    if (ecart_y > deadzone_y) {
        jeu->camera_y += (ecart_y - deadzone_y) * 0.08f; // Mouvement doux
    } else if (ecart_y < -deadzone_y) {
        jeu->camera_y += (ecart_y + deadzone_y) * 0.08f;
    }

    // Clamping X
    if (jeu->camera_x < 0.0f) jeu->camera_x = 0.0f;
    if (jeu->camera_x > jeu->largeur_niveau - LARGEUR_FENETRE && jeu->largeur_niveau > LARGEUR_FENETRE)
        jeu->camera_x = jeu->largeur_niveau - LARGEUR_FENETRE;

    // Clamping Y
    if (jeu->camera_y < 0.0f) jeu->camera_y = 0.0f;
    if (jeu->camera_y > jeu->hauteur_niveau - HAUTEUR_FENETRE && jeu->hauteur_niveau > HAUTEUR_FENETRE)
        jeu->camera_y = jeu->hauteur_niveau - HAUTEUR_FENETRE;
}

void getPlatformHitbox(Plateforme *p, float *px, float *py, float *pw, float *ph)
{
    *px = p->x;
    *py = p->y;
    *pw = p->largeur;
    *ph = p->hauteur;

    if (p->type == '#' || p->type == '-')
    {
        // Marge gauche/droite pour platform1 et platform3 
        *px += 14.0f;
        *pw -= 28.0f;

        // La partie solide fait ~36px de haut, centrée dans le tile de 64px.
        // (64 - 36) / 2 = 14px de marge en bas et en haut. 
        *py += 14.0f;
        *ph  = 36.0f;
    }
    else if (p->type == 'y') {
        *ph = p->hauteur / 2.0f;
    }
    else if (p->type == 'Y') {
        *ph = p->hauteur / 2.0f;
        *py += p->hauteur / 2.0f;
    }
    else if (p->type == '<') {
        *pw = p->largeur / 2.0f;
        *px += p->largeur / 2.0f;
    }
    else if (p->type == '>') {
        *pw = p->largeur / 2.0f;
    }
}