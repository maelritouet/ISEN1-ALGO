/*
 * niveau.c - Gestion du niveau et de la caméra
 *
 * Fonctionnalités implémentées :
 *   [OBLIGATOIRE] Terrain avec plateformes
 *   [OBLIGATOIRE] Précipices (zones mortelles)
 *   [OBLIGATOIRE] Scrolling horizontal (caméra suit le joueur)
 *   [BONUS]       3 niveaux distincts (difficulté croissante)
 *   [BONUS]       Plateformes de différentes tailles
 *   [BONUS]       Jump pads (tremplins)
 *
 * Comment lire les niveaux :
 *   Chaque niveau est défini par un tableau de plateformes.
 *   Une plateforme "mortelle" est une zone de lave/vide.
 *   La caméra se déplace pour garder le joueur visible.
 *
 * Membre 2 - Niveau & caméra
 */

#include <stdio.h>
#include "jeu.h"
#include "niveau.h"
#include "joueur.h"   /* Pour accéder à la position du joueur */

/* =========================================================
 *  DONNÉES DES NIVEAUX
 *
 *  Chaque niveau est décrit par un tableau de structs initiales.
 *  On utilise un tableau temporaire, puis on copie dans jeu.plateformes.
 *
 *  Format : { x, y, largeur, hauteur, mortelle, active }
 * ========================================================= */

/* ---- Niveau 1 : "Les Ruines" ---- */
/* Un niveau introductif, plateformes larges, peu d'ennemis */
static Plateforme plateformes_niveau1[NB_PLATEFORMES] = {
    /* Sol principal */
    { 0.0f,    0.0f,   800.0f,  30.0f,  0, 1 },  /* 0  - sol de départ */
    { 950.0f,  0.0f,   400.0f,  30.0f,  0, 1 },  /* 1  - sol après précipice 1 */
    { 1500.0f, 0.0f,   600.0f,  30.0f,  0, 1 },  /* 2  - sol 3 */
    { 2300.0f, 0.0f,   400.0f,  30.0f,  0, 1 },  /* 3  - sol 4 */
    { 2900.0f, 0.0f,   700.0f,  30.0f,  0, 1 },  /* 4  - sol fin */

    /* Plateformes en hauteur */
    { 200.0f,  150.0f, 200.0f,  20.0f,  0, 1 },  /* 5  */
    { 500.0f,  250.0f, 150.0f,  20.0f,  0, 1 },  /* 6  */
    { 700.0f,  180.0f, 120.0f,  20.0f,  0, 1 },  /* 7  */
    { 1000.0f, 120.0f, 200.0f,  20.0f,  0, 1 },  /* 8  */
    { 1200.0f, 220.0f, 150.0f,  20.0f,  0, 1 },  /* 9  */
    { 1400.0f, 300.0f, 100.0f,  20.0f,  0, 1 },  /* 10 */
    { 1600.0f, 150.0f, 200.0f,  20.0f,  0, 1 },  /* 11 */
    { 1900.0f, 250.0f, 180.0f,  20.0f,  0, 1 },  /* 12 */
    { 2100.0f, 350.0f, 120.0f,  20.0f,  0, 1 },  /* 13 */
    { 2400.0f, 200.0f, 160.0f,  20.0f,  0, 1 },  /* 14 */
    { 2600.0f, 300.0f, 140.0f,  20.0f,  0, 1 },  /* 15 */
    { 2800.0f, 180.0f, 200.0f,  20.0f,  0, 1 },  /* 16 */
    { 3000.0f, 280.0f, 150.0f,  20.0f,  0, 1 },  /* 17 */

    /* Précipices mortels (lave au fond) */
    { 800.0f,  -50.0f, 150.0f,  30.0f,  1, 1 },  /* 18 - lave précipice 1 */
    { 2200.0f, -50.0f, 100.0f,  30.0f,  1, 1 },  /* 19 - lave précipice 2 */
    { 2700.0f, -50.0f, 200.0f,  30.0f,  1, 1 },  /* 20 - lave précipice 3 */

    /* Mur de fin de niveau */
    { 3580.0f, 0.0f,   30.0f,   400.0f, 0, 1 },  /* 21 - mur droit */

    /* Plateformes libres (non utilisées dans ce niveau) */
    { 0, 0, 0, 0, 0, 0 },  /* 22 */
    { 0, 0, 0, 0, 0, 0 },  /* 23 */
    { 0, 0, 0, 0, 0, 0 },  /* 24 */
    { 0, 0, 0, 0, 0, 0 },  /* 25 */
    { 0, 0, 0, 0, 0, 0 },  /* 26 */
    { 0, 0, 0, 0, 0, 0 },  /* 27 */
    { 0, 0, 0, 0, 0, 0 },  /* 28 */
    { 0, 0, 0, 0, 0, 0 },  /* 29 */
};

/* ---- Niveau 2 : "Les Catacombes" ---- */
/* Niveau plus vertical, plateformes plus petites, précipices plus nombreux */
static Plateforme plateformes_niveau2[NB_PLATEFORMES] = {
    /* Sol de départ */
    { 0.0f,    0.0f,   500.0f,  30.0f,  0, 1 },  /* 0 */
    { 700.0f,  0.0f,   300.0f,  30.0f,  0, 1 },  /* 1 */
    { 1200.0f, 0.0f,   200.0f,  30.0f,  0, 1 },  /* 2 */
    { 1700.0f, 0.0f,   400.0f,  30.0f,  0, 1 },  /* 3 */
    { 2400.0f, 0.0f,   500.0f,  30.0f,  0, 1 },  /* 4 */
    { 3100.0f, 0.0f,   500.0f,  30.0f,  0, 1 },  /* 5 */

    /* Plateformes hautes (parcours plus vertical) */
    { 100.0f,  200.0f, 120.0f,  20.0f,  0, 1 },  /* 6  */
    { 300.0f,  350.0f, 100.0f,  20.0f,  0, 1 },  /* 7  */
    { 500.0f,  450.0f, 100.0f,  20.0f,  0, 1 },  /* 8  */
    { 750.0f,  300.0f, 120.0f,  20.0f,  0, 1 },  /* 9  */
    { 950.0f,  180.0f, 100.0f,  20.0f,  0, 1 },  /* 10 */
    { 1100.0f, 350.0f, 80.0f,   20.0f,  0, 1 },  /* 11 */
    { 1300.0f, 200.0f, 100.0f,  20.0f,  0, 1 },  /* 12 */
    { 1500.0f, 300.0f, 80.0f,   20.0f,  0, 1 },  /* 13 */
    { 1800.0f, 150.0f, 120.0f,  20.0f,  0, 1 },  /* 14 */
    { 2000.0f, 280.0f, 100.0f,  20.0f,  0, 1 },  /* 15 */
    { 2200.0f, 380.0f, 80.0f,   20.0f,  0, 1 },  /* 16 */
    { 2500.0f, 200.0f, 130.0f,  20.0f,  0, 1 },  /* 17 */

    /* Précipices */
    { 500.0f,  -50.0f, 200.0f,  30.0f,  1, 1 },  /* 18 */
    { 1000.0f, -50.0f, 200.0f,  30.0f,  1, 1 },  /* 19 */
    { 1400.0f, -50.0f, 300.0f,  30.0f,  1, 1 },  /* 20 */
    { 2100.0f, -50.0f, 300.0f,  30.0f,  1, 1 },  /* 21 */

    /* Mur fin */
    { 3580.0f, 0.0f,   30.0f,   400.0f, 0, 1 },  /* 22 */

    { 0,0,0,0,0,0 }, /* 23 */
    { 0,0,0,0,0,0 }, /* 24 */
    { 0,0,0,0,0,0 }, /* 25 */
    { 0,0,0,0,0,0 }, /* 26 */
    { 0,0,0,0,0,0 }, /* 27 */
    { 0,0,0,0,0,0 }, /* 28 */
    { 0,0,0,0,0,0 }, /* 29 */
};

/* ---- Niveau 3 : "Le Donjon du Boss" ---- */
/* Niveau difficile, plateformes étroites, nombreux précipices */
static Plateforme plateformes_niveau3[NB_PLATEFORMES] = {
    /* Sol fragmenté */
    { 0.0f,    0.0f,   300.0f,  30.0f,  0, 1 },  /* 0 */
    { 500.0f,  0.0f,   200.0f,  30.0f,  0, 1 },  /* 1 */
    { 900.0f,  0.0f,   150.0f,  30.0f,  0, 1 },  /* 2 */
    { 1250.0f, 0.0f,   200.0f,  30.0f,  0, 1 },  /* 3 */
    { 1700.0f, 0.0f,   150.0f,  30.0f,  0, 1 },  /* 4 */
    { 2100.0f, 0.0f,   200.0f,  30.0f,  0, 1 },  /* 5 */
    { 2600.0f, 0.0f,   300.0f,  30.0f,  0, 1 },  /* 6 */
    { 3100.0f, 0.0f,   500.0f,  30.0f,  0, 1 },  /* 7 - arène boss */

    /* Plateformes hautes */
    { 100.0f,  200.0f, 80.0f,   20.0f,  0, 1 },  /* 8  */
    { 250.0f,  350.0f, 80.0f,   20.0f,  0, 1 },  /* 9  */
    { 550.0f,  250.0f, 80.0f,   20.0f,  0, 1 },  /* 10 */
    { 700.0f,  380.0f, 80.0f,   20.0f,  0, 1 },  /* 11 */
    { 950.0f,  200.0f, 80.0f,   20.0f,  0, 1 },  /* 12 */
    { 1100.0f, 320.0f, 80.0f,   20.0f,  0, 1 },  /* 13 */
    { 1300.0f, 180.0f, 80.0f,   20.0f,  0, 1 },  /* 14 */
    { 1500.0f, 300.0f, 80.0f,   20.0f,  0, 1 },  /* 15 */
    { 1750.0f, 200.0f, 80.0f,   20.0f,  0, 1 },  /* 16 */
    { 1950.0f, 350.0f, 80.0f,   20.0f,  0, 1 },  /* 17 */

    /* Nombreux précipices */
    { 300.0f,  -50.0f, 200.0f,  30.0f,  1, 1 },  /* 18 */
    { 700.0f,  -50.0f, 200.0f,  30.0f,  1, 1 },  /* 19 */
    { 1050.0f, -50.0f, 200.0f,  30.0f,  1, 1 },  /* 20 */
    { 1450.0f, -50.0f, 250.0f,  30.0f,  1, 1 },  /* 21 */
    { 1850.0f, -50.0f, 250.0f,  30.0f,  1, 1 },  /* 22 */
    { 2300.0f, -50.0f, 300.0f,  30.0f,  1, 1 },  /* 23 */
    { 2900.0f, -50.0f, 200.0f,  30.0f,  1, 1 },  /* 24 */

    /* Mur fin */
    { 3580.0f, 0.0f,   30.0f,   500.0f, 0, 1 },  /* 25 */

    { 0,0,0,0,0,0 }, /* 26 */
    { 0,0,0,0,0,0 }, /* 27 */
    { 0,0,0,0,0,0 }, /* 28 */
    { 0,0,0,0,0,0 }, /* 29 */
};

/* =========================================================
 *  Position X de fin de niveau (la porte)
 * ========================================================= */
static float x_fin_niveau = 3550.0f;

/* =========================================================
 *  initialiseNiveau()
 *
 *  Copie le tableau de plateformes du niveau demandé dans
 *  jeu.plateformes, et réinitialise la caméra.
 *
 *  numero : 1, 2 ou 3
 * ========================================================= */
void initialiseNiveau(int numero)
{
    int i;
    Plateforme *source;

    /* Choisir le bon tableau de données */
    switch (numero)
    {
        case 1: source = plateformes_niveau1; break;
        case 2: source = plateformes_niveau2; break;
        case 3: source = plateformes_niveau3; break;
        default:
            source = plateformes_niveau1;
            break;
    }

    /* Copier plateforme par plateforme dans l'état global */
    for (i = 0; i < NB_PLATEFORMES; i++)
    {
        jeu.plateformes[i] = source[i];
    }

    /* Caméra commence à l'origine */
    jeu.camera.x = 0.0f;

    /* Timer du niveau */
    jeu.timer = TIMER_NIVEAU;

    /* Numéro courant */
    jeu.niveau_actuel = numero;

    /* Difficulté croissante : le timer diminue avec les niveaux */
    if (numero == 2) jeu.timer = 90.0f;
    if (numero == 3) jeu.timer = 75.0f;

    printf("[Niveau] Niveau %d charge, timer=%.0f secondes\n", numero, jeu.timer);
}

/* =========================================================
 *  miseAJourCamera()
 *
 *  La caméra suit le joueur horizontalement.
 *  Elle avance quand le joueur approche du bord droit,
 *  et recule quand il approche du bord gauche.
 *
 *  La caméra ne va jamais en dessous de 0 (début du niveau),
 *  ni au-delà de la fin du niveau.
 * ========================================================= */
void miseAJourCamera(void)
{
    Joueur *j = &jeu.joueur;
    float  *camX = &jeu.camera.x;

    /* Position du joueur DANS la fenêtre (relative à la caméra) */
    float pos_dans_fenetre = j->x - *camX;

    /* Si le joueur dépasse le seuil droit → avancer la caméra */
    if (pos_dans_fenetre > SEUIL_CAMERA_DROITE)
    {
        *camX = j->x - SEUIL_CAMERA_DROITE;
    }

    /* Si le joueur passe le seuil gauche → reculer la caméra */
    if (pos_dans_fenetre < SEUIL_CAMERA_GAUCHE)
    {
        *camX = j->x - SEUIL_CAMERA_GAUCHE;
    }

    /* Limites de la caméra : ne pas sortir du niveau */
    if (*camX < 0.0f)
        *camX = 0.0f;

    float cam_max = LARGEUR_NIVEAU - LARGEUR_FENETRE;
    if (*camX > cam_max)
        *camX = cam_max;
}

/* =========================================================
 *  debutNiveau() / finNiveau()
 * ========================================================= */
float debutNiveau(void) { return 0.0f; }
float finNiveau(void)   { return x_fin_niveau; }
