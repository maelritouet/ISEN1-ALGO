/* ============================================================
 *  niveau.c — Module niveau & caméra
 *
 *  Axe Y vers le HAUT (convention OpenGL/Gfxlib).
 *
 *  == SYSTÈME BLUEPRINT ==
 *  Chaque niveau est défini par un tableau de chaînes de 15×56
 *  caractères. Le parseur chargerNiveauDepuisBlueprint() lit ce
 *  tableau et place automatiquement plateformes, ennemis, pièces.
 *
 *  LÉGENDE DU BLUEPRINT :
 *  S : Spawn du Joueur
 *  G : Sortie (Goal)
 *  P : Pièce
 *  X : Lave
 *
 *  --- Sols pleins 3 parties (horizontaux) ---
 *  = : Grass (3 parts)
 *  _ : Dirt (3 parts)
 *
 *  --- Plateformes 3 parties (hitbox réduite) ---
 *  # : Rock Platform (3 parts)
 *  - : Wood Platform (3 parts)
 *
 *  --- Colonnes (verticales) ---
 *  | : Column (Ceiling, Middle, Floor dessinés automatiquement)
 *
 *  --- Blocs Aléatoires ---
 *  D : Dungeon Tile (Variante choisie selon la coordonnée)
 *
 *  --- Autres éléments ---
 *  I : Ice
 *  R : Rock
 *  r : Small rock
 *  C : Chain
 *  c : Column Ceiling (manuel)
 *  f : Column Floor (manuel)
 *  m : Column Middle (manuel)
 *  B : Crate
 *  Y : Spike Ceiling
 *  y : Spike Floor
 *  < : Spike Left Wall
 *  > : Spike Right Wall
 *
 *  --- ENNEMIS ---
 *  E : Chevalier Gobelin
 *  M : Slime Vert
 *  Z : Slime Rouge
 * ============================================================ */

#include <stddef.h>
#include <string.h>
#include <math.h>
#include "niveau.h"
#include "jeu.h"

/* ------------------------------------------------------------
 *  BLUEPRINT — Niveau 1 : Plaines médiévales
 *
 *  Structure (gauche → droite) :
 *   Zone A (cols  0-11) : départ, sol plein, plateformes basses
 *   Zone B (cols 12-15) : PRÉCIPICE 1 (fond mortel)
 *   Zone C (cols 16-27) : sol intermédiaire, plateformes hautes
 *   Zone D (cols 28-31) : PRÉCIPICE 2
 *   Zone E (cols 32-55) : section finale, sortie en haut à droite
 *
 *  Chaque rangée fait exactement BLUEPRINT_COLS (56) caractères.
 * ------------------------------------------------------------ */
static const char *blueprint_n2[] = {
/*col:  00000000001111111111222222222233333333334444444444555555 */
/*col:  01234567890123456789012345678901234567890123456789012345 */
/*r00*/ "........................................................",
/*r01*/ "........................................................",
/*r02*/ "....................PPPP................................",
/*r03*/ "........####.......####............................R....",
/*r04*/ "....E.................................P.................",
/*r05*/ "..####...............................####.....P.........",
/*r06*/ ".............##...........E.P...............####....G...",
/*r07*/ "....................P....####...####.............#######",
/*r08*/ "..............P...####..................................",
/*r09*/ "...........#######......................................",
/*r10*/ "S.PP...E......................E.........................",
/*r11*/ "============......=================........=============",
/*r12*/ "____________XXXXXX_________________XXXXXXXX__________====",
/*r13*/ "________________________________________________________",
/*r14*/ "________________________________________________________",
};

static const char *blueprint_n1[] = {
/*col:  00000000001111111111222222222233333333334444444444555555 */
/*r00*/ "........................................................",
/*r01*/ "...........G............................................",
/*r02*/ "..........###...........................................",
/*r03*/ "........................................................",
/*r04*/ "........###.............................................",
/*r05*/ "........................................................",
/*r06*/ "......###...............................................",
/*r07*/ "........................................................",
/*r08*/ "....###.................................................",
/*r09*/ "........................................................",
/*r10*/ "..###...................................................",
/*r11*/ ".......................##....####.......................",
/*r12*/ ".##################.....................................",
/*r13*/ "...........................####.........................",
/*r14*/ "........................................................",
/*r15*/ "..............................#####.....................",
/*r16*/ "........................................................",
/*r17*/ ".....................................####...............",
/*r18*/ "....PP......PP..............................###.....PP..",
/*r19*/ "...###.....################################.......######",
/*r20*/ ".........PP.........####.....PP.PP.PP.....PP.PP.........",
/*r21*/ ".......#####....#.............####.##......####.##......",
/*r22*/ "..PP.......................##............PP............P",
/*r23*/ "..####.......##.....####..............####...........###",
/*r24*/ ".....###............Z......###.........M.......M........",
/*r25*/ "S.........M.............................................",
/*r26*/ "============.....===========.....===========......======",
/*r27*/ "____________.....___________XXXXX___________XXXXXX______",
/*r28*/ "____________....._______________________________________",
/*r29*/ "____________....._______________________________________",
};

static const char *blueprint_n3[] = {
"........................................................",
".......................................................G",
".....................................................###",
"........................................................",
"..............................................P..####...",
"............................................###.........",
"........................................................",
"....................................P....##.............",
"...................................####.................",
"........................................................",
".........................P...#####......................",
"........................##..............................",
"........................................................",
"...............P....###.................................",
"..............##........................................",
"........................................................",
"..........####..........................................",
"....P...................................................",
"...####.................................................",
"............##.......Z..................................",
".................########...............................",
"..........##............................................",
"...............###......................................",
"........P................##........E....................",
".......####........###..........#######.................",
"...............###......................................",
".....P......Z...........................................",
"S....##...#####......M.........................P........",
"###...............#######.....................###.......",
"XXX...............XXXXXXX.....................XXX.......",
};

static const char *blueprint_n4[] = {
"DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD",
"D>.........................................D...........D",
"D>...........................BB.....P......D........BD.D",
"D>.S..........M.B.P.Z.....DDDDDDDDDDDDD....D...BBB...D.D",
"DDDDDD----D..DDDD.DDDDD....|..........D....D........BD.D",
"..........DyyD........D....|...............D.........D.D",
"..........DDDD........D....|.........Z.....D.....BB..D.D",
"......................DyyyyD......DDDDD....D..P......D.D",
"......................DDDDDD.....yDPPPDyyyyD..BB.....D.D",
"........................|........DDP.PDDDDDD......BB.D.D",
"........................|..............PP...........PD.D",
"........................|.............ZBB.....M.....BD.D",
"........................|.P.......DDDDDDDDD...DD.....D.D",
"........................DDDDD>.......YYYYYDyyyyyyyyyyD.D",
"............................D>............DDDDDDDDDDDD.D",
".....M......................D>............|............D",
"...#####....................Dyyyyyyy......|.....DD..DDDD",
"............................DDDDDDDDDD....|.DD.........D",
".....................................|...<D............D",
".....................................|...<D.....###....D",
".....................................DyyyyDyyyyyy......D",
".....................................DDDDDDDDDDDD......D",
".......................................................D",
".............Z...................................###...D",
"...........#####.............................##........D",
"...................................................yyyyD",
"...................................................DDDDD",
".......................................................D",
"........##...##...##...M...........................P..GD",
"RRRRR.................RRRRR........................####D",
"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXD",
};

/* ------------------------------------------------------------
 *  estCaractereEnnemi — Vérifie si un caractère du blueprint
 *  représente un ennemi (tous types confondus).
 *
 *  Pour ajouter un type : ajouter son caractère ici.
 * ------------------------------------------------------------ */
static int estCaractereEnnemi(char ch)
{
    return (ch == 'E' || ch == 'M' || ch == 'Z');  /* E = Chevalier, M = Slime, Z = Red Slime */
    /* Exemples futurs :
     * || ch == 'F'    // Ennemi volant
     * || ch == 'K'    // Squelette
     * || ch == 'O'    // Ogre
     */
}


static void creerEnnemiDepuisType(JeuEtat *jeu, char ch, float x, float y)
{
    if (jeu->nb_ennemis >= NB_ENNEMIS) return;

    /* différentes vitesses de patrouille pour varier les selon ennemis */
    static const float vitesses[] = { 1.5f, 2.0f, 2.5f, 2.0f, 1.8f, 2.3f };
    static const int nb_vitesses  = 6;

    float vb  = vitesses[jeu->nb_ennemis % nb_vitesses];
    int   dir = (jeu->nb_ennemis % 2 == 0) ? DIR_DROITE : DIR_GAUCHE;

    Ennemi *e = &jeu->ennemis[jeu->nb_ennemis];
    e->x           = x;
    e->y           = y;
    e->direction   = dir;
    e->vivant      = 1;
    e->attaque     = 0;
    e->en_charge   = 0;

    switch (ch)
    {
        case 'E':
            e->type_ennemi = TYPE_CHEVALIER_GOBELIN;
            e->largeur     = 48;
            e->hauteur     = 48;
            e->vx_base     = vb;
            break;

        case 'M': 
            e->type_ennemi = TYPE_SLIME;
            e->largeur     = 40; 
            e->hauteur     = 40;
            e->vx_base     = vb * 0.75f; 
            break;

        case 'Z': 
            e->type_ennemi = TYPE_RED_SLIME;
            e->largeur     = 40;
            e->hauteur     = 40;
            e->vx_base     = vb * 1.5f; 
            break;

        /* template:
         * case 'F':
         *     e->type_ennemi = TYPE_ENNEMI_VOLANT;
         *     e->largeur     = 32;
         *     e->hauteur     = 32;
         *     e->vx_base     = 3.0f;
         *     break;
         */

        default: //fallback slime
            e->type_ennemi = TYPE_SLIME;
            e->largeur     = 40;
            e->hauteur     = 40;
            e->vx_base     = vb;
            break;
    }

    e->vx = e->vx_base * (dir == DIR_DROITE ? 1.0f : -1.0f);
    jeu->nb_ennemis++;
}

/* ------------------------------------------------------------
 *  chargerNiveauDepuisBlueprint — Parseur générique
 *
 *  Parcourt le blueprint caractère par caractère :
 *  - Les runs de blocs identiques consécutifs sur une même rangée
 *    sont fusionnés en une seule Plateforme (économie de slots).
 *  - Le caractère d'origine est stocké dans p->type.
 *  - Les caractères d'ennemis créent un ennemi du type correspondant.
 *  - 'P' crée une pièce centrée dans le tile.
 *  - 'S' fixe la position de spawn du joueur.
 *  - 'G' fixe la zone de sortie (victoire).
 * ------------------------------------------------------------ */
static void chargerNiveauDepuisBlueprint(JeuEtat *jeu,
                                         const char **bp,
                                         int rows, int cols)
{
    int r, c;
    (void)cols; /* On utilise strlen pour supporter des largeurs variables */

    float max_largeur = 0.0f;

    for (r = 0; r < rows; r++)
    {
        int largeur_ligne = (int)strlen(bp[r]); /* Largeur réelle de cette ligne */
        float y_tile = (float)(rows - 1 - r) * TILE_SIZE;

        if (largeur_ligne * TILE_SIZE > max_largeur) max_largeur = largeur_ligne * TILE_SIZE;

        c = 0;
        while (c < largeur_ligne)
        {
            char ch = bp[r][c];

            /* --- Colonne verticale '|' --- */
            if (ch == '|')
            {
                /* Si on a déjà un '|' juste au-dessus dans le blueprint, cette case a déjà été 
                   fusionnée par la boucle d'au-dessus lors d'un passage précédent. On l'ignore. */
                if (r > 0 && bp[r-1][c] == '|') {
                    c++;
                    continue;
                }

                /* C'est le sommet d'une nouvelle colonne ! On cherche sa longueur vers le bas. */
                int r_end = r;
                while (r_end < rows && bp[r_end][c] == '|') {
                    r_end++;
                }
                int hauteur_tiles = r_end - r;

                if (jeu->nb_plateformes < NB_PLATEFORMES)
                {
                    Plateforme *p = &jeu->plateformes[jeu->nb_plateformes];
                    p->x       = (float)c * TILE_SIZE;
                    /* La coordonnée Y est celle du bloc le plus bas (r_end - 1) */
                    p->y       = (float)(rows - 1 - (r_end - 1)) * TILE_SIZE;
                    p->largeur = (float)TILE_SIZE;
                    p->hauteur = (float)hauteur_tiles * TILE_SIZE;
                    p->mortelle = 0;
                    p->type    = '|';
                    jeu->nb_plateformes++;
                }
                c++;
                continue;
            }

            /* --- Plateforme horizontale ou zone mortelle : fusion des runs --- */
            /* Tout ce qui n'est pas air, ennemi, pièce, spawn, sortie est un bloc solide */
            if (ch != '.' && !estCaractereEnnemi(ch) && ch != 'P' && ch != 'S' && ch != 'G')
            {
                int c_start  = c;
                int mortelle = (ch == 'X' || ch == 'y' || ch == 'Y' || ch == '<' || ch == '>') ? 1 : 0;
                while (c < largeur_ligne && bp[r][c] == ch)
                    c++;
                int largeur_tiles = c - c_start;

                if (jeu->nb_plateformes < NB_PLATEFORMES)
                {
                    Plateforme *p = &jeu->plateformes[jeu->nb_plateformes];
                    p->x       = (float)c_start * TILE_SIZE;
                    p->y       = y_tile;
                    p->largeur = (float)largeur_tiles * TILE_SIZE;
                    p->hauteur = (float)TILE_SIZE;
                    p->mortelle = mortelle;
                    p->type    = ch;
                    jeu->nb_plateformes++;
                }
                continue; /* c déjà avancé par le while interne */
            }

            /* --- Ennemi (tous types) --- */
            if (estCaractereEnnemi(ch))
            {
                creerEnnemiDepuisType(jeu, ch,
                                      (float)c * TILE_SIZE, y_tile);
            }

            /* --- Pièce --- */
            else if (ch == 'P' && jeu->nb_objets < NB_PIECES)
            {
                Objet *o = &jeu->objets[jeu->nb_objets];
                o->x        = (float)c * TILE_SIZE + (TILE_SIZE - 20) / 2.0f;
                o->y        = y_tile + TILE_SIZE * 0.3f;
                o->collectee = 0;
                o->type     = 0;
                o->largeur  = 20;
                o->hauteur  = 20;
                jeu->nb_objets++;
            }

            /* --- Spawn joueur --- */
            else if (ch == 'S')
            {
                jeu->joueur.x = (float)c * TILE_SIZE;
                jeu->joueur.y = y_tile;
                /* Sauvegarder le spawn pour les respawns après mort */
                jeu->spawn_x  = jeu->joueur.x;
                jeu->spawn_y  = jeu->joueur.y;
            }

            /* --- Zone de sortie --- */
            else if (ch == 'G')
            {
                jeu->sortie_x = (float)c * TILE_SIZE;
                jeu->sortie_y = y_tile;
            }

            c++;
        }
    }

    jeu->largeur_niveau = max_largeur;
    jeu->hauteur_niveau = rows * TILE_SIZE;
}

/* ============================================================
 *  initialiserNiveau — Point d'entrée du module
 * ============================================================ */
void initialiserNiveau(JeuEtat *jeu)
{
    jeu->nb_plateformes = 0;
    jeu->nb_ennemis     = 0;
    jeu->nb_objets      = 0;
    jeu->camera_x       = 0.0f;
    jeu->camera_y       = 0.0f;
    jeu->sortie_x       = 0.0f;
    jeu->sortie_y       = 0.0f;
    jeu->spawn_x        = 0.0f;
    jeu->spawn_y        = 0.0f;

    switch (jeu->niveau_actuel)
    {
        case 1:
            chargerNiveauDepuisBlueprint(jeu,
                blueprint_n1, sizeof(blueprint_n1)/sizeof(char*), BLUEPRINT_COLS);
            break;

        case 2:
            chargerNiveauDepuisBlueprint(jeu,
                blueprint_n2, sizeof(blueprint_n2)/sizeof(char*), 120);
            break;

        case 3:
            chargerNiveauDepuisBlueprint(jeu,
                blueprint_n3, sizeof(blueprint_n3)/sizeof(char*), 120);
            break;

        case 4:
            chargerNiveauDepuisBlueprint(jeu,
                blueprint_n4, sizeof(blueprint_n4)/sizeof(char*), 120);
            break;

        default:
            chargerNiveauDepuisBlueprint(jeu,
                blueprint_n1, sizeof(blueprint_n1)/sizeof(char*), 120);
            break;
    }
}

/* ============================================================
 *  mettreAJourCamera — Caméra douce qui suit le joueur
 *
 *  Interpolation linéaire (lerp, facteur 0.12) :
 *  on déplace la caméra de 12% de l'écart restant → mouvement
 *  fluide qui se ralentit naturellement en approchant la cible.
 * ============================================================ */
void mettreAJourCamera(JeuEtat *jeu)
{
    Joueur *j = &jeu->joueur;

    float cible_x = j->x - LARGEUR_FENETRE / 2.0f + j->largeur / 2.0f;
    jeu->camera_x += (cible_x - jeu->camera_x) * 0.12f;

    // --- Zone Morte Verticale ---
    // On ne déplace la caméra Y que si le joueur s'éloigne trop du centre
    float centre_ecran_y = jeu->camera_y + HAUTEUR_FENETRE / 2.0f;
    float centre_joueur_y = j->y + j->hauteur / 2.0f;
    float ecart_y = centre_joueur_y - centre_ecran_y;
    float deadzone_y = 150.0f; // Les sauts basiques (env 100px) ne bougeront pas la caméra

    if (ecart_y > deadzone_y) {
        jeu->camera_y += (ecart_y - deadzone_y) * 0.08f; // Mouvement doux
    } else if (ecart_y < -deadzone_y) {
        jeu->camera_y += (ecart_y + deadzone_y) * 0.08f;
    }

    // Clamping X
    if (jeu->camera_x < 0.0f) jeu->camera_x = 0.0f;
    if (jeu->camera_x > jeu->largeur_niveau - LARGEUR_FENETRE && jeu->largeur_niveau > LARGEUR_FENETRE)
        jeu->camera_x = jeu->largeur_niveau - LARGEUR_FENETRE;

    // Clamping Y
    if (jeu->camera_y < 0.0f) jeu->camera_y = 0.0f;
    if (jeu->camera_y > jeu->hauteur_niveau - HAUTEUR_FENETRE && jeu->hauteur_niveau > HAUTEUR_FENETRE)
        jeu->camera_y = jeu->hauteur_niveau - HAUTEUR_FENETRE;
}

void getPlatformHitbox(Plateforme *p, float *px, float *py, float *pw, float *ph)
{
    *px = p->x;
    *py = p->y;
    *pw = p->largeur;
    *ph = p->hauteur;

    if (p->type == '#' || p->type == '-')
    {
        /* Marge gauche/droite pour platform1 et platform3 */
        *px += 14.0f;
        *pw -= 28.0f;

        /* La partie solide fait ~36px de haut, centrée dans le tile de 64px.
         * (64 - 36) / 2 = 14px de marge en bas et en haut. */
        *py += 14.0f;
        *ph  = 36.0f;
    }
    else if (p->type == 'y') {
        // Spike Floor : 50% du bas
        *ph = p->hauteur / 2.0f;
        // Y part du bas dans ce moteur (OpenGL), donc pas besoin de modifier py
    }
    else if (p->type == 'Y') {
        // Spike Ceiling : 50% du haut
        *ph = p->hauteur / 2.0f;
        *py += p->hauteur / 2.0f;
    }
    else if (p->type == '<') {
        // Pointe vers la gauche : donc attaché au mur de droite (Right 50%)
        *pw = p->largeur / 2.0f;
        *px += p->largeur / 2.0f;
    }
    else if (p->type == '>') {
        // Pointe vers la droite : donc attaché au mur de gauche (Left 50%)
        *pw = p->largeur / 2.0f;
        // X part de la gauche, pas besoin de modifier px
    }
}