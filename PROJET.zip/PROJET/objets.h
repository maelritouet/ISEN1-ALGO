#ifndef OBJETS_H
#define OBJETS_H

#include "jeu.h"

//  objets.h 

void mettreAJourObjets(JeuEtat *jeu);

void initialiserJeu(JeuEtat *jeu);

#endif
