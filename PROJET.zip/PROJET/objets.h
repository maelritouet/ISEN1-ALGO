/*
 * objets.h - Déclarations du module objets et logique de jeu
 *
 * Ce module gère :
 *   - Les pièces, power-ups, clés
 *   - La détection de collecte (joueur passe dessus)
 *   - Les bonus accordés selon le type
 *   - La transition de niveau (porte de fin)
 *   - La sauvegarde des scores (bonus)
 *
 * Membre 4 - Objets & game logic
 */

#ifndef OBJETS_H
#define OBJETS_H

#include "jeu.h"

/* Nombre de pièces à collecter pour gagner une vie */
#define PIECES_PAR_VIE  10

/* Rayon de collecte (en pixels) */
#define RAYON_COLLECTE  30.0f

/* Prototypes */
void initialiseObjets(void);
void miseAJourObjets(void);

/* Renvoie le nombre de pièces non collectées dans le niveau actuel */
int nbPiecesRestantes(void);

/* Sauvegarde/charge le tableau des scores (bonus) */
void sauvegardeScores(void);
void chargeScores(void);

#endif /* OBJETS_H */
