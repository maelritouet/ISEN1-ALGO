#ifndef OBJETS_H
#define OBJETS_H

#include "jeu.h"

// ============================================================
//  objets.h — Module objets & game logic (Membre 4)
// ============================================================

void initialiserObjets(JeuEtat *jeu);
void mettreAJourObjets(JeuEtat *jeu);

// Initialise l'état complet du jeu (appelé depuis main.c)
void initialiserJeu(JeuEtat *jeu);

#endif
