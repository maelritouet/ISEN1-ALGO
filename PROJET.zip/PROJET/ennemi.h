#ifndef ENNEMI_H
#define ENNEMI_H

#include "jeu.h"

void mettreAJourEnnemis(JeuEtat *jeu);

#endif