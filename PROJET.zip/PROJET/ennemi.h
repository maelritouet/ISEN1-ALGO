/*
 * ennemi.h - Déclarations du module ennemis
 *
 * Ce module gère :
 *   - L'initialisation des ennemis selon le niveau
 *   - Leurs déplacements automatiques
 *   - Leur IA (poursuite du joueur, retournement)
 *   - La détection de mort (saut dessus) et d'attaque
 *
 * Membre 3 - Ennemis
 */

#ifndef ENNEMI_H
#define ENNEMI_H

#include "jeu.h"

/* Types d'ennemis */
#define TYPE_GOBELIN    0   /* Patrouille simple */
#define TYPE_SQUELETTE  1   /* Patrouille + peut sauter */
#define TYPE_BOSS       2   /* Gros ennemi, plus de vie */

/* Vitesses par type d'ennemi */
#define VITESSE_GOBELIN     1.5f
#define VITESSE_SQUELETTE   2.0f
#define VITESSE_BOSS        1.0f

/* Distance d'activation : l'ennemi commence à bouger quand le joueur
 * est à moins de DIST_ACTIVATION pixels */
#define DIST_ACTIVATION     400.0f

/* Distance d'attaque : ennemi en mode "charge" si le joueur est proche */
#define DIST_ATTAQUE        100.0f

/* Prototypes */
void initialiseEnnemis(void);
void miseAJourEnnemis(void);

/* Renvoie 1 si l'ennemi i et le joueur se chevauchent */
int collisionEnnemiJoueur(int i);

#endif /* ENNEMI_H */
