#ifndef ENNEMI_H
#define ENNEMI_H

#include "jeu.h"

// ============================================================
//  ennemi.h — Module ennemis (Membre 3)
// ============================================================

// Place les ennemis dans le niveau courant
void initialiserEnnemis(JeuEtat *jeu);

// Met à jour tous les ennemis (mouvement, IA, contact joueur)
void mettreAJourEnnemis(JeuEtat *jeu);

#endif