#include "menu.h"
#include <stdio.h>
#include <stdlib.h>
#include "gfxlib/GfxLib.h"
#include "rendu.h"

void dessinerMenu(void) {
    int cx = LARGEUR_FENETRE / 2;
    int cy = HAUTEUR_FENETRE / 2;

    dessinerFondMenu();

    epaisseurDeTrait(6.0f);
    couleurCourante(200, 160, 50);
    afficheChaine("MEDIEVAL FANTASY", 48, cx - 310, cy + 80);

    couleurCourante(200, 160, 50);
    rectangle(cx - 340, cy + 65, cx + 340, cy + 67);

    epaisseurDeTrait(4.0f);
    couleurCourante(255, 255, 255);
    afficheChaine("[ ENTREE ]  Jouer", 24, cx - 150, cy);

    couleurCourante(180, 180, 180);
    afficheChaine("[ Q ]       Quitter", 20, cx - 140, cy - 50);

    couleurCourante(140, 200, 255);
    afficheChaine("[ H ]       Aide / Touches", 20, cx - 140, cy - 100);

    epaisseurDeTrait(2.5f);
    couleurCourante(100, 100, 120);
    afficheChaine("ISEN Toulon - CIN1 2026", 14, cx - 190, 60);

    epaisseurDeTrait(1.0f);
}

void dessinerSelectionNiveau(JeuEtat *jeu) {
    const char *noms_niveaux[9] = {
        "Niveau 0  -  Tutoriel",
        "Niveau 1  -  lever de soleil sur la moisson",
        "Niveau 2  -  Montagnes enneigees",
        "Niveau 3  -  Sunset",
        "Niveau 4  -  La longue nuit ",
        "Niveau 5  -  Le gouffre sans fond",
        "Niveau 6  -  Au cachot !",
        "Niveau 7  -  Bonne chance",
        "Niveau 8  -  Le chateau des ombres"
    };
    const int NB_LIGNES = 9;
    int i;
    int cx = LARGEUR_FENETRE / 2;
    int cy = HAUTEUR_FENETRE / 2;

    effaceFenetre(10, 12, 35);

    epaisseurDeTrait(5.0f);
    couleurCourante(200, 160, 50);
    afficheChaine("CHOISIR UN NIVEAU", 36, cx - 240, cy + 300);
    epaisseurDeTrait(3.0f);

    couleurCourante(200, 160, 50);
    rectangle(cx - 340, cy + 287, cx + 340, cy + 289);

    for (i = 0; i < NB_LIGNES; i++) {
        int y_ligne = (cy + 220) - i * 45;
        int selectionne = (i == jeu->selection_niveau);
        int disponible  = (i <= jeu->nb_niveaux);

        if (selectionne && disponible) {
            couleurCourante(255, 210, 50);
            afficheChaine(">", 28, cx - 375, y_ligne);
            afficheChaine(noms_niveaux[i], 26, cx - 340, y_ligne);
            if (jeu->meilleurs_temps[i] < 9999.0f) {
                char rec[32];
                sprintf(rec, "[Record: %.2fs]", jeu->meilleurs_temps[i]);
                couleurCourante(180, 255, 180);
                afficheChaine(rec, 20, cx + 180, y_ligne);
            }
        }
        else if (disponible) {
            couleurCourante(200, 200, 200);
            afficheChaine(noms_niveaux[i], 24, cx - 340, y_ligne);
            if (jeu->meilleurs_temps[i] < 9999.0f) {
                char rec[32];
                sprintf(rec, "[Record: %.2fs]", jeu->meilleurs_temps[i]);
                couleurCourante(150, 200, 150);
                afficheChaine(rec, 18, cx + 180, y_ligne);
            }
        }
        else {
            couleurCourante(90, 90, 110);
            afficheChaine(noms_niveaux[i], 22, cx - 340, y_ligne);
            afficheChaine("(A venir)", 16, cx + 180, y_ligne);
        }
    }
    couleurCourante(140, 140, 160);
    afficheChaine("HAUT / BAS  pour naviguer", 16, cx - 180, 140);
    afficheChaine("ENTREE      pour lancer",   16, cx - 180, 115);
    afficheChaine("ECHAP       pour revenir",  16, cx - 180,  90);
}

void dessinerAide(void) {
    int cx = LARGEUR_FENETRE / 2;
    int cy = HAUTEUR_FENETRE / 2;

    effaceFenetre(10, 12, 35);

    epaisseurDeTrait(5.0f);
    couleurCourante(200, 160, 50);
    afficheChaine("GUIDE DES TOUCHES", 36, cx - 250, cy + 250);
    couleurCourante(200, 160, 50);
    rectangle(cx - 340, cy + 237, cx + 340, cy + 239);
    epaisseurDeTrait(4.0f);
    couleurCourante(140, 200, 255);
    afficheChaine("-- Controles en jeu --", 22, cx - 170, cy + 190);
    couleurCourante(255, 255, 255);
    afficheChaine("Fleche Gauche     Aller a gauche",        20, cx - 300, cy + 140);
    afficheChaine("Fleche Droite     Aller a droite",        20, cx - 300, cy + 105);
    afficheChaine("Fleche Haut       Sauter",                20, cx - 300, cy +  70);
    afficheChaine("Espace            Sauter (alternatif)",   20, cx - 300, cy +  35);
    afficheChaine("E                 Dash",                  20, cx - 300, cy +  0);
    couleurCourante(140, 200, 255);
    afficheChaine("-- Navigation menus --", 22, cx - 170, cy - 20);
    couleurCourante(255, 255, 255);
    afficheChaine("Entree            Valider / Lancer",      20, cx - 300, cy -  70);
    afficheChaine("Haut / Bas        Naviguer",              20, cx - 300, cy - 105);
    afficheChaine("Echap             Retour / Quitter",      20, cx - 300, cy - 140);
    afficheChaine("Q                 Quitter le jeu",        20, cx - 300, cy - 175);
    afficheChaine("H                 Ouvrir cette aide",     20, cx - 300, cy - 210);
    couleurCourante(200, 160, 50);
    afficheChaine("Astuce : Saute sur les ennemis pour les eliminer !", 18, cx - 280, cy - 290);
    epaisseurDeTrait(3.0f);
    couleurCourante(140, 140, 160);
    afficheChaine("ECHAP / ENTREE  pour revenir au menu", 16, cx - 220, 60);
    epaisseurDeTrait(1.0f);
}

void dessinerGameOver(void) {
    int cx = LARGEUR_FENETRE / 2;
    int cy = HAUTEUR_FENETRE / 2;
    
    dessinerFondMort();

    epaisseurDeTrait(6.0f);
    couleurCourante(220, 50, 50);
    afficheChaine("GAME OVER", 50, cx - 160, cy + 40);
    epaisseurDeTrait(3.0f);
    couleurCourante(255, 255, 255);
    afficheChaine("Appuie sur ENTREE pour recommencer", 20, cx - 240, cy - 60);
    epaisseurDeTrait(1.0f);
}

void dessinerVictoire(JeuEtat *jeu) {
    int cx = LARGEUR_FENETRE / 2;
    int cy = HAUTEUR_FENETRE / 2;
    char texte[64];
    int  ms    = (int)(jeu->timer_complet * 1000);
    int  sec   = ms / 1000;
    int  centi = (ms % 1000) / 10;

    dessinerFondVictoire();

    epaisseurDeTrait(6.0f);
    couleurCourante(80, 220, 80);
    afficheChaine("VICTOIRE !", 50, cx - 160, cy + 60);

    epaisseurDeTrait(3.0f);
    if (jeu->nouveau_record_etabli) {
        couleurCourante(255, 100, 100);
        afficheChaine("NOUVEAU RECORD !", 32, cx - 180, cy + 120);
        couleurCourante(255, 215, 0);
        sprintf(texte, "Temps : %d.%02d s", sec, centi);
        afficheChaine(texte, 28, cx - 110, cy + 10);
    } else {
        couleurCourante(255, 215, 0);
        sprintf(texte, "Temps : %d.%02d s", sec, centi);
        afficheChaine(texte, 28, cx - 110, cy + 10);

        couleurCourante(180, 255, 180);
        sprintf(texte, "Meilleur temps : %.2f s", jeu->meilleurs_temps[jeu->niveau_actuel]);
        afficheChaine(texte, 20, cx - 130, cy - 20);
    }

    couleurCourante(200, 200, 200);
    sprintf(texte, "Pieces : %d", jeu->joueur.pieces);
    afficheChaine(texte, 22, cx - 80, cy - 55);

    epaisseurDeTrait(2.0f);
    couleurCourante(255, 255, 255);
    afficheChaine("Appuie sur ENTREE pour rejouer", 20, cx - 220, cy - 100);
    epaisseurDeTrait(1.0f);
}
