#include "joueur.h"
#include "objets.h"
#include "jeu.h"
#include "niveau.h"
#include "gfxlib/GfxLib.h"
#include <stdlib.h>

static int toucheGauche = 0;
static int toucheDroite = 0;

void mettreAJourTouches(JeuEtat *jeu, int gauche, int droite)
{
    (void)jeu;
    toucheGauche = gauche;
    toucheDroite = droite;
}

void initialiserJoueur(JeuEtat *jeu)
{
    jeu->joueur.x = (jeu->spawn_x > 0.0f) ? jeu->spawn_x : 100.0f;
    jeu->joueur.y = (jeu->spawn_y > 0.0f) ? jeu->spawn_y : 100.0f;
    jeu->joueur.vx           = 0.0f;
    jeu->joueur.vy           = 0.0f;
    jeu->joueur.direction    = DIR_DROITE;
    jeu->joueur.vies         = 3;
    jeu->joueur.pieces       = 0;
    jeu->joueur.invulnerable = 0;
    jeu->joueur.au_sol       = 0;
    jeu->joueur.vivant       = 1;
    jeu->joueur.largeur      = 48;
    jeu->joueur.hauteur      = 48;
    jeu->joueur.coyote_timer = 0;
    jeu->joueur.jump_buffer  = 0;
    jeu->joueur.sauts_restants = 1;
    jeu->joueur.en_dash      = 0;
    jeu->joueur.timer_dash   = 0;
    jeu->joueur.cooldown_dash = 0;
    toucheGauche = 0;
    toucheDroite = 0;
}

static int estEnCollision(float ax, float ay, float aw, float ah,
                           float bx, float by, float bw, float bh)
{
    if (ax + aw <= bx) return 0;
    if (ax >= bx + bw) return 0;
    if (ay + ah <= by) return 0;
    if (ay >= by + bh) return 0;
    return 1;
}

static void gererCollisionsHorizontales(JeuEtat *jeu)
{
    Joueur *j = &jeu->joueur;
    int i;
    for (i = 0; i < jeu->nb_plateformes; i++)
    {
        Plateforme *p = &jeu->plateformes[i];
        if (p->mortelle) continue;
        float px, py, pw, ph;
        getPlatformHitbox(p, &px, &py, &pw, &ph);

        if (!estEnCollision(j->x, j->y, j->largeur, j->hauteur,
                            px, py, pw, ph)) continue;
        if      (j->vx > 0) { j->x = px - j->largeur;  j->vx = 0.0f; if (j->en_dash) { j->timer_dash = 0; } }
        else if (j->vx < 0) { j->x = px + pw;          j->vx = 0.0f; if (j->en_dash) { j->timer_dash = 0; } }
    }
}

static void gererCollisionsVerticales(JeuEtat *jeu)
{
    Joueur *j = &jeu->joueur;
    int i;
    int etait_au_sol = j->au_sol;

    j->au_sol = 0;

    for (i = 0; i < jeu->nb_plateformes; i++)
    {
        Plateforme *p = &jeu->plateformes[i];
        float px, py, pw, ph;
        getPlatformHitbox(p, &px, &py, &pw, &ph);

        if (!estEnCollision(j->x, j->y, j->largeur, j->hauteur,
                            px, py, pw, ph)) continue;
        if (p->mortelle) {
            if (j->invulnerable == 0) {
                j->vies--;
                j->invulnerable = 60;
                system("aplay -q images/sounds/hurt.wav &");
                if (j->vies <= 0) { j->vivant = 0; jeu->etat = ETAT_GAME_OVER; }
            }
            continue;
        }
        if (j->vy <= 0) { j->y = py + ph; j->vy = 0.0f; j->au_sol = 1; j->sauts_restants = 1; }
        else            { j->y = py - j->hauteur;  j->vy = 0.0f; }
    }

    // Coyote Time quelques frames en + pour le saut
    if (etait_au_sol && !j->au_sol) j->coyote_timer = COYOTE_TICKS;
    else if (j->au_sol)             j->coyote_timer = 0;
}


void mettreAJourJoueur(JeuEtat *jeu)
{
    Joueur *j = &jeu->joueur;
    if (!j->vivant) return;

    if (j->en_dash) {
        j->vy = 0.0f;
        j->vx = (j->direction == DIR_DROITE) ? 15.0f : -15.0f;
        
        j->timer_dash--;
        if (j->timer_dash <= 0) {
            j->en_dash = 0;
            // Retour à vitesse normale à la fin du dash
            j->vx = (j->direction == DIR_DROITE) ? VITESSE_JOUEUR : -VITESSE_JOUEUR;
        }
    } else {
        j->vy -= (j->vy < 0) ? GRAVITE_CHUTE : GRAVITE;
        if (j->vy < -VITESSE_CHUTE_MAX) j->vy = -VITESSE_CHUTE_MAX;

        // Déplacement gauche/droite avec effet glissement
        if      (toucheDroite) { j->vx = VITESSE_JOUEUR;  j->direction = DIR_DROITE; }
        else if (toucheGauche) { j->vx = -VITESSE_JOUEUR; j->direction = DIR_GAUCHE; }
        else if (j->au_sol)    { j->vx = 0.0f; }      
        else                   { j->vx *= 0.85f; }   
    }

    j->x += j->vx;
    gererCollisionsHorizontales(jeu);

    j->y += j->vy;
    gererCollisionsVerticales(jeu);

    if (j->coyote_timer > 0) j->coyote_timer--;
    if (j->jump_buffer  > 0) j->jump_buffer--;

    if (j->jump_buffer > 0)
    {
        if (j->au_sol || j->coyote_timer > 0)
        {
            j->vy           = FORCE_SAUT;
            j->au_sol       = 0;
            j->coyote_timer = 0;
            j->jump_buffer  = 0;
            j->sauts_restants = 1;
            system("aplay -q images/sounds/jump.wav &");
        }
        else if (j->sauts_restants > 0)
        {
            j->vy           = FORCE_SAUT;
            j->jump_buffer  = 0;
            j->sauts_restants--;
            system("aplay -q images/sounds/jump.wav &");
        }
    }

    // Si le joueur tombe dans le vide, mort & respawn
    if (j->y < -200)
    {
        j->vies--;
        j->x = (jeu->spawn_x > 0.0f) ? jeu->spawn_x : 100.0f;
        j->y = (jeu->spawn_y > 0.0f) ? jeu->spawn_y : 100.0f;
        j->vx = j->vy = 0.0f;
        j->invulnerable = 60;
        j->coyote_timer = j->jump_buffer = 0;
        system("aplay -q images/sounds/hurt.wav &");
        if (j->vies <= 0) { j->vivant = 0; jeu->etat = ETAT_GAME_OVER; }
    }

    if (j->invulnerable > 0) j->invulnerable--;
    if (j->cooldown_dash > 0) j->cooldown_dash--;
}

void gererClavierJoueur(JeuEtat *jeu, char touche)
{
    if (touche == ' ' && jeu->etat == ETAT_JEU)
        jeu->joueur.jump_buffer = JUMP_BUFFER_TICKS;
    
    if ((touche == 'e' || touche == 'E') && jeu->etat == ETAT_JEU) {
        if (!jeu->joueur.en_dash && jeu->joueur.cooldown_dash <= 0) {
            jeu->joueur.en_dash = 1;
            jeu->joueur.timer_dash = 15;
            jeu->joueur.cooldown_dash = 60;
        }
    }
}

void gererClavierSpecialJoueur(JeuEtat *jeu, int touche)
{
    (void)jeu; (void)touche;
}