#include "joueur.h"
#include "objets.h"
#include "jeu.h"
#include "niveau.h"
#include "gfxlib/GfxLib.h"

static int toucheGauche = 0;
static int toucheDroite = 0;

void mettreAJourTouches(JeuEtat *jeu, int gauche, int droite)
{
    (void)jeu;
    toucheGauche = gauche;
    toucheDroite = droite;
}

void initialiserJoueur(JeuEtat *jeu)
{
    /* Position : utilise le spawn défini par le blueprint ('S').
     * spawn_x/spawn_y sont remplis par chargerNiveauDepuisBlueprint()
     * avant que initialiserJoueur() soit appelé. */
    jeu->joueur.x = (jeu->spawn_x > 0.0f) ? jeu->spawn_x : 100.0f;
    jeu->joueur.y = (jeu->spawn_y > 0.0f) ? jeu->spawn_y : 100.0f;
    jeu->joueur.vx           = 0.0f;
    jeu->joueur.vy           = 0.0f;
    jeu->joueur.direction    = DIR_DROITE;
    jeu->joueur.vies         = 3;
    jeu->joueur.pieces       = 0;
    jeu->joueur.invulnerable = 0;
    jeu->joueur.au_sol       = 0;
    jeu->joueur.vivant       = 1;
    jeu->joueur.largeur      = 48;
    jeu->joueur.hauteur      = 48;
    jeu->joueur.coyote_timer = 0;
    jeu->joueur.jump_buffer  = 0;
    toucheGauche = 0;
    toucheDroite = 0;
}

static int estEnCollision(float ax, float ay, float aw, float ah,
                           float bx, float by, float bw, float bh)
{
    if (ax + aw <= bx) return 0;
    if (ax >= bx + bw) return 0;
    if (ay + ah <= by) return 0;
    if (ay >= by + bh) return 0;
    return 1;
}

/* Résolution horizontale uniquement (après j->x += j->vx) */
static void gererCollisionsHorizontales(JeuEtat *jeu)
{
    Joueur *j = &jeu->joueur;
    int i;
    for (i = 0; i < jeu->nb_plateformes; i++)
    {
        Plateforme *p = &jeu->plateformes[i];
        if (p->mortelle) continue;
        float px, py, pw, ph;
        getPlatformHitbox(p, &px, &py, &pw, &ph);

        if (!estEnCollision(j->x, j->y, j->largeur, j->hauteur,
                            px, py, pw, ph)) continue;
        if      (j->vx > 0) { j->x = px - j->largeur;  j->vx = 0.0f; }
        else if (j->vx < 0) { j->x = px + pw;          j->vx = 0.0f; }
    }
}

/* Résolution verticale uniquement (après j->y += j->vy) */
static void gererCollisionsVerticales(JeuEtat *jeu)
{
    Joueur *j = &jeu->joueur;
    int i;
    int etait_au_sol = j->au_sol;

    j->au_sol = 0;

    for (i = 0; i < jeu->nb_plateformes; i++)
    {
        Plateforme *p = &jeu->plateformes[i];
        float px, py, pw, ph;
        getPlatformHitbox(p, &px, &py, &pw, &ph);

        if (!estEnCollision(j->x, j->y, j->largeur, j->hauteur,
                            px, py, pw, ph)) continue;
        if (p->mortelle) {
            if (j->invulnerable == 0) {
                j->vies--;
                j->invulnerable = 60;
                if (j->vies <= 0) { j->vivant = 0; jeu->etat = ETAT_GAME_OVER; }
            }
            continue;
        }
        if (j->vy <= 0) { j->y = py + ph; j->vy = 0.0f; j->au_sol = 1; }
        else            { j->y = py - j->hauteur;  j->vy = 0.0f; }
    }

    /* Coyote time */
    if (etait_au_sol && !j->au_sol) j->coyote_timer = COYOTE_TICKS;
    else if (j->au_sol)             j->coyote_timer = 0;
}


void mettreAJourJoueur(JeuEtat *jeu)
{
    Joueur *j = &jeu->joueur;
    if (!j->vivant) return;

    // 1. Gravité variable
    j->vy -= (j->vy < 0) ? GRAVITE_CHUTE : GRAVITE;
    if (j->vy < -VITESSE_CHUTE_MAX) j->vy = -VITESSE_CHUTE_MAX;

    // 2. Déplacements horizontaux
    if      (toucheDroite) { j->vx = VITESSE_JOUEUR;  j->direction = DIR_DROITE; }
    else if (toucheGauche) { j->vx = -VITESSE_JOUEUR; j->direction = DIR_GAUCHE; }
    else if (j->au_sol)    { j->vx = 0.0f; }      // Arrêt net au sol
    else                   { j->vx *= 0.85f; }    // Glissement progressif en l'air

    // 3a. Déplacement horizontal + résolution
    j->x += j->vx;
    gererCollisionsHorizontales(jeu);

    // 3b. Déplacement vertical + résolution
    j->y += j->vy;
    gererCollisionsVerticales(jeu);

    // 5. Timers
    if (j->coyote_timer > 0) j->coyote_timer--;
    if (j->jump_buffer  > 0) j->jump_buffer--;

    // 6. Saut
    if (j->jump_buffer > 0 && (j->au_sol || j->coyote_timer > 0))
    {
        j->vy           = FORCE_SAUT;
        j->au_sol       = 0;
        j->coyote_timer = 0;
        j->jump_buffer  = 0;
    }

    // 7. Mort par chute
    if (j->y < -200)
    {
        j->vies--;
        j->x = (jeu->spawn_x > 0.0f) ? jeu->spawn_x : 100.0f;
        j->y = (jeu->spawn_y > 0.0f) ? jeu->spawn_y : 100.0f;
        j->vx = j->vy = 0.0f;
        j->invulnerable = 60;
        j->coyote_timer = j->jump_buffer = 0;
        if (j->vies <= 0) { j->vivant = 0; jeu->etat = ETAT_GAME_OVER; }
    }

    // 8. Invulnérabilité
    if (j->invulnerable > 0) j->invulnerable--;

    /* La caméra est mise à jour par mettreAJourCamera() dans niveau.c */
}

void gererClavierJoueur(JeuEtat *jeu, char touche)
{
    /* Saut avec espace (en jeu uniquement) */
    if (touche == ' ' && jeu->etat == ETAT_JEU)
        jeu->joueur.jump_buffer = JUMP_BUFFER_TICKS;

    /* Note : les transitions de menu/game_over/victoire/sélection
     * sont gérées directement dans main.c (case Clavier). */
}

void gererClavierSpecialJoueur(JeuEtat *jeu, int touche)
{
    (void)jeu; (void)touche;
}