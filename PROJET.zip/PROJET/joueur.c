/*
 * joueur.c - Moteur physique et gestion du joueur
 *
 * Fonctionnalités implémentées :
 *   [OBLIGATOIRE] Déplacement gauche/droite
 *   [OBLIGATOIRE] Saut (avec détection sol)
 *   [OBLIGATOIRE] Gravité et vélocité verticale
 *   [OBLIGATOIRE] Collisions joueur/plateformes
 *   [OBLIGATOIRE] Orientation du sprite selon direction
 *   [BONUS] Double saut
 *   [BONUS] Frames d'invulnérabilité après dégâts (+ clignotement)
 *   [BONUS] Inertie horizontale
 *   [BONUS] Mort par chute hors de l'écran
 *
 * Membre 1 - Moteur physique & joueur
 */

#include <stdio.h>
#include "gfxlib/GfxLib.h"  /* Pour ToucheFleche* et toucheShiftAppuyee() */
#include "jeu.h"
#include "joueur.h"
#include "niveau.h"   /* Pour accéder aux plateformes */

/* =========================================================
 *  Variables internes (privées à ce fichier)
 * ========================================================= */

/* États des touches maintenues enfoncées */
static int touche_gauche_enfoncee  = 0;
static int touche_droite_enfoncee  = 0;
static int touche_course_enfoncee  = 0; /* Shift = courir */

/* Compteur de sauts (0 = au sol, 1 = premier saut, 2 = double saut) */
static int nb_sauts_effectues = 0;

/* =========================================================
 *  initialiseJoueur()
 *
 *  Replace le joueur à sa position de départ pour le niveau
 *  courant, réinitialise ses vitesses et états.
 * ========================================================= */
void initialiseJoueur(void)
{
    Joueur *j = &jeu.joueur;

    /* Position de départ : bas-gauche de l'écran, légèrement en hauteur */
    j->x           = 100.0f;
    j->y           = 200.0f;

    /* Vitesses nulles au départ */
    j->vx          = 0.0f;
    j->vy          = 0.0f;

    /* Regarde vers la droite */
    j->direction   = 1;

    /* Vies : on ne réinitialise les vies QUE pour un nouveau jeu (pas pour relancer) */
    /* Elles sont gérées dans main.c avant d'appeler initialiseJoueur */

    /* Pas invulnérable, vivant, pas de clé */
    j->invulnerable = 0;
    j->vivant       = 1;
    j->au_sol       = 0;
    j->a_cle        = 0;

    /* Réinitialise les touches */
    touche_gauche_enfoncee = 0;
    touche_droite_enfoncee = 0;
    touche_course_enfoncee = 0;
    nb_sauts_effectues     = 0;
}

/* =========================================================
 *  detecteCollisionPlateforme()
 *
 *  Vérifie si le joueur chevauche une plateforme donnée.
 *  Renvoie 1 si collision, 0 sinon.
 *
 *  On utilise la méthode AABB (Axis-Aligned Bounding Box) :
 *  deux rectangles se chevauchent si et seulement si leurs
 *  intervalles se croisent sur les deux axes.
 * ========================================================= */
static int detecteCollisionPlateforme(Plateforme *p)
{
    Joueur *j = &jeu.joueur;

    /* Le joueur est un rectangle de TAILLE_JOUEUR_L x TAILLE_JOUEUR_H
     * dont le coin bas-gauche est (j->x, j->y).
     * La plateforme est un rectangle dont le coin bas-gauche est (p->x, p->y). */

    float joueur_droite    = j->x + TAILLE_JOUEUR_L;
    float joueur_haut      = j->y + TAILLE_JOUEUR_H;
    float plateforme_droite = p->x + p->largeur;
    float plateforme_haut  = p->y + p->hauteur;

    /* Chevauchement horizontal ET vertical */
    if (j->x < plateforme_droite &&
        joueur_droite > p->x &&
        j->y < plateforme_haut &&
        joueur_haut > p->y)
    {
        return 1; /* Collision détectée */
    }
    return 0;
}

/* =========================================================
 *  gereCollisionsPlateformes()
 *
 *  Parcourt toutes les plateformes et résout les collisions.
 *  La résolution se fait par "correction minimale" :
 *  on pousse le joueur dans la direction où il s'est le moins
 *  enfoncé dans la plateforme.
 * ========================================================= */
static void gereCollisionsPlateformes(void)
{
    int i;
    Joueur *j = &jeu.joueur;

    j->au_sol = 0; /* On suppose qu'il est en l'air jusqu'à preuve du contraire */

    for (i = 0; i < NB_PLATEFORMES; i++)
    {
        Plateforme *p = &jeu.plateformes[i];

        /* Ignorer les plateformes inactives */
        if (!p->active) continue;

        /* Vérifier la collision */
        if (!detecteCollisionPlateforme(p)) continue;

        /* --- Le joueur est en collision avec p --- */

        /* Si la plateforme est mortelle (lave, précipice), le joueur meurt */
        if (p->mortelle)
        {
            j->vivant = 0;
            return;
        }

        /* Calculer le chevauchement de chaque côté */
        float chevauch_gauche  = (j->x + TAILLE_JOUEUR_L) - p->x;
        float chevauch_droite  = (p->x + p->largeur) - j->x;
        float chevauch_bas     = (j->y + TAILLE_JOUEUR_H) - p->y;
        float chevauch_haut    = (p->y + p->hauteur) - j->y;

        /* Trouver le plus petit chevauchement → direction de correction */
        float min_chevauch = chevauch_gauche;
        if (chevauch_droite < min_chevauch) min_chevauch = chevauch_droite;
        if (chevauch_bas    < min_chevauch) min_chevauch = chevauch_bas;
        if (chevauch_haut   < min_chevauch) min_chevauch = chevauch_haut;

        /* Appliquer la correction */
        if (min_chevauch == chevauch_bas)
        {
            /* Le joueur est posé dessus (atterrit sur la plateforme) */
            j->y    = p->y - TAILLE_JOUEUR_H;
            j->vy   = 0.0f;
            j->au_sol = 1;
            nb_sauts_effectues = 0; /* Reset : peut sauter à nouveau */
        }
        else if (min_chevauch == chevauch_haut)
        {
            /* Le joueur a sauté et tape le dessous */
            j->y  = p->y + p->hauteur;
            j->vy = -j->vy * 0.3f; /* Rebond léger */
        }
        else if (min_chevauch == chevauch_gauche)
        {
            /* Bloqué à gauche */
            j->x  = p->x - TAILLE_JOUEUR_L;
            j->vx = 0.0f;
        }
        else
        {
            /* Bloqué à droite */
            j->x  = p->x + p->largeur;
            j->vx = 0.0f;
        }
    }
}

/* =========================================================
 *  miseAJourJoueur()
 *
 *  Appelée à chaque frame par main.c.
 *  Ordre des opérations :
 *    1. Appliquer la gravité
 *    2. Déplacer selon les touches enfoncées
 *    3. Mettre à jour la position
 *    4. Résoudre les collisions avec les plateformes
 *    5. Vérifier les limites de l'écran / chute
 *    6. Décrémenter le timer d'invulnérabilité
 * ========================================================= */
void miseAJourJoueur(void)
{
    Joueur *j = &jeu.joueur;

    if (!j->vivant) return;

    /* --- 1. Gravité --- */
    /* On accélère vers le bas à chaque frame */
    j->vy -= GRAVITE;

    /* --- 2. Déplacement horizontal --- */
    float vitesse_cible = 0.0f;

    if (touche_gauche_enfoncee)
    {
        vitesse_cible   = touche_course_enfoncee ? -VITESSE_COURSE : -VITESSE_JOUEUR;
        j->direction    = -1;
    }
    else if (touche_droite_enfoncee)
    {
        vitesse_cible   = touche_course_enfoncee ? VITESSE_COURSE : VITESSE_JOUEUR;
        j->direction    = 1;
    }

    /* Inertie : on glisse progressivement vers la vitesse cible */
    /* INERTIE = 0.75 → on garde 75% de l'ancienne vitesse + 25% de la nouvelle */
    j->vx = j->vx * INERTIE + vitesse_cible * (1.0f - INERTIE);

    /* Bloquer une vitesse trop faible (évite le glissement infini) */
    if (j->vx > -0.1f && j->vx < 0.1f) j->vx = 0.0f;

    /* --- 3. Mise à jour de la position --- */
    j->x += j->vx;
    j->y += j->vy;

    /* --- 4. Collisions avec les plateformes --- */
    gereCollisionsPlateformes();

    /* --- 5. Vérifications hors-limites --- */

    /* Le joueur ne peut pas sortir à gauche de la caméra */
    if (j->x < jeu.camera.x)
    {
        j->x  = jeu.camera.x;
        j->vx = 0.0f;
    }

    /* Chute dans un précipice (y < 0 = sous le sol du monde) */
    if (j->y < -100.0f)
    {
        j->vivant = 0; /* Mort par chute */
    }

    /* --- 6. Timer d'invulnérabilité --- */
    if (j->invulnerable > 0)
    {
        j->invulnerable--;
    }
}

/* =========================================================
 *  gereEntreeJoueur()
 *
 *  Reçoit les entrées clavier depuis main.c et met à jour
 *  les flags de touches enfoncées.
 *
 *  Touches :
 *    Flèche gauche / 'q' → aller à gauche
 *    Flèche droite / 'd' → aller à droite
 *    Flèche haut / ' ' / 'z' → sauter (ou double sauter)
 *    Shift → courir (bonus)
 *    'a' → attaque (appel de attaqueJoueur dans ennemis.c)
 * ========================================================= */
void gereEntreeJoueur(int touche_speciale, char touche_normale)
{
    Joueur *j = &jeu.joueur;
    if (!j->vivant) return;

    /* --- Touches spéciales (flèches) --- */
    if (touche_speciale == ToucheFlecheGauche)
    {
        touche_gauche_enfoncee = 1;
        touche_droite_enfoncee = 0;
    }
    else if (touche_speciale == ToucheFlecheDroite)
    {
        touche_droite_enfoncee = 1;
        touche_gauche_enfoncee = 0;
    }
    else if (touche_speciale == ToucheFlecheHaut)
    {
        /* Sauter */
        if (nb_sauts_effectues == 0)
        {
            /* Premier saut : uniquement si au sol */
            if (j->au_sol)
            {
                j->vy = FORCE_SAUT;
                j->au_sol = 0;
                nb_sauts_effectues = 1;
            }
        }
        else if (nb_sauts_effectues == 1)
        {
            /* Double saut (bonus) : dans les airs */
            j->vy = FORCE_DOUBLE_SAUT;
            nb_sauts_effectues = 2;
        }
    }

    /* --- Touches normales (lettres) --- */
    switch (touche_normale)
    {
        case 'q':
        case 'Q':
            touche_gauche_enfoncee = 1;
            touche_droite_enfoncee = 0;
            j->direction = -1;
            break;

        case 'd':
        case 'D':
            touche_droite_enfoncee = 1;
            touche_gauche_enfoncee = 0;
            j->direction = 1;
            break;

        case 'z':
        case 'Z':
        case ' ':
            /* Sauter avec Z ou Espace */
            if (nb_sauts_effectues == 0 && j->au_sol)
            {
                j->vy = FORCE_SAUT;
                j->au_sol = 0;
                nb_sauts_effectues = 1;
            }
            else if (nb_sauts_effectues == 1)
            {
                j->vy = FORCE_DOUBLE_SAUT;
                nb_sauts_effectues = 2;
            }
            break;

        /* Relâchement des touches de déplacement */
        /* GfxLib n'envoie pas d'événement "relâché", on simule avec des
         * touches négatives : le module main appellera gereRelacheClavier */
        default:
            break;
    }

    /* Courir si Shift enfoncé */
    touche_course_enfoncee = toucheShiftAppuyee() ? 1 : 0;
}

/* =========================================================
 *  gereRelacheJoueur()
 *
 *  GfxLib n'a pas d'événement "touche relâchée", mais on peut
 *  simuler en remettant les flags à 0 quand la touche n'est
 *  plus dans l'événement Temporisation (voir main.c).
 *
 *  Ici on expose une version simple : main.c peut appeler
 *  cette fonction avec les mêmes codes pour "stopper".
 *
 *  Note pédagogique : une vraie gestion key-up nécessiterait
 *  un tableau de touches actives — simplifié ici.
 * ========================================================= */
void gereRelacheJoueur(int touche_speciale)
{
    if (touche_speciale == ToucheFlecheGauche)
        touche_gauche_enfoncee = 0;
    else if (touche_speciale == ToucheFlecheDroite)
        touche_droite_enfoncee = 0;
}

/* =========================================================
 *  blesseJoueur()
 *
 *  Inflige des dégâts non létaux au joueur.
 *  Si le joueur est invulnérable, ne fait rien.
 *  Sinon : réduit les vies et démarre l'invulnérabilité.
 *  Si plus de vies → marque vivant=0.
 * ========================================================= */
void blesseJoueur(void)
{
    Joueur *j = &jeu.joueur;

    if (j->invulnerable > 0) return; /* Immune */
    if (!j->vivant) return;

    j->vies--;

    if (j->vies <= 0)
    {
        j->vivant = 0; /* Mort */
    }
    else
    {
        /* Activer les frames d'invulnérabilité */
        j->invulnerable = DUREE_INVULNERABLE;

        /* Léger rebond vers le haut lors d'un dégât */
        j->vy = FORCE_SAUT * 0.5f;
    }
}

/* =========================================================
 *  joueurEnChute()
 *
 *  Renvoie 1 si le joueur descend (vy < 0) et n'est pas au sol.
 *  Utilisé par ennemi.c pour détecter si on saute dessus.
 * ========================================================= */
int joueurEnChute(void)
{
    return (!jeu.joueur.au_sol && jeu.joueur.vy < 0.0f) ? 1 : 0;
}
