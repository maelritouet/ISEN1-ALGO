# 🎤 Plan de Soutenance (4-5 Minutes)

Pour tenir sur 4 à 5 minutes à cinq personnes, chaque intervenant aura environ **45 à 60 secondes** de temps de parole. L'objectif est d'être percutant, visuel, et de montrer immédiatement que les problèmes techniques ont été maîtrisés.

---

## Slide 1 : Titre & Concept (Tout le groupe)
* **Visuel :** Écran titre du jeu avec le menu principal + vos 5 noms.
* **Discours (15 sec) :** Présentation du jeu. "Nous vous présentons notre Platformer Medieval Fantasy. Inspiré des grands classiques, nous avons voulu coder un moteur fluide et robuste en C avec GfxLib."

---

## Slide 2 : Démonstration Rapide (Le Gameplay)
* **Visuel :** Un court GIF (ou succession de 3 screenshots) montrant le joueur courir, dasher, sauter sur un ennemi, et ramasser une pièce.
* **Discours (30 sec) :** "Notre jeu propose 9 niveaux complets générés procéduralement, une physique avancée (dash, double saut) et un écosystème d'ennemis interactifs."

---

## Slide 3 : Architecture Globale
* **Visuel :** Un schéma simplifié (boîtes et flèches) de la Boucle de Jeu (Input -> Physique -> Affichage).
* **Discours (30 sec - Mael) :** "Le cœur de notre moteur tourne à 60 FPS constants. Nous l'avons architecturé autour d'une machine à état centralisée (`JeuEtat`), séparant rigoureusement la donnée (Blueprints), la logique (Physique), et le rendu graphique."

---

## 🚧 Slide 4 : Défis Techniques & Solutions (Le cœur de la notation)

*C'est ici que chaque membre prend la parole 45 secondes pour expliquer SA vraie difficulté.*

### 1. Mael Ritouet (Lead Programmer & Moteur)
* **Problème 1 : Input Lag & Répétition OS.** Par défaut, l'OS gère le clavier avec un délai de répétition (quand on maintient une touche, il y a une pause avant la répétition). En l'air, cela empêchait le joueur de changer de direction fluidement (Air-strafing).
* **Solution :** Bypass total en interrogeant directement le serveur X11 via `XQueryKeymap`. Cela lit physiquement l'état des switchs du clavier sous forme de masque binaire, garantissant une réactivité au pixel près à 60 FPS.
* **Problème 2 : Transparence ARVB et Bug GfxLib.** Les sprites BMP avaient un fond Magenta (255, 0, 255) qui devait être invisible, mais GfxLib inversait parfois les canaux Rouge et Bleu en mémoire, et gérait mal l'Alpha.
* **Solution :** J'ai développé un algorithme de conversion bit-à-bit. Lors du chargement du fichier, on itère sur chaque pixel : on rétablit l'ordre RGB, on détecte le Magenta, et on manipule manuellement la mémoire pour ne pas dessiner ces pixels lors du rendu (création d'un "Color Keying" maison).

### 2. Camarade 5 (Génération des Niveaux)
* **Problème : Monotonie visuelle et Bug Parallaxe.** Lire une lettre 'R' dans le blueprint et afficher toujours la même tuile donnait un effet "grille" très artificiel. De plus, le scrolling parallaxe créait des "vides noirs" en bord de map.
* **Solution :** 
  - *Smart Tiling :* Lors du parsing du tableau 2D, l'algorithme tire un nombre pseudo-aléatoire pour choisir entre 3 ou 4 variantes de blocs de pierre pour la même lettre 'R', cassant la monotonie.
  - *Clamp Caméra :* Un algorithme de bornage (`clamp`) mathématique empêche la caméra de dépasser `0` à gauche et `LARGEUR_MAX` à droite, même avec le décalage de vitesse du fond.

### 3. Camarade 4 (Comportement Ennemis)
* **Problème : Synchro des Animations.** La boucle de jeu tournant à 60 Ticks Par Seconde, changer de frame d'animation à chaque tick faisait courir les ennemis à une vitesse stroboscopique (l'animation complète se finissait en 0.1 seconde).
* **Solution :** Décorrélation de la logique et du rendu. J'ai ajouté un compteur local à chaque ennemi. On utilise l'opérateur modulo (`if (compteur % 5 == 0)`) pour ne changer d'image visuelle que tous les 5 ticks de physique. Les monstres tournent ainsi visuellement à 12 FPS tout en se déplaçant avec une physique à 60 FPS.

### 4. Camarade 3 (Menu, Interface & Audio)
* **Problème : Audio Bloquant.** Utiliser une fonction C classique ou GfxLib pour lire le bruitage d'une pièce d'or figeait le jeu (freeze de l'écran) pendant toute la durée du son (0.5 sec).
* **Solution :** Recours à la programmation système asynchrone. J'ai utilisé l'appel système `system("aplay sound.wav &")` pour créer un processus enfant (fork) géré par Linux en arrière-plan. Le jeu continue de tourner pendant que l'OS s'occupe de l'audio de manière totalement détachée.

### 5. Camarade 2 (Objets & Score)
* **Problème : Frustration des Hitboxes.** Avec les boîtes englobantes classiques (AABB), si le pixel de l'épée du joueur touche le pixel d'une pièce, la pièce n'était pas collectée. C'était "trop" précis et punitif.
* **Solution :** Ajustement asymétrique des algorithmes de collision. La "Hitbox" logique de collecte est artificiellement gonflée de 10 pixels par rapport au sprite visuel affiché. J'ai rajouté un "offset" de tolérance mathématique dans le calcul (`x_joueur < x_piece + largeur_piece + offset`). Cela crée un gameplay généreux et agréable ("Coyote Time" de collision).

---

## Slide 5 : Bilan et Conclusion
* **Visuel :** L'écran de Victoire du jeu / Affichage des Meilleurs Temps.
* **Discours (30 sec) :** "En conclusion, ce projet nous a appris à manipuler les structures dynamiques en C, la gestion de la mémoire (pointeurs sur bitmaps), et le travail collaboratif sur une architecture modulaire. Avez-vous des questions ?"
