/*
 * ennemi.c - Gestion des ennemis (déplacement, IA, mort)
 *
 * Fonctionnalités implémentées :
 *   [OBLIGATOIRE] Ennemis fixes et se déplaçant latéralement
 *   [OBLIGATOIRE] Ennemis orientés selon leur direction
 *   [OBLIGATOIRE] Joueur peut tuer en sautant dessus
 *   [OBLIGATOIRE] Ennemis attaquent le joueur au contact
 *   [OBLIGATOIRE] Ennemis essaient d'atteindre le joueur s'il est proche
 *   [BONUS]       Certains ennemis peuvent sauter (squelette)
 *   [BONUS]       Difficulté croissante selon le niveau
 *
 * IA simple :
 *   - Patrouille : va et vient entre deux points
 *   - Poursuite : fonce vers le joueur si assez proche
 *   - Retournement : demi-tour au bord d'une plateforme
 *
 * Membre 3 - Ennemis
 */

#include <stdio.h>
#include <math.h>   /* Pour fabsf() (valeur absolue float) */
#include "jeu.h"
#include "ennemi.h"
#include "joueur.h" /* Pour blesseJoueur() et joueurEnChute() */
#include "niveau.h"

/* =========================================================
 *  Données de spawn des ennemis par niveau
 *
 *  Format : { x, y, vx, direction, vivant, attaque, type }
 *  On met le nombre réel d'ennemis par niveau ici.
 * ========================================================= */

static Ennemi spawn_niveau1[NB_ENNEMIS] = {
    { 300.0f,  30.0f, VITESSE_GOBELIN,   1,  1, 0, TYPE_GOBELIN   },
    { 600.0f,  30.0f, VITESSE_GOBELIN,  -1,  1, 0, TYPE_GOBELIN   },
    { 1000.0f, 30.0f, VITESSE_GOBELIN,   1,  1, 0, TYPE_GOBELIN   },
    { 1600.0f, 30.0f, VITESSE_SQUELETTE, 1,  1, 0, TYPE_SQUELETTE },
    { 2000.0f, 30.0f, VITESSE_GOBELIN,  -1,  1, 0, TYPE_GOBELIN   },
    { 2500.0f, 30.0f, VITESSE_SQUELETTE,-1,  1, 0, TYPE_SQUELETTE },
    { 2900.0f, 30.0f, VITESSE_GOBELIN,   1,  1, 0, TYPE_GOBELIN   },
    { 3200.0f, 30.0f, VITESSE_GOBELIN,  -1,  1, 0, TYPE_GOBELIN   },
};

static Ennemi spawn_niveau2[NB_ENNEMIS] = {
    { 200.0f,  30.0f, VITESSE_SQUELETTE, 1, 1, 0, TYPE_SQUELETTE },
    { 550.0f,  30.0f, VITESSE_GOBELIN,  -1, 1, 0, TYPE_GOBELIN   },
    { 950.0f,  30.0f, VITESSE_SQUELETTE, 1, 1, 0, TYPE_SQUELETTE },
    { 1300.0f, 30.0f, VITESSE_SQUELETTE,-1, 1, 0, TYPE_SQUELETTE },
    { 1800.0f, 30.0f, VITESSE_GOBELIN,   1, 1, 0, TYPE_GOBELIN   },
    { 2200.0f, 30.0f, VITESSE_SQUELETTE, 1, 1, 0, TYPE_SQUELETTE },
    { 2700.0f, 30.0f, VITESSE_SQUELETTE,-1, 1, 0, TYPE_SQUELETTE },
    { 3200.0f, 30.0f, VITESSE_SQUELETTE, 1, 1, 0, TYPE_SQUELETTE },
};

static Ennemi spawn_niveau3[NB_ENNEMIS] = {
    { 150.0f,  30.0f, VITESSE_SQUELETTE, 1, 1, 0, TYPE_SQUELETTE },
    { 600.0f,  30.0f, VITESSE_SQUELETTE,-1, 1, 0, TYPE_SQUELETTE },
    { 1000.0f, 30.0f, VITESSE_SQUELETTE, 1, 1, 0, TYPE_SQUELETTE },
    { 1400.0f, 30.0f, VITESSE_SQUELETTE,-1, 1, 0, TYPE_SQUELETTE },
    { 1900.0f, 30.0f, VITESSE_SQUELETTE, 1, 1, 0, TYPE_SQUELETTE },
    { 2400.0f, 30.0f, VITESSE_SQUELETTE,-1, 1, 0, TYPE_SQUELETTE },
    { 2800.0f, 30.0f, VITESSE_SQUELETTE, 1, 1, 0, TYPE_SQUELETTE },
    /* Boss au fond du donjon */
    { 3300.0f, 30.0f, VITESSE_BOSS,     -1, 1, 0, TYPE_BOSS      },
};

/* =========================================================
 *  Limites de patrouille
 *  Chaque ennemi fait demi-tour à ±PORTEE_PATROUILLE de sa
 *  position de départ.
 * ========================================================= */
static float x_depart[NB_ENNEMIS];  /* Position X initiale de chaque ennemi */

#define PORTEE_PATROUILLE  150.0f   /* Pixels de chaque côté */

/* Timer de saut pour les squelettes */
static int timer_saut[NB_ENNEMIS];

/* =========================================================
 *  initialiseEnnemis()
 * ========================================================= */
void initialiseEnnemis(void)
{
    int i;
    Ennemi *source;

    switch (jeu.niveau_actuel)
    {
        case 1: source = spawn_niveau1; break;
        case 2: source = spawn_niveau2; break;
        case 3: source = spawn_niveau3; break;
        default: source = spawn_niveau1; break;
    }

    for (i = 0; i < NB_ENNEMIS; i++)
    {
        jeu.ennemis[i] = source[i];
        x_depart[i]    = source[i].x;
        timer_saut[i]  = 60 + i * 20; /* Timer décalé pour éviter les sauts synchronisés */
    }
}

/* =========================================================
 *  distanceJoueurEnnemi()
 *
 *  Calcule la distance horizontale entre le joueur et l'ennemi i.
 *  On utilise fabsf() pour la valeur absolue sur les floats.
 * ========================================================= */
static float distanceJoueurEnnemi(int i)
{
    float dx = jeu.joueur.x - jeu.ennemis[i].x;
    return fabsf(dx); /* Valeur absolue */
}

/* =========================================================
 *  collisionEnnemiJoueur()
 *
 *  Détecte si l'ennemi i chevauche le joueur (AABB).
 *  Renvoie 1 = collision, 0 = pas de collision.
 * ========================================================= */
int collisionEnnemiJoueur(int i)
{
    Ennemi *e = &jeu.ennemis[i];
    Joueur *j = &jeu.joueur;

    float e_droite  = e->x + TAILLE_ENNEMI_L;
    float e_haut    = e->y + TAILLE_ENNEMI_H;
    float j_droite  = j->x + TAILLE_JOUEUR_L;
    float j_haut    = j->y + TAILLE_JOUEUR_H;

    return (j->x < e_droite && j_droite > e->x &&
            j->y < e_haut   && j_haut   > e->y) ? 1 : 0;
}

/* =========================================================
 *  ennemiToucheUnMur()
 *
 *  Renvoie 1 si l'ennemi est sorti de sa zone de patrouille
 *  ou sur le bord d'une plateforme (pour faire demi-tour).
 * ========================================================= */
static int ennemiHorsZone(int i)
{
    Ennemi *e = &jeu.ennemis[i];

    /* Demi-tour aux limites de patrouille */
    if (e->x < x_depart[i] - PORTEE_PATROUILLE) return 1;
    if (e->x > x_depart[i] + PORTEE_PATROUILLE) return 1;

    /* Ne pas tomber dans le vide : vérifier si le sol existe devant */
    /* (Simplification : on vérifie si x est dans le monde) */
    if (e->x < 10.0f || e->x > LARGEUR_NIVEAU - TAILLE_ENNEMI_L - 10.0f) return 1;

    return 0;
}

/* =========================================================
 *  miseAJourEnnemi()
 *
 *  Met à jour un ennemi individuel.
 *  IA en deux modes :
 *    - PATROUILLE : va et vient dans sa zone si joueur loin
 *    - POURSUITE  : fonce vers le joueur si joueur proche
 * ========================================================= */
static void miseAJourEnnemi(int i)
{
    Ennemi *e = &jeu.ennemis[i];
    Joueur *j = &jeu.joueur;

    if (!e->vivant) return;

    float dist = distanceJoueurEnnemi(i);

    /* ---- Mode IA ---- */
    if (dist < DIST_ATTAQUE)
    {
        /* Très proche : mode ATTAQUE (se rapproche agressivement) */
        e->attaque = 1;
        /* Fonce vers le joueur */
        if (j->x < e->x)
        {
            e->vx       = -VITESSE_GOBELIN * 2.0f;
            e->direction = -1;
        }
        else
        {
            e->vx       = VITESSE_GOBELIN * 2.0f;
            e->direction = 1;
        }
    }
    else if (dist < DIST_ACTIVATION)
    {
        /* Proche : POURSUITE lente vers le joueur */
        e->attaque = 0;
        float vitesse = (e->type == TYPE_BOSS) ? VITESSE_BOSS
                      : (e->type == TYPE_SQUELETTE) ? VITESSE_SQUELETTE
                      : VITESSE_GOBELIN;
        if (j->x < e->x)
        {
            e->vx       = -vitesse;
            e->direction = -1;
        }
        else
        {
            e->vx       = vitesse;
            e->direction = 1;
        }
    }
    else
    {
        /* Loin : PATROUILLE */
        e->attaque = 0;
        float vitesse = (e->type == TYPE_BOSS) ? VITESSE_BOSS
                      : (e->type == TYPE_SQUELETTE) ? VITESSE_SQUELETTE
                      : VITESSE_GOBELIN;

        /* Demi-tour si hors zone */
        if (ennemiHorsZone(i))
        {
            e->vx       = -e->vx;
            e->direction = -e->direction;
        }

        /* S'assurer que la vitesse reste correcte en patrouille */
        if (e->vx > 0) { e->vx = vitesse; e->direction = 1; }
        else            { e->vx = -vitesse; e->direction = -1; }
    }

    /* ---- Bonus : saut du squelette ---- */
    if (e->type == TYPE_SQUELETTE && dist < DIST_ACTIVATION)
    {
        timer_saut[i]--;
        if (timer_saut[i] <= 0)
        {
            /* Sauter par-dessus un obstacle potentiel */
            e->y += FORCE_SAUT * 0.8f; /* Saut simplifié (pas de gravité ennemi) */
            timer_saut[i] = 120; /* Prochain saut dans ~2 secondes */
        }
    }

    /* ---- Déplacement ---- */
    e->x += e->vx;

    /* ---- Collision avec le joueur ---- */
    if (collisionEnnemiJoueur(i))
    {
        /* Vérifier si le joueur SAUTE sur l'ennemi (tombe d'en haut) */
        int joueur_au_dessus = (j->y + TAILLE_JOUEUR_H * 0.3f > e->y + TAILLE_ENNEMI_H * 0.8f);
        int joueur_tombe     = joueurEnChute();

        if (joueur_au_dessus && joueur_tombe)
        {
            /* Le joueur saute dessus → ennemi mort */
            e->vivant  = 0;
            e->attaque = 0;
            /* Rebond vers le haut du joueur */
            jeu.joueur.vy = FORCE_SAUT * 0.7f;
            /* Points bonus */
            jeu.score += (e->type == TYPE_BOSS) ? 500 : 100;
            printf("[Ennemi] Ennemi %d occis (saut dessus), score=%d\n", i, jeu.score);
        }
        else
        {
            /* Contact latéral → le joueur prend des dégâts */
            blesseJoueur();
        }
    }
}

/* =========================================================
 *  miseAJourEnnemis()
 *
 *  Appelée chaque frame par main.c.
 *  Met à jour tous les ennemis vivants.
 * ========================================================= */
void miseAJourEnnemis(void)
{
    int i;
    for (i = 0; i < NB_ENNEMIS; i++)
    {
        miseAJourEnnemi(i);
    }
}
