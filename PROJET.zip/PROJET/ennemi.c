#include <math.h>
#include "ennemi.h"
#include "jeu.h"

// ============================================================
//  ennemi.c — Module ennemis (Membre 3)
//
//  Comportement :
//  - Patrouille horizontale sur une plateforme
//  - Demi-tour au bord de plateforme ou contre un mur
//  - Mort si le joueur lui saute sur la tête
//  - Joueur perd une vie au contact (sauf invulnérable)
//
//  À l'oral : "Chaque ennemi se déplace horizontalement.
//  À chaque tick on vérifie s'il y a encore du sol devant
//  lui — si non, il fait demi-tour. Même chose s'il touche
//  un mur. Pour la mort, on teste si le joueur arrive par
//  le dessus avec une vitesse négative."
// ============================================================

// ------------------------------------------------------------
//  initialiserEnnemis — Place les ennemis dans le niveau
// ------------------------------------------------------------
void initialiserEnnemis(JeuEtat *jeu)
{
    int n = 0;

    // Ennemi 0 — sur le sol, zone de départ
    jeu->ennemis[n].x         = 350.0f;
    jeu->ennemis[n].y         = 100.0f;
    jeu->ennemis[n].vx        = 2.0f;
    jeu->ennemis[n].vx_base   = 2.0f;
    jeu->ennemis[n].direction = DIR_DROITE;
    jeu->ennemis[n].vivant    = 1;
    jeu->ennemis[n].attaque   = 0;
    jeu->ennemis[n].en_charge = 0;
    jeu->ennemis[n].largeur   = 40;
    jeu->ennemis[n].hauteur   = 40;
    n++;

    // Ennemi 1 — sur une plateforme en hauteur
    jeu->ennemis[n].x         = 980.0f;
    jeu->ennemis[n].y         = 220.0f;
    jeu->ennemis[n].vx        = 1.5f;
    jeu->ennemis[n].vx_base   = 1.5f;
    jeu->ennemis[n].direction = DIR_GAUCHE;
    jeu->ennemis[n].vivant    = 1;
    jeu->ennemis[n].attaque   = 0;
    jeu->ennemis[n].en_charge = 0;
    jeu->ennemis[n].largeur   = 40;
    jeu->ennemis[n].hauteur   = 40;
    n++;

    // Ennemi 2 — sur le sol après le premier précipice
    jeu->ennemis[n].x         = 1050.0f;
    jeu->ennemis[n].y         = 100.0f;
    jeu->ennemis[n].vx        = 2.5f;
    jeu->ennemis[n].vx_base   = 2.5f;
    jeu->ennemis[n].direction = DIR_DROITE;
    jeu->ennemis[n].vivant    = 1;
    jeu->ennemis[n].attaque   = 0;
    jeu->ennemis[n].en_charge = 0;
    jeu->ennemis[n].largeur   = 40;
    jeu->ennemis[n].hauteur   = 40;
    n++;

    // Ennemi 3 — gardien de la zone finale
    jeu->ennemis[n].x         = 2200.0f;
    jeu->ennemis[n].y         = 100.0f;
    jeu->ennemis[n].vx        = 3.0f;
    jeu->ennemis[n].vx_base   = 3.0f;
    jeu->ennemis[n].direction = DIR_DROITE;
    jeu->ennemis[n].vivant    = 1;
    jeu->ennemis[n].attaque   = 0;
    jeu->ennemis[n].en_charge = 0;
    jeu->ennemis[n].largeur   = 40;
    jeu->ennemis[n].hauteur   = 40;
    n++;

    jeu->nb_ennemis = n;
}

// ------------------------------------------------------------
//  aSolDevant — Vérifie s'il y a une plateforme sous le
//  prochain pas de l'ennemi (pour détecter les bords)
//
//  Principe : on teste un point juste devant et juste sous
//  l'ennemi. S'il n'y a pas de plateforme là → bord détecté.
// ------------------------------------------------------------
static int aSolDevant(JeuEtat *jeu, Ennemi *e)
{
    int i;

    // Point à tester : devant l'ennemi, au niveau de ses pieds
    float testX;
    if (e->direction == DIR_DROITE)
        testX = e->x + e->largeur + 2; // 2px devant le bord droit
    else
        testX = e->x - 2;              // 2px devant le bord gauche

    float testY = e->y - 2; // Juste sous les pieds

    for (i = 0; i < jeu->nb_plateformes; i++)
    {
        Plateforme *p = &jeu->plateformes[i];
        if (p->mortelle) continue;

        // Est-ce que le point testX/testY est au-dessus de cette plateforme ?
        if (testX >= p->x && testX <= p->x + p->largeur &&
            testY >= p->y && testY <= p->y + p->hauteur)
            return 1; // Il y a du sol devant
    }
    return 0; // Pas de sol → bord de plateforme
}

// ------------------------------------------------------------
//  estContreMur — Vérifie si l'ennemi touche un mur
// ------------------------------------------------------------
static int estContreMur(JeuEtat *jeu, Ennemi *e)
{
    int i;
    for (i = 0; i < jeu->nb_plateformes; i++)
    {
        Plateforme *p = &jeu->plateformes[i];
        if (p->mortelle) continue;

        // Collision horizontale : l'ennemi chevauche-t-il la plateforme en X ?
        int chevaucheY = (e->y + e->hauteur > p->y) && (e->y < p->y + p->hauteur);
        if (!chevaucheY) continue;

        if (e->direction == DIR_DROITE)
        {
            if (e->x + e->largeur >= p->x && e->x < p->x)
                return 1; // Mur à droite
        }
        else
        {
            if (e->x <= p->x + p->largeur && e->x + e->largeur > p->x + p->largeur)
                return 1; // Mur à gauche
        }
    }
    return 0;
}

// ------------------------------------------------------------
//  gererContactJoueurEnnemi — Détecte si le joueur touche
//  un ennemi, et détermine ce qui se passe :
//  - Joueur arrive par le dessus (vy < 0) → ennemi meurt
//  - Joueur touche par le côté ou dessous → joueur perd une vie
// ------------------------------------------------------------
static void gererContactJoueurEnnemi(JeuEtat *jeu, Ennemi *e)
{
    Joueur *j = &jeu->joueur;

    // Test de collision AABB entre joueur et ennemi
    int collisionX = (j->x + j->largeur > e->x) && (j->x < e->x + e->largeur);
    int collisionY = (j->y + j->hauteur > e->y) && (j->y < e->y + e->hauteur);

    if (!collisionX || !collisionY) return; // Pas de contact

    /* Le joueur arrive-t-il par le dessus (stomp) ?
     *
     * Deux conditions nécessaires :
     *  1. Le joueur descend (vy < 0) — exclut les contacts au sol où vy ≈ -0.5
     *     On seuille à -1 pour filtrer le bruit de gravité au sol.
     *  2. Les pieds du joueur (j->y, axe Y vers le haut) se trouvent
     *     près du sommet de l'ennemi (e->y + e->hauteur).
     *     Tolérance de 12px pour absorber la vitesse de chute.
     *
     * Quand le joueur touche par le côté, ses pieds sont bien plus bas
     * que le sommet de l'ennemi → condition 2 fausse → pas de stomp.
     */
    float sommetEnnemi = e->y + e->hauteur;
    int parLeDessus = (j->vy < -1.0f) &&
                      (j->y >= sommetEnnemi - 12.0f);

    if (parLeDessus)
    {
        // L'ennemi meurt
        e->vivant = 0;
        // Petit rebond du joueur vers le haut (feel satisfaisant)
        j->vy = 8.0f;
    }
    else
    {
        // Le joueur est touché par le côté
        if (j->invulnerable == 0)
        {
            j->vies--;
            j->invulnerable = 90; // 1.5 secondes d'invulnérabilité
            if (j->vies <= 0)
            {
                j->vivant = 0;
                jeu->etat = ETAT_GAME_OVER;
            }
        }
    }
}

// ------------------------------------------------------------
//  mettreAJourEnnemis — Appelée à chaque tick depuis main.c
//
//  IA en deux modes :
//  - Patrouille : déplacement normal gauche/droite avec demi-tour
//    au bord de plateforme ou contre un mur.
//  - Charge : l'ennemi a détecté le joueur à < ENNEMI_DIST_DETECTION.
//    Il fonce vers lui à ENNEMI_VITESSE_CHARGE, sans s'arrêter
//    aux bords de plateformes (comportement agressif).
//    Il revient en patrouille si la distance dépasse ENNEMI_DIST_CHARGE_MAX.
// ------------------------------------------------------------
void mettreAJourEnnemis(JeuEtat *jeu)
{
    int i;
    Joueur *j = &jeu->joueur;

    for (i = 0; i < jeu->nb_ennemis; i++)
    {
        Ennemi *e = &jeu->ennemis[i];

        if (!e->vivant) continue;

        /* --- 1. IA : détection et basculement de mode --- */
        if (j->vivant)
        {
            /* Distance horizontale et verticale joueur <-> ennemi */
            float dx   = j->x - e->x;
            float dist = fabsf(dx);
            float dy   = fabsf(j->y - e->y);

            if (!e->en_charge && dist <= ENNEMI_DIST_DETECTION
                              && dy  <= ENNEMI_DIST_VERTICALE)
            {
                /* Passage en mode CHARGE :
                 * le joueur est proche ET sur le même plan horizontal */
                e->en_charge = 1;
                e->attaque   = 1;
            }
            else if (e->en_charge &&
                     (dist > ENNEMI_DIST_CHARGE_MAX || dy > ENNEMI_DIST_VERTICALE))
            {
                /* Retour en PATROUILLE :
                 * joueur trop loin en X OU monté sur une plateforme au-dessus */
                e->en_charge = 0;
                e->attaque   = 0;
                e->vx = e->vx_base * (e->direction == DIR_DROITE ? 1.0f : -1.0f);
            }
        }
        else
        {
            /* Joueur mort : forcément retour patrouille */
            e->en_charge = 0;
            e->attaque   = 0;
        }

        /* --- 2. Déplacement selon le mode --- */
        if (e->en_charge)
        {
            /* MODE CHARGE : foncer vers le joueur */
            float dx = j->x - e->x;
            if (dx > 0) {
                e->vx       =  ENNEMI_VITESSE_CHARGE;
                e->direction = DIR_DROITE;
            } else {
                e->vx       = -ENNEMI_VITESSE_CHARGE;
                e->direction = DIR_GAUCHE;
            }
            /* En charge : pas de détection de bord
             * (l'ennemi suit le joueur même au bord de la plateforme) */
        }
        else
        {
            /* MODE PATROUILLE : demi-tour si bord ou mur */
            if (!aSolDevant(jeu, e) || estContreMur(jeu, e))
            {
                e->direction *= -1;
                e->vx        *= -1;
            }
        }

        /* --- 3. Déplacement effectif --- */
        e->x += e->vx;

        /* --- 4. Contact avec le joueur --- */
        if (j->vivant)
            gererContactJoueurEnnemi(jeu, e);
    }
}