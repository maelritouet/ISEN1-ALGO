#include <math.h>
#include "ennemi.h"
#include "jeu.h"
#include "niveau.h"


//  À l'oral : "Chaque ennemi se déplace horizontalement.
//  À chaque tick on vérifie s'il y a encore du sol devant
//  lui — si non, il fait demi-tour. Même chose s'il touche
//  un mur. Pour la mort, on teste si le joueur arrive par
//  le dessus avec une vitesse négative."

//  aSolDevant — Vérifie s'il y a une plateforme sous le
//  prochain pas de l'ennemi (pour détecter les bords)
//
// on teste un point juste devant et juste sous
//  l'ennemi. S'il n'y a pas de plateforme là → bord détecté.
static int aSolDevant(JeuEtat *jeu, Ennemi *e)
{
    int i;

    float testX;
    if (e->direction == DIR_DROITE)
        testX = e->x + e->largeur + 2; 
    else
        testX = e->x - 2;            

    float testY = e->y - 2; 

    for (i = 0; i < jeu->nb_plateformes; i++)
    {
        Plateforme *p = &jeu->plateformes[i];
        if (p->mortelle) continue;

        float px, py, pw, ph;
        getPlatformHitbox(p, &px, &py, &pw, &ph);

        if (testX >= px && testX <= px + pw &&
            testY >= py && testY <= py + ph)
            return 1; // Il y a du sol devant
    }
    return 0; // Pas de sol → bord de plateforme
}

static int estContreMur(JeuEtat *jeu, Ennemi *e)
{
    int i;
    for (i = 0; i < jeu->nb_plateformes; i++)
    {
        Plateforme *p = &jeu->plateformes[i];
        if (p->mortelle) continue;

        float px, py, pw, ph;
        getPlatformHitbox(p, &px, &py, &pw, &ph);

        // Collision horizontale : l'ennemi chevauche-t-il la plateforme en X ?
        int chevaucheY = (e->y + e->hauteur > py) && (e->y < py + ph);
        if (!chevaucheY) continue;

        if (e->direction == DIR_DROITE)
        {
            if (e->x + e->largeur >= px && e->x < px)
                return 1; // Mur à droite
        }
        else
        {
            if (e->x <= px + pw && e->x + e->largeur > px + pw)
                return 1; // Mur à gauche
        }
    }
    return 0;
}

//  gererContactJoueurEnnemi — Détecte si le joueur touche
//  un ennemi, et détermine ce qui se passe :
//  - Joueur arrive par le dessus (vy < 0) → ennemi meurt
//  - Joueur touche par le côté ou dessous → joueur perd une vie
static void gererContactJoueurEnnemi(JeuEtat *jeu, Ennemi *e)
{
    Joueur *j = &jeu->joueur;

    // Test de collision AABB entre joueur et ennemi
    int collisionX = (j->x + j->largeur > e->x) && (j->x < e->x + e->largeur);
    int collisionY = (j->y + j->hauteur > e->y) && (j->y < e->y + e->hauteur);

    if (!collisionX || !collisionY) return; // Pas de contact

    if (j->en_dash) {
        // Le dash tue l'ennemi instantanément sans modifier le mouvement du joueur
        if (!e->en_mort) {
            if (e->type_ennemi == TYPE_DEMON) {
                e->en_mort = 1;
                e->timer_mort = 30;
            } else {
                e->vivant = 0; // Slimes meurent direct
            }
        }
        return;
    }

    /* Le joueur arrive-t-il par le dessus (stomp) ? */
    float centreEnnemi = e->y + e->hauteur * 0.5f;
    int parLeDessus = (j->y >= centreEnnemi);

    if (parLeDessus)
    {
        if (!e->en_mort) {
            if (e->type_ennemi == TYPE_DEMON) {
                e->en_mort = 1;
                e->timer_mort = 30;
            } else {
                e->vivant = 0; // Slimes meurent direct
            }
        }
        // Petit rebond du joueur vers le haut (feel satisfaisant)
        j->vy = 8.0f;
    }
    else
    {
        // Le joueur est touché par le côté ou le dessous
        if (j->invulnerable == 0)
        {
            j->vies--;
            j->invulnerable = 90; // 1.5 secondes d'invulnérabilité
            if (j->vies <= 0)
            {
                if (!j->en_mort) {
                    j->en_mort = 1;
                    j->timer_mort = 60;
                }
            }
        }
    }
}

static void gererCollisionsVerticalesEnnemi(JeuEtat *jeu, Ennemi *e)
{
    int i;
    e->au_sol = 0;

    for (i = 0; i < jeu->nb_plateformes; i++)
    {
        Plateforme *p = &jeu->plateformes[i];
        if (p->mortelle) continue;

        float px, py, pw, ph;
        getPlatformHitbox(p, &px, &py, &pw, &ph);

        if (e->x + e->largeur <= px || e->x >= px + pw ||
            e->y + e->hauteur <= py || e->y >= py + ph)
            continue;

        // Collision 
        if (e->vy <= 0.0f) // chute
        {
            e->y = py + ph;
            e->vy = 0.0f;
            e->au_sol = 1;
        }
        else // 
        {
            e->y = py - e->hauteur;
            e->vy = 0.0f;
        }
    }
}

void mettreAJourEnnemis(JeuEtat *jeu)
{
    int i;
    Joueur *j = &jeu->joueur;

    for (i = 0; i < jeu->nb_ennemis; i++)
    {
        Ennemi *e = &jeu->ennemis[i];

        if (!e->vivant) continue;

        if (e->en_mort) {
            e->timer_mort--;
            if (e->timer_mort <= 0) e->vivant = 0;
            
            // Applique la gravité pendant la mort (pour qu'il retombe)
            e->vy -= GRAVITE;
            if (e->vy < -VITESSE_CHUTE_MAX) e->vy = -VITESSE_CHUTE_MAX;
            e->y += e->vy;
            gererCollisionsVerticalesEnnemi(jeu, e);
            continue; // Ignore l'IA
        }

        // détection  
        if (j->vivant)
        {
            // Distance horizontale et verticale joueur <-> ennemi 
            float dx   = j->x - e->x;
            float dist = fabsf(dx);
            float dy   = fabsf(j->y - e->y);

            float dist_detec = (e->type_ennemi == TYPE_DEMON) ? 300.0f : ((e->type_ennemi == TYPE_RED_SLIME) ? 200.0f : ENNEMI_DIST_DETECTION);
            float dist_max   = (e->type_ennemi == TYPE_DEMON) ? 400.0f : ((e->type_ennemi == TYPE_RED_SLIME) ? 300.0f : ENNEMI_DIST_CHARGE_MAX);

            if (!e->en_charge && dist <= dist_detec
                              && dy  <= ENNEMI_DIST_VERTICALE)
            {
                //  mode charge : le joueur proche et même plan horizontal 
                e->en_charge = 1;
                e->attaque   = 1;
            }
            else if (e->en_charge &&
                     (dist > dist_max || dy > ENNEMI_DIST_VERTICALE))
            {
                // retour en PATROUILLE : joueur trop loin en X ou en Y
                e->en_charge = 0;
                e->attaque   = 0;
                e->vx = e->vx_base * (e->direction == DIR_DROITE ? 1.0f : -1.0f);
            }
        }
        else
        {
            e->en_charge = 0;
            e->attaque   = 0;
        }

        //  Déplacement selon le mode 
        if (e->en_charge)
        {
            float vit_charge = (e->type_ennemi == TYPE_DEMON) ? 7.5f : ((e->type_ennemi == TYPE_RED_SLIME) ? 5.5f : ENNEMI_VITESSE_CHARGE);
            
            //  MODE CHARGE : foncer vers le joueur 
            float dx = j->x - e->x;
            if (dx > 0) {
                e->vx       =  vit_charge;
                e->direction = DIR_DROITE;
            } else {
                e->vx       = -vit_charge;
                e->direction = DIR_GAUCHE;
            }
            // En charge pas de détection de bord
        }
        else
        {
            // patrouilledemi-tour si bord ou mur   
            if (!aSolDevant(jeu, e) || estContreMur(jeu, e))
            {
                e->direction *= -1;
                e->vx        *= -1;
            }
        }

        // Gravité et Déplacement effectif 
        e->vy -= GRAVITE;
        if (e->vy < -VITESSE_CHUTE_MAX) e->vy = -VITESSE_CHUTE_MAX;
        
        e->x += e->vx;
        e->y += e->vy;

        gererCollisionsVerticalesEnnemi(jeu, e);

        if (e->y < -100) e->vivant = 0;

        // Contact avec le joueur 
        if (j->vivant)
            gererContactJoueurEnnemi(jeu, e);
    }
}