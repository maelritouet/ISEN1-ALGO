#!/usr/bin/env python3
"""
prepare_sprites.py - Prépare les sprites BMP pour le jeu

Ce script :
  1. Détecte automatiquement la taille d'une frame dans chaque spritesheet
  2. Extrait la première frame (= sprite statique)
  3. Crée le miroir horizontal pour la direction gauche
  4. Supprime le fond transparent (remplace par noir = couleur clé GfxLib)
  5. Redimensionne à la bonne taille de jeu
  6. Exporte en BMP 24-bit non compressé dans images/

Usage :
  python3 prepare_sprites.py

Dépendance : Pillow  →  pip install Pillow
"""

from PIL import Image
import os

# ── Dossiers ──────────────────────────────────────────────────────
DIR_KNIGHT = "images/Knight Pixel Art/Spritesheet"
DIR_SLIME  = "images/slime-monster/spritesheet"
OUT        = "images"

# ── Tailles cibles dans le jeu (doivent correspondre à jeu.h) ─────
TAILLE_JOUEUR = (32, 48)
TAILLE_ENNEMI = (32, 40)
TAILLE_PIECE  = (16, 16)

# Couleur de fond pour la transparence (noir = invisible sur fond sombre)
FOND = (0, 0, 0)


def charge_png(chemin):
    """Charge un PNG, convertit en RGBA pour gérer la transparence."""
    img = Image.open(chemin).convert("RGBA")
    return img


def supprime_transparence(img, couleur_fond=FOND):
    """
    Remplace les pixels transparents par couleur_fond.
    GfxLib ne gère pas la transparence PNG — on utilise le noir
    comme couleur "de fond" qui disparaît sur notre fond sombre.
    """
    fond = Image.new("RGBA", img.size, couleur_fond + (255,))
    fond.paste(img, mask=img.split()[3])  # canal alpha comme masque
    return fond.convert("RGB")


def detecte_frame_size(img):
    """
    Tente de deviner la taille d'une frame dans une spritesheet.
    Stratégie : on cherche des colonnes de pixels transparents pour
    trouver la largeur d'une frame.
    Si impossible, on divise la largeur par le nombre de frames estimé.
    """
    w, h = img.size
    # Cas simples connus
    if w <= 32:
        return w, h   # Image déjà une seule frame

    # Chercher des séparateurs transparents verticaux
    rgba = img.convert("RGBA")
    pixels = rgba.load()

    # Chercher la première colonne entièrement transparente
    for x in range(1, w):
        col_transparente = all(pixels[x, y][3] == 0 for y in range(h))
        if col_transparente:
            return x, h

    # Fallback : supposer que la spritesheet est carrée en frames
    # (ex: 6 frames = largeur / 6)
    # On essaie des diviseurs courants
    for nb_frames in [2, 4, 6, 8, 10]:
        if w % nb_frames == 0:
            return w // nb_frames, h

    return w, h  # Dernière option : prendre toute l'image


def extrait_premiere_frame(chemin_spritesheet):
    """
    Extrait la première frame d'une spritesheet.
    Renvoie une image PIL RGB.
    """
    img = charge_png(chemin_spritesheet)
    fw, fh = detecte_frame_size(img)
    print(f"  → Frame détectée : {fw}×{fh} px  (image totale : {img.width}×{img.height})")
    frame = img.crop((0, 0, fw, fh))
    return supprime_transparence(frame)


def miroir_horizontal(img):
    """Retourne l'image horizontalement (direction gauche)."""
    return img.transpose(Image.FLIP_LEFT_RIGHT)


def redimensionne(img, taille_cible):
    """
    Redimensionne à la taille cible avec NEAREST (pixel art).
    On utilise NEAREST pour ne pas flouter le pixel art.
    """
    return img.resize(taille_cible, Image.NEAREST)


def sauvegarde_bmp(img, nom_fichier):
    """Sauvegarde en BMP 24-bit non compressé (requis par lisBMPRGB)."""
    chemin = os.path.join(OUT, nom_fichier)
    img.convert("RGB").save(chemin, format="BMP")
    print(f"  ✓ Sauvegardé : {chemin}  ({img.width}×{img.height})")


def main():
    print("=" * 55)
    print("  Préparation des sprites BMP pour GfxLib")
    print("=" * 55)

    # ── Chevalier : idle (première frame = sprite "au repos") ─────
    print("\n[1/4] Chevalier — idle (droite)")
    chemin_idle = os.path.join(DIR_KNIGHT, "Hero-idle-Sheet.png")
    knight_idle = extrait_premiere_frame(chemin_idle)
    knight_idle_r = redimensionne(knight_idle, TAILLE_JOUEUR)
    sauvegarde_bmp(knight_idle_r, "joueur_droite.bmp")

    print("\n[2/4] Chevalier — idle (gauche = miroir)")
    knight_idle_l = miroir_horizontal(knight_idle_r)
    sauvegarde_bmp(knight_idle_l, "joueur_gauche.bmp")

    # ── Slime : première frame ────────────────────────────────────
    print("\n[3/4] Slime — première frame")
    chemin_slime = os.path.join(DIR_SLIME, "slime-spritesheet.png")
    slime = extrait_premiere_frame(chemin_slime)
    slime_r = redimensionne(slime, TAILLE_ENNEMI)
    sauvegarde_bmp(slime_r, "gobelin.bmp")

    print("\n[4/4] Slime — miroir (direction gauche)")
    slime_l = miroir_horizontal(slime_r)
    sauvegarde_bmp(slime_l, "gobelin_gauche.bmp")

    # ── Objets placeholder (carrés colorés en BMP) ────────────────
    print("\n[5/5] Objets placeholder (pièce, powerup, clé, porte)")

    # Pièce : cercle doré
    piece = Image.new("RGB", TAILLE_PIECE, (255, 215, 0))
    sauvegarde_bmp(piece, "piece.bmp")

    # Powerup : carré rose
    powerup = Image.new("RGB", (24, 24), (255, 80, 200))
    sauvegarde_bmp(powerup, "powerup.bmp")

    # Clé : carré jaune
    cle = Image.new("RGB", (24, 24), (255, 200, 0))
    sauvegarde_bmp(cle, "cle.bmp")

    # Porte : rectangle marron
    porte = Image.new("RGB", (50, 100), (120, 70, 30))
    sauvegarde_bmp(porte, "porte.bmp")

    # Squelette et boss : copie du slime recolorisée (placeholder)
    squelette = redimensionne(slime, TAILLE_ENNEMI)
    # Teinte grise
    r, g, b = squelette.split()
    squelette_gris = Image.merge("RGB", [g, g, g])  # niveaux de gris
    sauvegarde_bmp(squelette_gris, "squelette.bmp")

    boss = redimensionne(slime, (64, 60))
    sauvegarde_bmp(boss, "boss.bmp")

    print("\n" + "=" * 55)
    print("  Terminé ! Sprites dans images/")
    print("  Relance make pour compiler avec les sprites.")
    print("=" * 55)


if __name__ == "__main__":
    main()
