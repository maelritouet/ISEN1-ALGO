/*
 * joueur.h - Déclarations du module joueur
 *
 * Ce module gère tout ce qui concerne le personnage joueur :
 *   - Initialisation
 *   - Physique (gravité, vélocité)
 *   - Saut
 *   - Collision avec les plateformes
 *   - Gestion des entrées clavier
 *   - Frames d'invulnérabilité (bonus)
 *
 * Membre 1 - Moteur physique & joueur
 */

#ifndef JOUEUR_H
#define JOUEUR_H

#include "jeu.h"

/* ---- Constantes spécifiques au joueur ---- */

/* Vitesse de course (bonus) */
#define VITESSE_COURSE      7.0f

/* Facteur d'inertie : 0 = pas d'inertie, 1 = glisse à l'infini (bonus) */
#define INERTIE             0.75f

/* Force du double saut (bonus) */
#define FORCE_DOUBLE_SAUT   10.0f

/* ---- Prototypes publics ---- */

/* Remet le joueur dans son état initial pour le niveau courant */
void initialiseJoueur(void);

/* Met à jour physique et collisions — appelé à chaque frame */
void miseAJourJoueur(void);

/* Traite une entrée clavier pour déplacer/faire sauter le joueur
 *   touche_speciale : code GfxLib (ToucheFlecheGauche, etc.) ou 0
 *   touche_normale  : char ('z', ' ', etc.) ou 0
 */
void gereEntreeJoueur(int touche_speciale, char touche_normale);

/* Inflige des dégâts au joueur (réduit les vies, active l'invulnérabilité) */
void blesseJoueur(void);

/* Renvoie 1 si le joueur est en train de tomber (vy < 0 et pas au sol) */
int joueurEnChute(void);

/* Signale qu'une touche est relâchée (stoppe le déplacement) */
void gereRelacheJoueur(int touche_speciale);

#endif /* JOUEUR_H */
