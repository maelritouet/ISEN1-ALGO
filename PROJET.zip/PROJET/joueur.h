#ifndef JOUEUR_H
#define JOUEUR_H

#include "jeu.h"

void initialiserJoueur(JeuEtat *jeu);
void mettreAJourTouches(JeuEtat *jeu, int gauche, int droite);
void mettreAJourJoueur(JeuEtat *jeu);
void gererClavierJoueur(JeuEtat *jeu, char touche);
void gererClavierSpecialJoueur(JeuEtat *jeu, int touche);

#endif