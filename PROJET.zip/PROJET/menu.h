#ifndef MENU_H
#define MENU_H

#include "jeu.h"

void dessinerMenu(void);
void dessinerSelectionNiveau(JeuEtat *jeu);
void dessinerAide(void);
void dessinerGameOver(void);
void dessinerVictoire(JeuEtat *jeu);

#endif
