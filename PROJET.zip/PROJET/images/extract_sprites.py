import os
from PIL import Image

# Configuration
TARGET_SIZE = (64, 64)
BG_COLOR = (255, 0, 255)  # Pure Magenta for chroma-key transparency

# List of your files and how many horizontal frames they contain
spritesheets = {
    "Attack_2.png": 4,
    "Dead.png": 3,
    "Walk.png": 8
}

def process_spritesheets():
    for filename, frame_count in spritesheets.items():
        if not os.path.exists(filename):
            print(f"Skipping {filename}: File not found in current directory.")
            continue
            
        print(f"Processing {filename}...")
        
        # Open original image
        img = Image.open(filename)
        img_w, img_h = img.size
        
        # Calculate the uniform width of each frame container
        frame_width = img_w // frame_count
        
        # Create an output directory for organized files
        output_dir = os.path.splitext(filename)[0] + "_frames"
        os.makedirs(output_dir, exist_ok=True)
        
        for i in range(frame_count):
            # 1. Crop out the individual frame slot
            left = i * frame_width
            right = left + frame_width
            frame_container = img.crop((left, 0, right, img_h))
            
            # 2. Find the tight bounding box of the actual slime pixels (ignoring transparency)
            bbox = frame_container.getbbox()
            if not bbox:
                # If the frame is entirely empty, just create a blank magenta block
                final_bmp = Image.new("RGB", TARGET_SIZE, BG_COLOR)
            else:
                # Crop tightly to just the slime sprite
                slime_sprite = frame_container.crop(bbox)
                sprite_w, sprite_h = slime_sprite.size
                
                # Scale down if the sprite is somehow larger than 64x64 (preserves aspect ratio)
                if sprite_w > TARGET_SIZE[0] or sprite_h > TARGET_SIZE[1]:
                    slime_sprite.thumbnail(TARGET_SIZE, Image.Resampling.LANCZOS)
                    sprite_w, sprite_h = slime_sprite.size
                
                # 3. Create the 64x64 solid magenta background
                final_bmp = Image.new("RGB", TARGET_SIZE, BG_COLOR)
                
                # 4. Calculate positioning (X: Centered, Y: Snapped to bottom)
                paste_x = (TARGET_SIZE[0] - sprite_w) // 2
                paste_y = TARGET_SIZE[1] - sprite_h
                
                # 5. Paste sprite onto the background using its alpha channel as a mask
                if slime_sprite.mode == 'RGBA':
                    final_bmp.paste(slime_sprite, (paste_x, paste_y), slime_sprite)
                else:
                    final_bmp.paste(slime_sprite, (paste_x, paste_y))
            
            # 6. Save explicitly as a 24-bit BMP
            output_filename = os.path.join(output_dir, f"frame_{i}.bmp")
            final_bmp.save(output_filename, format="BMP")
            
        print(f"Successfully saved {frame_count} frames to folder: '{output_dir}/'")

if __name__ == "__main__":
    process_spritesheets()
