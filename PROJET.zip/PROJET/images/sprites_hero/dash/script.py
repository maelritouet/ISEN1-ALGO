import os
from PIL import Image

def mirror_bmp_images():
    # Liste tous les fichiers du dossier actuel
    files = os.listdir('.')
    
    # Filtre pour ne garder que les fichiers .bmp qui contiennent 'dash'
    bmp_files = [f for f in files if f.endswith('.bmp') and 'dash' in f]
    
    if not bmp_files:
        print("Aucun fichier .bmp correspondant trouvé dans le dossier.")
        return

    print(f"Trouvé {len(bmp_files)} fichiers à inverser...")

    for file_name in bmp_files:
        try:
            # Ouvrir l'image
            with Image.open(file_name) as img:
                # Appliquer l'effet miroir horizontal (axe vertical)
                mirrored_img = img.transpose(Image.FLIP_LEFT_RIGHT)
                
                # Générer le nouveau nom de fichier (ex: dash1_left.bmp)
                name_part, ext_part = os.path.splitext(file_name)
                output_name = f"{name_part}_left{ext_part}"
                
                # Sauvegarder la nouvelle image
                mirrored_img.save(output_name)
                print(f"Succès : {file_name} -> {output_name}")
                
        except Exception as e:
            print(f"Erreur avec le fichier {file_name}: {e}")

if __name__ == "__main__":
    mirror_bmp_images()
