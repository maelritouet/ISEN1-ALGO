import os
from PIL import Image

# Configuration : Dimensions divisées par 2 -> 48x24
TARGET_SIZE = (48, 24)
BG_COLOR = (255, 0, 255)  # Magenta pur pour la transparence

# Liste de vos fichiers avec le nombre de frames horizontales correspondantes
spritesheets = {
    "Attack_2.png": 4,
    "Dead.png": 3,
    "Walk.png": 8,
    "Hero-attack-Sheet.png": 8,
    "Hero-die-Sheet.png": 12
}

def process_spritesheets():
    for filename, frame_count in spritesheets.items():
        if not os.path.exists(filename):
            print(f"Fichier manquant skipped : {filename}")
            continue
            
        print(f"Traitement de {filename}...")
        
        # Ouverture de la planche de sprites
        img = Image.open(filename)
        img_w, img_h = img.size
        
        # Calcul de la largeur de chaque case d'origine
        frame_width = img_w // frame_count
        
        # Création du dossier de sortie
        output_dir = os.path.splitext(filename)[0] + "_frames"
        os.makedirs(output_dir, exist_ok=True)
        
        for i in range(frame_count):
            # 1. Découpage de la case de la frame
            left = i * frame_width
            right = left + frame_width
            frame_container = img.crop((left, 0, right, img_h))
            
            # 2. Détection de la box réelle du sprite (ignore le vide transparent)
            bbox = frame_container.getbbox()
            if not bbox:
                # Si la frame est vide, on génère un bloc magenta uni
                final_bmp = Image.new("RGB", TARGET_SIZE, BG_COLOR)
            else:
                # Recadrage serré autour du personnage/slime
                character_sprite = frame_container.crop(bbox)
                sprite_w, sprite_h = character_sprite.size
                
                # Sécurité : Redimensionne proprement si le sprite dépasse du 48x24
                # Utilise NEAREST pour garder le style Pixel Art net sans flou
                if sprite_w > TARGET_SIZE[0] or sprite_h > TARGET_SIZE[1]:
                    character_sprite.thumbnail(TARGET_SIZE, Image.Resampling.NEAREST)
                    sprite_w, sprite_h = character_sprite.size
                
                # 3. Création du fond de 48x24 en magenta
                final_bmp = Image.new("RGB", TARGET_SIZE, BG_COLOR)
                
                # 4. Calcul du positionnement (X: Centré, Y: Collé en bas)
                paste_x = (TARGET_SIZE[0] - sprite_w) // 2
                paste_y = TARGET_SIZE[1] - sprite_h
                
                # 5. Application du sprite sur le fond magenta
                if character_sprite.mode == 'RGBA':
                    final_bmp.paste(character_sprite, (paste_x, paste_y), character_sprite)
                else:
                    final_bmp.paste(character_sprite, (paste_x, paste_y))
            
            # 6. Sauvegarde brute en BMP 24-bit
            output_filename = os.path.join(output_dir, f"frame_{i}.bmp")
            final_bmp.save(output_filename, format="BMP")
            
        print(f"✓ {frame_count} frames sauvegardées dans le dossier : '{output_dir}/'")

if __name__ == "__main__":
    process_spritesheets()
