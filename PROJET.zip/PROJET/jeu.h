#ifndef JEU_H
#define JEU_H

// ============================================================
//  jeu.h — Structures et constantes partagées
//  Ce fichier est inclus par TOUS les modules du projet.
// ============================================================

// ------------------------------------------------------------
//  Constantes globales
// ------------------------------------------------------------

#define LARGEUR_FENETRE  1920
#define HAUTEUR_FENETRE  1080

// --- Physique ---
#define GRAVITE           0.5f
#define GRAVITE_CHUTE     0.9f
#define VITESSE_JOUEUR    5.0f
#define VITESSE_AIR       5.0f   /* Même vitesse au sol et en l'air */
#define FORCE_SAUT        14.0f
#define VITESSE_CHUTE_MAX 18.0f
#define COYOTE_TICKS      6
#define JUMP_BUFFER_TICKS 6

// --- Niveau ---
#define NB_PLATEFORMES   200
#define NB_ENNEMIS       50
#define NB_PIECES        100
#define PIECES_POUR_BONUS 10

// --- États du jeu ---
#define ETAT_MENU        0
#define ETAT_JEU         1
#define ETAT_GAME_OVER   2
#define ETAT_VICTOIRE    3
#define ETAT_SELECTION   4   /* Écran de sélection de niveau */
#define ETAT_AIDE        5   /* Écran d'aide (guide des touches) */

// --- IA Ennemis ---
#define ENNEMI_DIST_DETECTION  150.0f   /* Distance horizontale de détection (px) */
#define ENNEMI_DIST_CHARGE_MAX 250.0f   /* Au-delà : retour en patrouille */
#define ENNEMI_VITESSE_CHARGE    4.5f   /* Vitesse en mode charge */
#define ENNEMI_DIST_VERTICALE   80.0f   /* Seuil Y : charge annulée si joueur trop haut */

// --- Types d'ennemis ---
// Pour ajouter un nouveau type : ajouter une valeur ici,
// puis gérer les sprites dans rendu.c et le comportement dans ennemi.c
#define TYPE_CHEVALIER_GOBELIN  0
#define NB_TYPES_ENNEMIS        1      /* Nombre de types définis */

// --- Système Blueprint (création de niveaux) ---
#define TILE_SIZE        64             /* Taille d'un tile en pixels */
#define BLUEPRINT_ROWS   15             /* Hauteur du blueprint (rangées) */
#define BLUEPRINT_COLS   56             /* Largeur du blueprint (colonnes) */

// --- Directions ---
#define DIR_DROITE  1
#define DIR_GAUCHE -1

// ------------------------------------------------------------
//  Structure : Joueur
// ------------------------------------------------------------
typedef struct {
    float x, y;
    float vx, vy;
    int   direction;
    int   vies;
    int   pieces;
    int   invulnerable;   /* Timer en ticks, 0 = vulnérable */
    int   au_sol;         /* 1 si posé sur une plateforme */
    int   vivant;
    int   largeur;
    int   hauteur;
    int   coyote_timer;   /* Ticks restants pour sauter après avoir quitté un bord */
    int   jump_buffer;    /* Ticks restants du jump buffer (saut anticipé) */
} Joueur;

// ------------------------------------------------------------
//  Structure : Plateforme
// ------------------------------------------------------------
typedef struct {
    float x, y;
    float largeur;
    float hauteur;
    int   mortelle;
    char  type;      /* '#' = grass+dirt, 'D' = dirt seul, 'X' = mortelle, etc. */
} Plateforme;

// ------------------------------------------------------------
//  Structure : Ennemi
// ------------------------------------------------------------
typedef struct {
    float x, y;
    float vx;
    float vx_base;    /* Vitesse de patrouille de base (sauvegardée) */
    int   direction;
    int   vivant;
    int   attaque;    /* 1 si en mode charge, 0 en patrouille */
    int   en_charge;  /* Alias clair de attaque pour la logique IA */
    int   largeur;
    int   hauteur;
    int   type_ennemi; /* TYPE_CHEVALIER_GOBELIN, etc. — détermine sprites et IA */
} Ennemi;

// ------------------------------------------------------------
//  Structure : Objet
// ------------------------------------------------------------
typedef struct {
    float x, y;
    int   collectee;
    int   type;
    int   largeur;
    int   hauteur;
} Objet;

// ------------------------------------------------------------
//  Structure : JeuEtat — le cerveau central du jeu
// ------------------------------------------------------------
typedef struct {
    Joueur     joueur;
    Plateforme plateformes[NB_PLATEFORMES];
    Ennemi     ennemis[NB_ENNEMIS];
    Objet      objets[NB_PIECES];

    int        nb_plateformes;
    int        nb_ennemis;
    int        nb_objets;

    int        niveau_actuel;
    int        nb_niveaux;       /* Nombre total de niveaux disponibles */
    int        selection_niveau; /* Niveau surligné dans l'écran de sélection */
    float      timer;
    int        etat;

    float      camera_x;
    float      sortie_x;
    float      sortie_y;
    float      spawn_x;          /* Position X de spawn du joueur (définie par 'S' dans le blueprint) */
    float      spawn_y;          /* Position Y de spawn */
} JeuEtat;

#endif