#ifndef JEU_H
#define JEU_H

// ============================================================
//  jeu.h — Structures et constantes partagées
//  Ce fichier est inclus par TOUS les modules du projet.
// ============================================================

// ------------------------------------------------------------
//  Constantes globales
// ------------------------------------------------------------

#define LARGEUR_FENETRE  1280
#define HAUTEUR_FENETRE  720

// --- Physique ---
#define GRAVITE           0.5f
#define GRAVITE_CHUTE     0.9f
#define VITESSE_JOUEUR    5.0f
#define VITESSE_AIR       5.0f   /* Même vitesse au sol et en l'air */
#define FORCE_SAUT        14.0f
#define VITESSE_CHUTE_MAX 18.0f
#define COYOTE_TICKS      6
#define JUMP_BUFFER_TICKS 6

// --- Niveau ---
#define NB_PLATEFORMES   40
#define NB_ENNEMIS       10
#define NB_PIECES        25
#define PIECES_POUR_BONUS 10

// --- États du jeu ---
#define ETAT_MENU      0
#define ETAT_JEU       1
#define ETAT_GAME_OVER 2
#define ETAT_VICTOIRE  3

// --- Directions ---
#define DIR_DROITE  1
#define DIR_GAUCHE -1

// ------------------------------------------------------------
//  Structure : Joueur
// ------------------------------------------------------------
typedef struct {
    float x, y;
    float vx, vy;
    int   direction;
    int   vies;
    int   pieces;
    int   invulnerable;   /* Timer en ticks, 0 = vulnérable */
    int   au_sol;         /* 1 si posé sur une plateforme */
    int   vivant;
    int   largeur;
    int   hauteur;
    int   coyote_timer;   /* Ticks restants pour sauter après avoir quitté un bord */
    int   jump_buffer;    /* Ticks restants du jump buffer (saut anticipé) */
} Joueur;

// ------------------------------------------------------------
//  Structure : Plateforme
// ------------------------------------------------------------
typedef struct {
    float x, y;
    float largeur;
    float hauteur;
    int   mortelle;
} Plateforme;

// ------------------------------------------------------------
//  Structure : Ennemi
// ------------------------------------------------------------
typedef struct {
    float x, y;
    float vx;
    int   direction;
    int   vivant;
    int   attaque;
    int   largeur;
    int   hauteur;
} Ennemi;

// ------------------------------------------------------------
//  Structure : Objet
// ------------------------------------------------------------
typedef struct {
    float x, y;
    int   collectee;
    int   type;
    int   largeur;
    int   hauteur;
} Objet;

// ------------------------------------------------------------
//  Structure : JeuEtat — le cerveau central du jeu
// ------------------------------------------------------------
typedef struct {
    Joueur     joueur;
    Plateforme plateformes[NB_PLATEFORMES];
    Ennemi     ennemis[NB_ENNEMIS];
    Objet      objets[NB_PIECES];

    int        nb_plateformes;
    int        nb_ennemis;
    int        nb_objets;

    int        niveau_actuel;
    float      timer;
    int        etat;

    float      camera_x;
} JeuEtat;

#endif