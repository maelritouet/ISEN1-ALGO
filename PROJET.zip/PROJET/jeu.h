#ifndef JEU_H
#define JEU_H

//  jeu.h — Structures et constantes partagées

//  Constantes globales

#define LARGEUR_FENETRE  1920
#define HAUTEUR_FENETRE  1080

//  Physique
#define GRAVITE           0.5f
#define GRAVITE_CHUTE     0.9f
#define VITESSE_JOUEUR    5.0f
#define VITESSE_AIR       5.0f   /* Même vitesse au sol et en l'air */
#define FORCE_SAUT        10.5f
#define VITESSE_CHUTE_MAX 18.0f
#define COYOTE_TICKS      6
#define JUMP_BUFFER_TICKS 6

//  Niveau
#define NB_PLATEFORMES   400
#define NB_ENNEMIS       80
#define NB_PIECES        200
#define PIECES_POUR_BONUS 10

//  États du jeu
#define ETAT_MENU        0
#define ETAT_JEU         1
#define ETAT_GAME_OVER   2
#define ETAT_VICTOIRE    3
#define ETAT_TRANSITION  6
#define ETAT_SELECTION   4   /* Écran de sélection de niveau */
#define ETAT_AIDE        5   /* Écran d'aide (guide des touches) */

//  IA Ennemis
#define ENNEMI_DIST_DETECTION  150.0f   /* Distance horizontale de détection (px) */
#define ENNEMI_DIST_CHARGE_MAX 250.0f   /* Au-delà : retour en patrouille */
#define ENNEMI_VITESSE_CHARGE    4.5f   /* Vitesse en mode charge */
#define ENNEMI_DIST_VERTICALE   80.0f   /* Seuil Y : charge annulée si joueur trop haut */

//  Types d'ennemis 
#define TYPE_DEMON              0
#define TYPE_SLIME              1
#define TYPE_RED_SLIME          2
#define NB_TYPES_ENNEMIS        3      /* Nombre de types définis */

//  Système Blueprint
#define TILE_SIZE        64            
#define BLUEPRINT_COLS   120            /* Largeur max */

//  Directions
#define DIR_DROITE  1
#define DIR_GAUCHE -1

//  Structure : Joueur
typedef struct {
    float x, y;
    float vx, vy;
    int   direction;
    int   vies;
    int   pieces;
    int   invulnerable;   /* Compteur à rebourd en ticks */
    int   au_sol;         /* 1 si plateforme */
    int   vivant;
    int   largeur;
    int   hauteur;
    int   coyote_timer;   /* Ticks restants pour sauter après avoir quitté un bord */
    int   jump_buffer;    /* Ticks restants du jump buffer (saut anticipé) */
    int   sauts_restants; /* double saut */
    int   en_dash;        /* 1 si dash */
    int   timer_dash;     /* Ticks restants pour le dash actuel */
    int   cooldown_dash;  /* Ticks restants avant de pouvoir redasher */
    int   en_mort;        /* 1 si animation de mort en cours */
    int   timer_mort;     /* Ticks restants pour l'animation de mort */
} Joueur;

//  Structure : Plateforme
typedef struct {
    float x, y;
    float largeur;
    float hauteur;
    int   mortelle;
    char  type;      /* # = grass+dirt, 'D' = dirt seul, 'X' = mortelle, etc. */
} Plateforme;

//  Structure : Ennemi
typedef struct {
    float      x, y;
    float      vx, vy;          /* Vitesse courante horizontale et verticale */
    float      vx_base;         /* Vitesse standard (patrouille) */
    int        direction;       /* 1 = droite, -1 = gauche */
    int        vivant;        
    int        au_sol;          /* 1 =sol,*/

    /* IA basique */
    int   attaque;    /* 1 si en mode charge, 0 en patrouille */
    int   en_charge;  
    int   largeur;
    int   hauteur;
    int   type_ennemi;
    int   en_mort;
    int   timer_mort;
} Ennemi;

//  Structure : Objet
typedef struct {
    float x, y;
    int   collectee;
    int   type;
    int   largeur;
    int   hauteur;
} Objet;

//  Structure : JeuEtat 
typedef struct {
    Joueur     joueur;
    Plateforme plateformes[NB_PLATEFORMES];
    Ennemi     ennemis[NB_ENNEMIS];
    Objet      objets[NB_PIECES];

    int        nb_plateformes;
    int        nb_ennemis;
    int        nb_objets;

    int        niveau_actuel;
    int        nb_niveaux;       /* total niveaux disponibles */
    int        selection_niveau; /* Niveau surligné dans l'écran de sélection */
    float      timer;
    float      timer_complet;    /* Temps de complétion du niveau*/
    int        etat;

    float      camera_x;
    float      camera_y;
    float      largeur_niveau;
    float      hauteur_niveau;
    float      sortie_x;
    float      sortie_y;
    float      spawn_x;         
    float      spawn_y;          

    float      meilleurs_temps[10]; 
    int        nouveau_record_etabli; /* 1 si record */

    float      opacite_fondu;    /* De 0.0 (transparent) à 255.0 (noir) */
    int        sens_fondu;       /* 1 pour s'assombrir, -1 pour s'éclaircir */
    int        etat_futur;       /* L'état vers lequel on va basculer une fois l'écran noir */
} JeuEtat;

void chargerRecords(JeuEtat *jeu);
void sauvegarderRecord(JeuEtat *jeu);

#endif