/*
 * jeu.h - Header principal du jeu de plateforme médiéval fantasy
 *
 * Ce fichier est inclus par TOUS les autres fichiers .c du projet.
 * Il contient :
 *   - Les constantes globales (taille fenêtre, physique, limites...)
 *   - Les définitions de structs partagées entre les modules
 *   - Les déclarations extern de la variable d'état globale
 *
 * Projet ISEN CIN1/BIOST1 - Semestre 2 2026
 */

#ifndef JEU_H
#define JEU_H

/* =========================================================
 *  CONSTANTES : Fenêtre
 * ========================================================= */

#define LARGEUR_FENETRE  1280   /* Largeur de la fenêtre en pixels */
#define HAUTEUR_FENETRE  720    /* Hauteur de la fenêtre en pixels */

/* =========================================================
 *  CONSTANTES : Physique
 * ========================================================= */

#define GRAVITE         0.5f    /* Accélération vers le bas chaque frame */
#define VITESSE_JOUEUR  4.0f    /* Vitesse horizontale du joueur en pixels/frame */
#define FORCE_SAUT      12.0f   /* Vitesse verticale initiale lors d'un saut */

/* =========================================================
 *  CONSTANTES : Limites des tableaux
 * ========================================================= */

#define NB_PLATEFORMES  30      /* Nombre maximum de plateformes par niveau */
#define NB_ENNEMIS      8       /* Nombre maximum d'ennemis par niveau */
#define NB_PIECES       20      /* Nombre maximum de pièces/objets par niveau */
#define NB_NIVEAUX      3       /* Nombre total de niveaux dans le jeu */

/* =========================================================
 *  CONSTANTES : États du jeu (champ "etat" de JeuEtat)
 * ========================================================= */

#define ETAT_MENU       0       /* Écran titre / menu principal */
#define ETAT_JEU        1       /* Partie en cours */
#define ETAT_GAME_OVER  2       /* Écran de game over */
#define ETAT_VICTOIRE   3       /* Écran de victoire */

/* =========================================================
 *  CONSTANTES : Types d'objets (champ "type" de Objet)
 * ========================================================= */

#define OBJET_PIECE     0       /* Pièce d'or : +1 au compteur */
#define OBJET_POWERUP   1       /* Power-up : restaure une vie */
#define OBJET_CLE       2       /* Clé : débloque la porte de fin */

/* =========================================================
 *  CONSTANTES : Jeu
 * ========================================================= */

#define VIES_INITIALES      3   /* Nombre de vies au départ */
#define DUREE_INVULNERABLE  90  /* Durée d'invulnérabilité après un dégât (en frames) */
#define TIMER_NIVEAU        120 /* Durée d'un niveau en secondes */
#define TAILLE_JOUEUR_L     32  /* Largeur du sprite joueur en pixels */
#define TAILLE_JOUEUR_H     48  /* Hauteur du sprite joueur en pixels */
#define TAILLE_ENNEMI_L     32  /* Largeur du sprite ennemi en pixels */
#define TAILLE_ENNEMI_H     40  /* Hauteur du sprite ennemi en pixels */
#define TAILLE_PIECE        16  /* Taille d'une pièce en pixels */

/* =========================================================
 *  STRUCT : Joueur
 *  Géré principalement par joueur.c (Membre 1)
 * ========================================================= */

typedef struct {
    float x, y;         /* Position du coin bas-gauche du joueur */
    float vx, vy;       /* Vitesse : vx=horizontal, vy=vertical (+ = monte) */
    int direction;      /* Sens du regard : 1 = droite, -1 = gauche */
    int vies;           /* Nombre de vies restantes */
    int pieces;         /* Nombre de pièces collectées */
    int invulnerable;   /* Timer d'invulnérabilité en frames (0 = vulnérable) */
    int vivant;         /* 1 = vivant, 0 = mort */
    int au_sol;         /* 1 = le joueur touche une plateforme, 0 = en l'air */
    int a_cle;          /* 1 = le joueur possède la clé du niveau */
} Joueur;

/* =========================================================
 *  STRUCT : Plateforme
 *  Gérée principalement par niveau.c (Membre 2)
 * ========================================================= */

typedef struct {
    float x, y;         /* Position du coin bas-gauche */
    float largeur;      /* Largeur en pixels */
    float hauteur;      /* Épaisseur en pixels */
    int mortelle;       /* 1 = fait mourir le joueur au contact (ex: lave) */
    int active;         /* 1 = existe dans le niveau, 0 = désactivée */
} Plateforme;

/* =========================================================
 *  STRUCT : Ennemi
 *  Géré principalement par ennemi.c (Membre 3)
 * ========================================================= */

typedef struct {
    float x, y;         /* Position du coin bas-gauche */
    float vx;           /* Vitesse horizontale (négatif = va vers la gauche) */
    int direction;      /* Sens du regard : 1 = droite, -1 = gauche */
    int vivant;         /* 1 = vivant, 0 = mort */
    int attaque;        /* 1 = en mode attaque (contact = dégât joueur) */
    int type;           /* 0 = gobelin basique, 1 = squelette, 2 = boss */
} Ennemi;

/* =========================================================
 *  STRUCT : Objet (pièces, powerups, clé)
 *  Géré principalement par objets.c (Membre 4)
 * ========================================================= */

typedef struct {
    float x, y;         /* Position du centre de l'objet */
    int collectee;      /* 1 = déjà ramassé (ne plus afficher), 0 = disponible */
    int type;           /* OBJET_PIECE, OBJET_POWERUP ou OBJET_CLE */
} Objet;

/* =========================================================
 *  STRUCT : Caméra (scrolling horizontal)
 *  Gérée par niveau.c (Membre 2)
 * ========================================================= */

typedef struct {
    float x;            /* Décalage horizontal de la caméra en pixels */
} Camera;

/* =========================================================
 *  STRUCT : JeuEtat — état global complet du jeu
 *  Cette structure contient TOUT ce qui décrit la partie en cours.
 *  Elle est déclarée dans main.c et partagée via extern.
 * ========================================================= */

typedef struct {
    Joueur      joueur;
    Plateforme  plateformes[NB_PLATEFORMES];
    Ennemi      ennemis[NB_ENNEMIS];
    Objet       objets[NB_PIECES];
    Camera      camera;
    int         niveau_actuel;  /* Numéro du niveau en cours (1 à NB_NIVEAUX) */
    float       timer;          /* Temps restant en secondes */
    int         etat;           /* ETAT_MENU, ETAT_JEU, ETAT_GAME_OVER, ETAT_VICTOIRE */
    int         score;          /* Score total du joueur */
} JeuEtat;

/* =========================================================
 *  VARIABLE GLOBALE PARTAGÉE
 *  Déclarée dans main.c, accessible partout via extern.
 * ========================================================= */

extern JeuEtat jeu;

/* =========================================================
 *  PROTOTYPES DES MODULES
 *  Chaque module déclare ses fonctions publiques dans son .h,
 *  mais on met ici un résumé pour référence rapide.
 * ========================================================= */

/* --- joueur.c --- */
void initialiseJoueur(void);
void miseAJourJoueur(void);
void gereEntreeJoueur(int touche_speciale, char touche_normale);

/* --- niveau.c --- */
void initialiseNiveau(int numero);
void miseAJourCamera(void);

/* --- ennemi.c --- */
void initialiseEnnemis(void);
void miseAJourEnnemis(void);

/* --- objets.c --- */
void initialiseObjets(void);
void miseAJourObjets(void);

/* --- rendu.c --- */
void dessineMenu(void);
void dessineJeu(void);
void dessineGameOver(void);
void dessineVictoire(void);

#endif /* JEU_H */
