#include <stdio.h>
#include <stdlib.h>
#include <X11/Xlib.h>
#include <X11/keysym.h>
#include <GL/gl.h>
#include "gfxlib/GfxLib.h"
#include "menu.h"
#include "jeu.h"
#include "joueur.h"
#include "niveau.h"
#include "ennemi.h"
#include "objets.h"
#include "rendu.h"

// ============================================================
//  main.c — Point d'entrée
//
//  Gestion des touches directionnelles via XQueryKeymap :
//  On interroge l'état physique du clavier X11 à chaque tick
//  (dans Temporisation) plutôt que de compter les événements
//  Gfxlib. Résultat : la touche est active exactement tant
//  qu'elle est physiquement enfoncée — comportement standard.
// ============================================================

JeuEtat jeu;

/* ------------------------------------------------------------
 *  lireTouchesX11 — Lit l'état physique du clavier en temps réel
 *
 *  XQueryKeymap() retourne un tableau de 32 octets où chaque bit
 *  correspond à une touche. On teste directement si Gauche/Droite/Haut
 *  sont physiquement enfoncées EN CE MOMENT, sans dépendre des
 *  événements Gfxlib qui ont un problème de répétition OS.
 *
 *  Résultat : comportement identique à tout jeu normal —
 *  la touche est active exactement tant qu'elle est physiquement tenue.
 * ------------------------------------------------------------ */
static void lireTouchesX11(int *gauche, int *droite, int *haut)
{
    Display *dpy = XOpenDisplay(NULL);
    if (!dpy) { *gauche = *droite = *haut = 0; return; }

    char keys[32];
    XQueryKeymap(dpy, keys);

    /* Convertir les KeySym en KeyCode puis tester le bit correspondant */
    KeyCode kc_gauche = XKeysymToKeycode(dpy, XK_Left);
    KeyCode kc_droite = XKeysymToKeycode(dpy, XK_Right);
    KeyCode kc_haut   = XKeysymToKeycode(dpy, XK_Up);
    KeyCode kc_espace = XKeysymToKeycode(dpy, XK_space);

    /* Le bit du KeyCode kc est : keys[kc/8] & (1 << (kc%8)) */
    *gauche = (keys[kc_gauche / 8] >> (kc_gauche % 8)) & 1;
    *droite = (keys[kc_droite / 8] >> (kc_droite % 8)) & 1;
    *haut   = ((keys[kc_haut   / 8] >> (kc_haut   % 8)) & 1) |
              ((keys[kc_espace / 8] >> (kc_espace  % 8)) & 1);

    XCloseDisplay(dpy);
}

void chargerRecords(JeuEtat *jeu) {
    int i;
    for (i = 0; i < 10; i++) jeu->meilleurs_temps[i] = 9999.9f;
    FILE *f = fopen("records.txt", "r");
    if (f) {
        int niveau;
        float temps;
        while (fscanf(f, "%d %f", &niveau, &temps) == 2) {
            if (niveau >= 0 && niveau < 10) {
                jeu->meilleurs_temps[niveau] = temps;
            }
        }
        fclose(f);
    }
}

void sauvegarderRecord(JeuEtat *jeu) {
    FILE *f = fopen("records.txt", "w");
    if (f) {
        int i;
        for (i = 0; i < 10; i++) {
            if (jeu->meilleurs_temps[i] < 9999.0f) {
                fprintf(f, "%d %.2f\n", i, jeu->meilleurs_temps[i]);
            }
        }
        fclose(f);
    }
}

int main(int argc, char **argv)
{
    initialiseGfx(argc, argv);
    prepareFenetreGraphique("Platformer Medieval Fantasy", LARGEUR_FENETRE, HAUTEUR_FENETRE);
    modePleinEcran();
    atexit(libererSprites);
    lanceBoucleEvenements();
    return 0;
}

void gestionEvenement(EvenementGfx evenement)
{
    switch (evenement)
    {
        case Initialisation:
            jeu.etat             = ETAT_MENU;
            jeu.niveau_actuel    = 1;
            jeu.nb_niveaux       = 4;  /* Niveaux 1 à 4 sont prêts */
            jeu.selection_niveau = 1;
            jeu.opacite_fondu    = 255.0f; /* Lancer avec un fondu d'ouverture */
            jeu.sens_fondu       = -1;
            jeu.etat_futur       = -1;
            chargerRecords(&jeu);
            initialiserJeu(&jeu);
            chargerSprites();
            demandeTemporisation(16);
            break;

        case Temporisation:
            if (jeu.sens_fondu != 0) {
                jeu.opacite_fondu += jeu.sens_fondu * 12.0f;
                if (jeu.opacite_fondu >= 255.0f) {
                    jeu.opacite_fondu = 255.0f;
                    if (jeu.etat_futur != -1) {
                        if (jeu.etat_futur == ETAT_JEU) {
                            jeu.niveau_actuel = jeu.selection_niveau;
                            initialiserJeu(&jeu);
                        } else if (jeu.etat_futur == ETAT_MENU) {
                            initialiserJeu(&jeu);
                            jeu.nb_niveaux       = 4;
                            jeu.selection_niveau = 1;
                        }
                        jeu.etat = jeu.etat_futur;
                        jeu.etat_futur = -1;
                        jeu.sens_fondu = -1; /* Lance le fondu d'ouverture */
                    }
                } else if (jeu.opacite_fondu <= 0.0f) {
                    jeu.opacite_fondu = 0.0f;
                    jeu.sens_fondu = 0;
                }
            }

            if (jeu.etat == ETAT_JEU)
            {
                int gauche, droite, haut;
                static int haut_precedent = 0;
                lireTouchesX11(&gauche, &droite, &haut);

                mettreAJourTouches(&jeu, gauche, droite);

                /* Jump buffer : si haut détecté ET qu'il vient d'être appuyé, on l'alimente */
                if (haut && !haut_precedent)
                    jeu.joueur.jump_buffer = JUMP_BUFFER_TICKS;
                haut_precedent = haut;

                mettreAJourJoueur(&jeu);
                mettreAJourCamera(&jeu);
                mettreAJourEnnemis(&jeu);
                mettreAJourObjets(&jeu);
                jeu.timer += 0.016f;
            }

            rafraichisFenetre();
            break;

        case Affichage:
            dessinerTout(&jeu);
            break;

        case Clavier:
            if (caractereClavier() == '\r' || caractereClavier() == '\n')
            {
                if (jeu.etat == ETAT_MENU)
                {
                    /* Menu → Sélection de niveau */
                    jeu.etat = ETAT_SELECTION;
                    jeu.selection_niveau = 1;
                }
                else if (jeu.etat == ETAT_AIDE)
                {
                    /* Aide → retour au menu */
                    jeu.etat = ETAT_MENU;
                }
                else if (jeu.etat == ETAT_SELECTION)
                {
                    /* Lancer le niveau sélectionné s'il est disponible via un fondu */
                    if (jeu.selection_niveau <= jeu.nb_niveaux && jeu.sens_fondu == 0)
                    {
                        jeu.etat_futur = ETAT_JEU;
                        jeu.sens_fondu = 1; /* Fondu au noir */
                    }
                }
                else if ((jeu.etat == ETAT_GAME_OVER || jeu.etat == ETAT_VICTOIRE) && jeu.sens_fondu == 0)
                {
                    jeu.etat_futur = ETAT_MENU;
                    jeu.sens_fondu = 1; /* Fondu au noir */
                }
            }
            if (caractereClavier() == 'h' || caractereClavier() == 'H')
            {
                if (jeu.etat == ETAT_MENU)
                    jeu.etat = ETAT_AIDE;
            }
            if (caractereClavier() == 27 || caractereClavier() == 'q')
            {
                if (jeu.etat == ETAT_SELECTION)
                    jeu.etat = ETAT_MENU;  /* ESC depuis sélection → menu */
                else if (jeu.etat == ETAT_AIDE)
                    jeu.etat = ETAT_MENU;  /* ESC depuis aide → menu */
                else
                    termineBoucleEvenements();
            }
            gererClavierJoueur(&jeu, caractereClavier());
            break;

        case ClavierSpecial:
            /* Directions gérées via XQueryKeymap dans Temporisation */

            if (toucheClavier() == ToucheFlecheHaut)
            {
                if (jeu.etat == ETAT_SELECTION)
                {
                    /* Navigation vers le haut dans le menu de sélection */
                    if (jeu.selection_niveau > 1)
                        jeu.selection_niveau--;
                }
                else
                {
                    jeu.joueur.jump_buffer = JUMP_BUFFER_TICKS;
                }
            }
            if (toucheClavier() == ToucheFlecheBas)
            {
                if (jeu.etat == ETAT_SELECTION)
                {
                    /* Navigation vers le bas (max 4 entrées affichées) */
                    if (jeu.selection_niveau < 4)
                        jeu.selection_niveau++;
                }
            }
            break;

        case Souris:
        case BoutonSouris:
        case Inactivite:
        case Redimensionnement:
            /* Forcer le système de coordonnées à rester en 1920x1080
             * afin que GfxLib zoome l'image au lieu d'agrandir la zone de jeu */
            glMatrixMode(GL_PROJECTION);
            glLoadIdentity();
            glOrtho(0.0, LARGEUR_FENETRE, 0.0, HAUTEUR_FENETRE, -1.0, 1.0);
            glMatrixMode(GL_MODELVIEW);
            
            /* GfxLib utilise glDrawPixels qui ignore la matrice de projection pour la taille des pixels.
             * Il faut donc lui dire de zoomer les pixels manuellement selon le ratio de la fenêtre. */
            glPixelZoom((float)largeurFenetre() / LARGEUR_FENETRE, (float)hauteurFenetre() / HAUTEUR_FENETRE);
            break;
    }
}