#include <stdlib.h>
#include <X11/Xlib.h>
#include <X11/keysym.h>
#include "gfxlib/GfxLib.h"
#include "jeu.h"
#include "joueur.h"
#include "niveau.h"
#include "ennemi.h"
#include "objets.h"
#include "rendu.h"

// ============================================================
//  main.c — Point d'entrée
//
//  Gestion des touches directionnelles via XQueryKeymap :
//  On interroge l'état physique du clavier X11 à chaque tick
//  (dans Temporisation) plutôt que de compter les événements
//  Gfxlib. Résultat : la touche est active exactement tant
//  qu'elle est physiquement enfoncée — comportement standard.
// ============================================================

JeuEtat jeu;

/* ------------------------------------------------------------
 *  lireTouchesX11 — Lit l'état physique du clavier en temps réel
 *
 *  XQueryKeymap() retourne un tableau de 32 octets où chaque bit
 *  correspond à une touche. On teste directement si Gauche/Droite/Haut
 *  sont physiquement enfoncées EN CE MOMENT, sans dépendre des
 *  événements Gfxlib qui ont un problème de répétition OS.
 *
 *  Résultat : comportement identique à tout jeu normal —
 *  la touche est active exactement tant qu'elle est physiquement tenue.
 * ------------------------------------------------------------ */
static void lireTouchesX11(int *gauche, int *droite, int *haut)
{
    Display *dpy = XOpenDisplay(NULL);
    if (!dpy) { *gauche = *droite = *haut = 0; return; }

    char keys[32];
    XQueryKeymap(dpy, keys);

    /* Convertir les KeySym en KeyCode puis tester le bit correspondant */
    KeyCode kc_gauche = XKeysymToKeycode(dpy, XK_Left);
    KeyCode kc_droite = XKeysymToKeycode(dpy, XK_Right);
    KeyCode kc_haut   = XKeysymToKeycode(dpy, XK_Up);
    KeyCode kc_espace = XKeysymToKeycode(dpy, XK_space);

    /* Le bit du KeyCode kc est : keys[kc/8] & (1 << (kc%8)) */
    *gauche = (keys[kc_gauche / 8] >> (kc_gauche % 8)) & 1;
    *droite = (keys[kc_droite / 8] >> (kc_droite % 8)) & 1;
    *haut   = ((keys[kc_haut   / 8] >> (kc_haut   % 8)) & 1) |
              ((keys[kc_espace / 8] >> (kc_espace  % 8)) & 1);

    XCloseDisplay(dpy);
}

int main(int argc, char **argv)
{
    initialiseGfx(argc, argv);
    prepareFenetreGraphique("Platformer Medieval Fantasy", LARGEUR_FENETRE, HAUTEUR_FENETRE);
    atexit(libererSprites);
    lanceBoucleEvenements();
    return 0;
}

void gestionEvenement(EvenementGfx evenement)
{
    switch (evenement)
    {
        case Initialisation:
            jeu.etat             = ETAT_MENU;
            jeu.niveau_actuel    = 1;
            jeu.nb_niveaux       = 2;  /* Mettre à jour quand d'autres niveaux sont prêts */
            jeu.selection_niveau = 1;
            initialiserJeu(&jeu);
            chargerSprites();
            demandeTemporisation(16);
            break;

        case Temporisation:
            if (jeu.etat == ETAT_JEU)
            {
                int gauche, droite, haut;
                lireTouchesX11(&gauche, &droite, &haut);

                mettreAJourTouches(&jeu, gauche, droite);

                /* Jump buffer : si haut détecté, on l'alimente */
                if (haut)
                    jeu.joueur.jump_buffer = JUMP_BUFFER_TICKS;

                mettreAJourJoueur(&jeu);
                mettreAJourCamera(&jeu);
                mettreAJourEnnemis(&jeu);
                mettreAJourObjets(&jeu);
                jeu.timer += 0.016f;
            }

            rafraichisFenetre();
            break;

        case Affichage:
            dessinerTout(&jeu);
            break;

        case Clavier:
            if (caractereClavier() == '\r' || caractereClavier() == '\n')
            {
                if (jeu.etat == ETAT_MENU)
                {
                    /* Menu → Sélection de niveau */
                    jeu.etat = ETAT_SELECTION;
                    jeu.selection_niveau = 1;
                }
                else if (jeu.etat == ETAT_AIDE)
                {
                    /* Aide → retour au menu */
                    jeu.etat = ETAT_MENU;
                }
                else if (jeu.etat == ETAT_SELECTION)
                {
                    /* Lancer le niveau sélectionné s'il est disponible */
                    if (jeu.selection_niveau <= jeu.nb_niveaux)
                    {
                        jeu.niveau_actuel = jeu.selection_niveau;
                        initialiserJeu(&jeu);
                        /* Restaurer les méta-infos après le reset */
                        jeu.nb_niveaux       = 2;
                        jeu.selection_niveau = jeu.niveau_actuel;
                        jeu.etat = ETAT_JEU;
                    }
                }
                else if (jeu.etat == ETAT_GAME_OVER || jeu.etat == ETAT_VICTOIRE)
                {
                    initialiserJeu(&jeu);
                    jeu.nb_niveaux       = 2;
                    jeu.selection_niveau = 1;
                }
            }
            if (caractereClavier() == 'h' || caractereClavier() == 'H')
            {
                if (jeu.etat == ETAT_MENU)
                    jeu.etat = ETAT_AIDE;
            }
            if (caractereClavier() == 27 || caractereClavier() == 'q')
            {
                if (jeu.etat == ETAT_SELECTION)
                    jeu.etat = ETAT_MENU;  /* ESC depuis sélection → menu */
                else if (jeu.etat == ETAT_AIDE)
                    jeu.etat = ETAT_MENU;  /* ESC depuis aide → menu */
                else
                    termineBoucleEvenements();
            }
            gererClavierJoueur(&jeu, caractereClavier());
            break;

        case ClavierSpecial:
            /* Directions gérées via XQueryKeymap dans Temporisation */

            if (toucheClavier() == ToucheFlecheHaut)
            {
                if (jeu.etat == ETAT_SELECTION)
                {
                    /* Navigation vers le haut dans le menu de sélection */
                    if (jeu.selection_niveau > 1)
                        jeu.selection_niveau--;
                }
                else
                {
                    jeu.joueur.jump_buffer = JUMP_BUFFER_TICKS;
                }
            }
            if (toucheClavier() == ToucheFlecheBas)
            {
                if (jeu.etat == ETAT_SELECTION)
                {
                    /* Navigation vers le bas (max 3 entrées affichées) */
                    if (jeu.selection_niveau < 3)
                        jeu.selection_niveau++;
                }
            }
            break;

        case Souris:
        case BoutonSouris:
        case Inactivite:
        case Redimensionnement:
            break;
    }
}