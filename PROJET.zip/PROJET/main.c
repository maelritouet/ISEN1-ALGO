/*
 * main.c - Point d'entrée et boucle principale du jeu
 *
 * Projet ISEN CIN1/BIOST1 - Semestre 2 2026
 */

#include <stdio.h>
#include "gfxlib/GfxLib.h"
#include "jeu.h"
#include "joueur.h"
#include "niveau.h"
#include "ennemi.h"
#include "objets.h"
#include "rendu.h"

/* Variable globale : état complet du jeu */
JeuEtat jeu;

/* Prototypes locaux */
static void initialiseJeu(void);
static void miseAJourLogique(void);
static void dessineFrame(void);
static void gereClavier(char touche);
static void gereClavierSpecial(int touche);

/* =========================================================
 *  main()
 * ========================================================= */
int main(int argc, char **argv)
{
    initialiseGfx(argc, argv);
    prepareFenetreGraphique("Donjon Medieval - ISEN 2026", LARGEUR_FENETRE, HAUTEUR_FENETRE);
    initialiseJeu();
    lanceBoucleEvenements();
    return 0;
}

/* =========================================================
 *  initialiseJeu()
 * ========================================================= */
static void initialiseJeu(void)
{
    jeu.etat          = ETAT_MENU;
    jeu.niveau_actuel = 1;
    jeu.score         = 0;
    jeu.joueur.vies   = VIES_INITIALES;
    jeu.joueur.pieces = 0;

    /* Démarrer le timer ~60fps */
    demandeTemporisation(16);
}

/* Démarre une nouvelle partie depuis le niveau 1 */
static void demarreNouvellePartie(void)
{
    jeu.score         = 0;
    jeu.niveau_actuel = 1;
    jeu.joueur.vies   = VIES_INITIALES;
    jeu.joueur.pieces = 0;

    initialiseNiveau(1);
    initialiseJoueur();
    initialiseEnnemis();
    initialiseObjets();
    jeu.etat = ETAT_JEU;
}

/* =========================================================
 *  miseAJourLogique() — appelée à chaque Temporisation
 * ========================================================= */
static void miseAJourLogique(void)
{
    /* Décrémenter le timer (60 frames ≈ 1 seconde) */
    jeu.timer -= 1.0f / 60.0f;

    if (jeu.timer <= 0.0f)
    {
        jeu.timer = 0.0f;
        jeu.etat  = ETAT_GAME_OVER;
        return;
    }

    miseAJourJoueur();
    miseAJourCamera();
    miseAJourEnnemis();
    miseAJourObjets();

    /* Gérer la mort du joueur */
    if (!jeu.joueur.vivant)
    {
        jeu.joueur.vies--;
        if (jeu.joueur.vies <= 0)
        {
            jeu.etat = ETAT_GAME_OVER;
        }
        else
        {
            /* Relance le niveau sans perdre les pièces */
            initialiseNiveau(jeu.niveau_actuel);
            initialiseJoueur();
            initialiseEnnemis();
            initialiseObjets();
        }
    }
}

/* =========================================================
 *  dessineFrame()
 * ========================================================= */
static void dessineFrame(void)
{
    switch (jeu.etat)
    {
        case ETAT_MENU:      dessineMenu();     break;
        case ETAT_JEU:       dessineJeu();      break;
        case ETAT_GAME_OVER: dessineGameOver(); break;
        case ETAT_VICTOIRE:  dessineVictoire(); break;
        default:             effaceFenetre(0,0,0); break;
    }
}

/* =========================================================
 *  gereClavier()
 * ========================================================= */
static void gereClavier(char touche)
{
    switch (jeu.etat)
    {
        case ETAT_MENU:
            if (touche == 13 || touche == ' ')
                demarreNouvellePartie();
            if (touche == 27)
                termineBoucleEvenements();
            break;

        case ETAT_JEU:
            gereEntreeJoueur(0, touche);
            if (touche == 27)
                jeu.etat = ETAT_MENU;
            break;

        case ETAT_GAME_OVER:
        case ETAT_VICTOIRE:
            jeu.etat = ETAT_MENU;
            break;
    }
}

/* =========================================================
 *  gereClavierSpecial()
 * ========================================================= */
static void gereClavierSpecial(int touche)
{
    if (jeu.etat == ETAT_JEU)
        gereEntreeJoueur(touche, 0);
}

/* =========================================================
 *  gestionEvenement() — obligatoire pour GfxLib
 * ========================================================= */
void gestionEvenement(EvenementGfx evenement)
{
    switch (evenement)
    {
        case Initialisation:
            /* Charger les sprites BMP */
            initialiseRendu();
            break;

        case Temporisation:
            if (jeu.etat == ETAT_JEU)
                miseAJourLogique();
            rafraichisFenetre();
            break;

        case Affichage:
            dessineFrame();
            break;

        case Clavier:
            gereClavier(caractereClavier());
            break;

        case ClavierSpecial:
            gereClavierSpecial(toucheClavier());
            break;

        case Souris:
        case BoutonSouris:
            break;

        default:
            break;
    }
}
