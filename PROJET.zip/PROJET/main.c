#include <stdlib.h>
#include "gfxlib/GfxLib.h"
#include "jeu.h"
#include "joueur.h"
#include "niveau.h"
#include "ennemi.h"
#include "objets.h"
#include "rendu.h"

// ============================================================
//  main.c — Point d'entrée
//
//  Gestion des touches :
//  La Gfxlib n'envoie pas d'événement au relâchement des touches.
//  On simule l'état "enfoncé" avec un compteur par touche.
//
//  Problème connu : quand on appuie sur Haut, l'OS suspend
//  momentanément les répétitions de Gauche/Droite (~200ms).
//  Solution : TOUCHE_DUREE = 15 ticks = 240ms, ce qui couvre
//  ce trou. On recharge aussi Gauche/Droite au moment du saut.
// ============================================================

JeuEtat jeu;

#define TOUCHE_DUREE 15   /* 15 ticks x 16ms = 240ms de mémoire */

static int cptGauche = 0;
static int cptDroite = 0;

int main(int argc, char **argv)
{
    initialiseGfx(argc, argv);
    prepareFenetreGraphique("Platformer Medieval Fantasy", LARGEUR_FENETRE, HAUTEUR_FENETRE);
    lanceBoucleEvenements();
    return 0;
}

void gestionEvenement(EvenementGfx evenement)
{
    switch (evenement)
    {
        case Initialisation:
            initialiserJeu(&jeu);
            jeu.nb_niveaux       = 1;  /* Mettre à jour quand d'autres niveaux sont prêts */
            jeu.selection_niveau = 1;
            chargerSprites();
            demandeTemporisation(16);
            break;

        case Temporisation:
            if (jeu.etat == ETAT_JEU)
            {
                mettreAJourTouches(&jeu,
                    cptGauche > 0 ? 1 : 0,
                    cptDroite > 0 ? 1 : 0);
                mettreAJourJoueur(&jeu);
                mettreAJourCamera(&jeu);
                mettreAJourEnnemis(&jeu);
                mettreAJourObjets(&jeu);
                jeu.timer += 0.016f;
            }

            if (cptGauche > 0) cptGauche--;
            if (cptDroite > 0) cptDroite--;

            rafraichisFenetre();
            break;

        case Affichage:
            dessinerTout(&jeu);
            break;

        case Clavier:
            if (caractereClavier() == '\r' || caractereClavier() == '\n')
            {
                if (jeu.etat == ETAT_MENU)
                {
                    /* Menu → Sélection de niveau */
                    jeu.etat = ETAT_SELECTION;
                    jeu.selection_niveau = 1;
                }
                else if (jeu.etat == ETAT_SELECTION)
                {
                    /* Lancer le niveau sélectionné s'il est disponible */
                    if (jeu.selection_niveau <= jeu.nb_niveaux)
                    {
                        jeu.niveau_actuel = jeu.selection_niveau;
                        initialiserJeu(&jeu);
                        /* Restaurer les méta-infos après le reset */
                        jeu.nb_niveaux       = 1;
                        jeu.selection_niveau = jeu.niveau_actuel;
                        jeu.etat = ETAT_JEU;
                    }
                }
                else if (jeu.etat == ETAT_GAME_OVER || jeu.etat == ETAT_VICTOIRE)
                {
                    initialiserJeu(&jeu);
                    jeu.nb_niveaux       = 1;
                    jeu.selection_niveau = 1;
                }
            }
            if (caractereClavier() == 27 || caractereClavier() == 'q')
            {
                if (jeu.etat == ETAT_SELECTION)
                    jeu.etat = ETAT_MENU;  /* ESC depuis sélection → menu */
                else
                    termineBoucleEvenements();
            }
            gererClavierJoueur(&jeu, caractereClavier());
            break;

        case ClavierSpecial:
            if (toucheClavier() == ToucheFlecheGauche)  cptGauche = TOUCHE_DUREE;
            if (toucheClavier() == ToucheFlecheDroite)  cptDroite = TOUCHE_DUREE;
            if (toucheClavier() == ToucheFlecheHaut)
            {
                if (jeu.etat == ETAT_SELECTION)
                {
                    /* Navigation vers le haut dans le menu de sélection */
                    if (jeu.selection_niveau > 1)
                        jeu.selection_niveau--;
                }
                else
                {
                    jeu.joueur.jump_buffer = JUMP_BUFFER_TICKS;
                    if (cptGauche > 0) cptGauche = TOUCHE_DUREE;
                    if (cptDroite > 0) cptDroite = TOUCHE_DUREE;
                }
            }
            if (toucheClavier() == ToucheFlecheBas)
            {
                if (jeu.etat == ETAT_SELECTION)
                {
                    /* Navigation vers le bas (max 3 entrées affichées) */
                    if (jeu.selection_niveau < 3)
                        jeu.selection_niveau++;
                }
            }
            break;

        case Souris:
        case BoutonSouris:
        case Inactivite:
        case Redimensionnement:
            break;
    }
}