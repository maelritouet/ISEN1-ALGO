#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <GL/gl.h>
#include "gfxlib/GfxLib.h"
#include "gfxlib/BmpLib.h"
#include "rendu.h"
#include "jeu.h"
#include "menu.h"



//  Constantes
#define TRANSPARENT_R  255
#define TRANSPARENT_G    0
#define TRANSPARENT_B  255
#define MAX_BG_LAYERS  5


typedef struct {
    Sprite **frames;    /* Tableau de pointeurs vers les frames */
    int      nb;        /* Nombre de frames */
    int      vitesse;   /* Ticks entre chaque frame */
} AnimSprite;

//  Animations du joueur 
//    0 = idle droite,  1 = idle gauche
//    2 = walk droite,  3 = walk gauche
//    4 = jump droite,  5 = jump gauche
//    6 = dash droite,  7 = dash gauche

#define ANIM_IDLE_D  0
#define ANIM_IDLE_G  1
#define ANIM_WALK_D  2
#define ANIM_WALK_G  3
#define ANIM_JUMP_D  4
#define ANIM_JUMP_G  5
#define ANIM_DASH_D  6
#define ANIM_DASH_G  7
#define ANIM_DEATH   8
#define NB_ANIMS_JOUEUR 9

static Sprite     *frames_joueur[NB_ANIMS_JOUEUR][12]; 
static AnimSprite  anim_joueur[NB_ANIMS_JOUEUR];

//    Demon : 0=fly Droite, 1=fly Gauche, 2=attack Droite, 3=attack Gauche, 4=mort
//    Slime   : 0=walk,   1=attack
//    Redslime: 0=walk,   1=attack
#define NB_ANIMS_DEMON    5
#define NB_ANIMS_SLIME    2
#define NB_ANIMS_REDSLIME 2

static Sprite     *frames_demon[NB_ANIMS_DEMON][8];
static AnimSprite  anim_demon[NB_ANIMS_DEMON];

static Sprite     *frames_slime[NB_ANIMS_SLIME][8];
static AnimSprite  anim_slime[NB_ANIMS_SLIME];

static Sprite     *frames_redslime[NB_ANIMS_REDSLIME][8];
static AnimSprite  anim_redslime[NB_ANIMS_REDSLIME];

// Plateforme 3 parties (gauche/milieu/droite)
typedef struct {
    char    type;
    Sprite *gauche, *milieu, *droite;
} Plateforme3P;

#define NB_PLATEFORMES_3P 4
static Plateforme3P spr_plateformes[NB_PLATEFORMES_3P];

// Colonne 3 parties (haut/milieu/bas)
typedef struct {
    char    type;
    Sprite *haut, *milieu, *bas;
} Colonne3P;

#define NB_COLONNES_3P 1
static Colonne3P spr_colonnes[NB_COLONNES_3P];

// Bloc simple (un seul sprite par type)
typedef struct {
    char    type;
    Sprite *sprite;
} BlocSimple;

#define NB_BLOCS_SIMPLES 14
static BlocSimple spr_blocs_tab[NB_BLOCS_SIMPLES];

static Sprite *spr_dungeon_tiles[4] = {NULL};

//  Fonds de niveaux
#define NB_THEMES_FOND 5
static Texture2D *tex_fonds[NB_THEMES_FOND][MAX_BG_LAYERS];

static int anim_tick = 0;

static Sprite *spr_fond_mort = NULL;
static Sprite *spr_fond_victoire = NULL;
static Sprite *spr_fond_menu = NULL;

// Charge un BMP et le convertit en ARVB avec transparence en magenta pure 
static Sprite *chargerSprite(const char *chemin)
{
    DonneesImageRGB *bmp = lisBMPRGB((char *)chemin);
    if (!bmp) {
        printf("ATTENTION : sprite introuvable : %s\n", chemin);
        return NULL;
    }
    Sprite *spr      = (Sprite *)malloc(sizeof(Sprite));
    spr->largeur     = bmp->largeurImage;
    spr->hauteur     = bmp->hauteurImage;
    int nb           = spr->largeur * spr->hauteur;
    spr->donneesARVB = (int *)malloc(nb * sizeof(int));

    const unsigned char *src = bmp->donneesRGB;
    unsigned char       *dst = (unsigned char *)spr->donneesARVB;
    int i;
    for (i = 0; i < nb; i++) {
        unsigned char b = src[0], v = src[1], r = src[2];
        dst[0] = b; dst[1] = v; dst[2] = r;
        dst[3] = (r == TRANSPARENT_R && v == TRANSPARENT_G && b == TRANSPARENT_B)
                 ? 0x00 : 0xFF;
        src += 3; dst += 4;
    }
    libereDonneesImageRGB(&bmp);
    return spr;
}

// Inverse les canaux Rouge et Bleu pour compatibilité avec creeTexture2D
static void inverserCouleursSprite(Sprite *spr)
{
    if (!spr) return;
    int i, nb = spr->largeur * spr->hauteur;
    for (i = 0; i < nb; i++) {
        unsigned char *b = (unsigned char *)&spr->donneesARVB[i];
        unsigned char t = b[0]; b[0] = b[2]; b[2] = t;
    }
}

static void libererSprite(Sprite **spr)
{
    if (*spr) { free((*spr)->donneesARVB); free(*spr); *spr = NULL; }
}

// charge n frames d'une animation 
static void chargerAnim(AnimSprite *a, Sprite **tab, int nb, int vitesse,
                        const char *fmt, int debut_index)
{
    int i;
    char chemin[128];
    a->frames  = tab;
    a->nb      = nb;
    a->vitesse = vitesse;
    for (i = 0; i < nb; i++) {
        sprintf(chemin, fmt, debut_index + i);
        tab[i] = chargerSprite(chemin);
    }
}

static void libererAnim(AnimSprite *a)
{
    int i;
    for (i = 0; i < a->nb; i++)
        libererSprite(&a->frames[i]);
}

// Calcule la frame actuelle et affiche le sprite à x y
static void dessinerAnim(AnimSprite *a, int x, int y)
{
    if (!a || a->nb == 0) return;
    int frame = (anim_tick / a->vitesse) % a->nb;
    Sprite *spr = a->frames[frame];
    if (spr)
        ecrisImageARVB(x, y, spr->largeur, spr->hauteur, spr->donneesARVB);
}

/* Recherche dans les tableaux de sprites par type de bloc */
static Plateforme3P *trouverPlateforme(char type)
{
    int i;
    for (i = 0; i < NB_PLATEFORMES_3P; i++)
        if (spr_plateformes[i].type == type) return &spr_plateformes[i];
    return NULL;
}

static Colonne3P *trouverColonne(char type)
{
    int i;
    for (i = 0; i < NB_COLONNES_3P; i++)
        if (spr_colonnes[i].type == type) return &spr_colonnes[i];
    return NULL;
}

static Sprite *trouverBloc(char type)
{
    int i;
    for (i = 0; i < NB_BLOCS_SIMPLES; i++)
        if (spr_blocs_tab[i].type == type) return spr_blocs_tab[i].sprite;
    return NULL;
}

static int themeFond(int niveau)
{
    switch (niveau) {
        case 0: case 1: return 0;
        case 2:         return 1;
        case 3:         return 2;
        case 4:         return 3;
        case 5: case 6: case 7: case 8: return 4;
        default:        return 0;
    }
}

void libererSprites(void)
{
    int i, t;

    for (i = 0; i < NB_ANIMS_JOUEUR; i++)
        libererAnim(&anim_joueur[i]);

    for (i = 0; i < NB_ANIMS_DEMON;    i++) libererAnim(&anim_demon[i]);
    for (i = 0; i < NB_ANIMS_SLIME;    i++) libererAnim(&anim_slime[i]);
    for (i = 0; i < NB_ANIMS_REDSLIME; i++) libererAnim(&anim_redslime[i]);

    for (i = 0; i < NB_PLATEFORMES_3P; i++) {
        libererSprite(&spr_plateformes[i].gauche);
        libererSprite(&spr_plateformes[i].milieu);
        libererSprite(&spr_plateformes[i].droite);
    }
    for (i = 0; i < NB_COLONNES_3P; i++) {
        libererSprite(&spr_colonnes[i].haut);
        libererSprite(&spr_colonnes[i].milieu);
        libererSprite(&spr_colonnes[i].bas);
    }
    for (i = 0; i < NB_BLOCS_SIMPLES; i++)
        libererSprite(&spr_blocs_tab[i].sprite);
    for (i = 0; i < 4; i++)
        libererSprite(&spr_dungeon_tiles[i]);

    for (t = 0; t < NB_THEMES_FOND; t++)
        for (i = 0; i < MAX_BG_LAYERS; i++)
            if (tex_fonds[t][i]) libereTexture(&tex_fonds[t][i]);

    if (spr_fond_mort) libererSprite(&spr_fond_mort);
    if (spr_fond_victoire) libererSprite(&spr_fond_victoire);
    if (spr_fond_menu) libererSprite(&spr_fond_menu);
}

void chargerSprites(void)
{
    int i;
    char chemin[128];

    // Plateformes 3 parties : type + gauche/milieu/droite
    spr_plateformes[0].type   = '#';
    spr_plateformes[0].gauche = chargerSprite("images/world/left-rock-platform.bmp");
    spr_plateformes[0].milieu = chargerSprite("images/world/middle-rock-platform.bmp");
    spr_plateformes[0].droite = chargerSprite("images/world/right-rock-plateform.bmp");

    spr_plateformes[1].type   = '=';
    spr_plateformes[1].gauche = chargerSprite("images/world/grass_left.bmp");
    spr_plateformes[1].milieu = chargerSprite("images/world/grass_middle.bmp");
    spr_plateformes[1].droite = chargerSprite("images/world/grass_right.bmp");

    spr_plateformes[2].type   = '_';
    spr_plateformes[2].gauche = chargerSprite("images/world/left_dirt.bmp");
    spr_plateformes[2].milieu = chargerSprite("images/world/middle_dirt.bmp");
    spr_plateformes[2].droite = chargerSprite("images/world/right_dirt.bmp");

    spr_plateformes[3].type   = '-';
    spr_plateformes[3].gauche = chargerSprite("images/world/dungeon/left_wood_platform.bmp");
    spr_plateformes[3].milieu = chargerSprite("images/world/dungeon/middle_wood_platform.bmp");
    spr_plateformes[3].droite = chargerSprite("images/world/dungeon/right_wood_platform.bmp");

    // Colonnes 3 parties : type + haut/milieu/bas
    spr_colonnes[0].type   = '|';
    spr_colonnes[0].haut   = chargerSprite("images/world/dungeon/column_ceiling.bmp");
    spr_colonnes[0].milieu = chargerSprite("images/world/dungeon/column_middle.bmp");
    spr_colonnes[0].bas    = chargerSprite("images/world/dungeon/column_floor.bmp");

    // D Tuiles donjon random
    for (i = 0; i < 4; i++) {
        sprintf(chemin, "images/world/dungeon/dungeon_tile%d.bmp", i + 1);
        spr_dungeon_tiles[i] = chargerSprite(chemin);
    }

    // Blocs simples : type + sprite unique
    spr_blocs_tab[ 0] = (BlocSimple){ 'I', chargerSprite("images/world/ice.bmp") };
    spr_blocs_tab[ 1] = (BlocSimple){ 'X', chargerSprite("images/world/lava.bmp") };
    spr_blocs_tab[ 2] = (BlocSimple){ 'R', chargerSprite("images/world/rock.bmp") };
    spr_blocs_tab[ 3] = (BlocSimple){ 'r', chargerSprite("images/world/small_rock.bmp") };
    spr_blocs_tab[ 4] = (BlocSimple){ 'C', chargerSprite("images/world/dungeon/chain.bmp") };
    spr_blocs_tab[ 5] = (BlocSimple){ 'c', chargerSprite("images/world/dungeon/column_ceiling.bmp") };
    spr_blocs_tab[ 6] = (BlocSimple){ 'm', chargerSprite("images/world/dungeon/column_middle.bmp") };
    spr_blocs_tab[ 7] = (BlocSimple){ 'f', chargerSprite("images/world/dungeon/column_floor.bmp") };
    spr_blocs_tab[ 8] = (BlocSimple){ 'B', chargerSprite("images/world/dungeon/crate.bmp") };
    spr_blocs_tab[ 9] = (BlocSimple){ 'Y', chargerSprite("images/world/dungeon/spike_ceiling.bmp") };
    spr_blocs_tab[10] = (BlocSimple){ 'y', chargerSprite("images/world/dungeon/spike_floor.bmp") };
    spr_blocs_tab[11] = (BlocSimple){ '>', chargerSprite("images/world/dungeon/spike_left_wall.bmp") };
    spr_blocs_tab[12] = (BlocSimple){ '<', chargerSprite("images/world/dungeon/spike_right_wall.bmp") };
    spr_blocs_tab[13] = (BlocSimple){ 'P', chargerSprite("images/objects/coin.bmp") };

    // Fonds (backgrounds parallaxe)
    struct { const char *nom; int couches; int theme; } bgs[] = {
        {"sunrise-sky", 4, 0},
        {"mountaign",   4, 1},
        {"sunset-sky",  4, 2},
        {"night-sky",   4, 3},
        {"cave",        5, 4}
    };
    int b;
    for (b = 0; b < 5; b++) {
        for (i = 0; i < bgs[b].couches && i < MAX_BG_LAYERS; i++) {
            sprintf(chemin, "images/world/background/%s/layer%d.bmp", bgs[b].nom, i + 1);
            Sprite *s = chargerSprite(chemin);
            if (s) {
                // On inverse R et B car creeTexture2D attend un format différent de glDrawPixels
                inverserCouleursSprite(s);
                
                // On crée la texture à sa taille d'origine
                tex_fonds[bgs[b].theme][i] = creeTexture2D(s->largeur, s->hauteur, s->donneesARVB);
                
                // On modifie juste sa largeur/hauteur d'affichage pour que 
                // la carte graphique s'occupe du redimensionnement (OpenGL)
                tex_fonds[bgs[b].theme][i]->largeur = (int)(LARGEUR_FENETRE * 1.5f);
                tex_fonds[bgs[b].theme][i]->hauteur = (int)(HAUTEUR_FENETRE * 1.5f);
                
                libererSprite(&s);
            }
        }
    }

    // Animations joueur via chargerAnim()
    // chargerAnim(structure, tableau_frames, nb_frames, vitesse, format, index_depart)
    chargerAnim(&anim_joueur[ANIM_IDLE_D], frames_joueur[ANIM_IDLE_D], 2, 20,
                "images/sprites_hero/idle_right_%02d.bmp", 0);
    chargerAnim(&anim_joueur[ANIM_IDLE_G], frames_joueur[ANIM_IDLE_G], 2, 20,
                "images/sprites_hero/idle_left_%02d.bmp",  0);
    chargerAnim(&anim_joueur[ANIM_WALK_D], frames_joueur[ANIM_WALK_D], 6, 5,
                "images/sprites_hero/walk_right_%02d.bmp", 0);
    chargerAnim(&anim_joueur[ANIM_WALK_G], frames_joueur[ANIM_WALK_G], 6, 5,
                "images/sprites_hero/walk_left_%02d.bmp",  0);
    chargerAnim(&anim_joueur[ANIM_JUMP_D], frames_joueur[ANIM_JUMP_D], 2, 10,
                "images/sprites_hero/jump_right_%02d.bmp", 0);
    chargerAnim(&anim_joueur[ANIM_JUMP_G], frames_joueur[ANIM_JUMP_G], 2, 10,
                "images/sprites_hero/jump_left_%02d.bmp",  0);
    chargerAnim(&anim_joueur[ANIM_DASH_D], frames_joueur[ANIM_DASH_D], 8, 2,
                "images/sprites_hero/dash/dash%d-right.bmp", 1);
    chargerAnim(&anim_joueur[ANIM_DASH_G], frames_joueur[ANIM_DASH_G], 8, 2,
                "images/sprites_hero/dash/dash%d-left.bmp",  1);
    chargerAnim(&anim_joueur[ANIM_DEATH], frames_joueur[ANIM_DEATH], 12, 5,
                "images/sprites_hero/death/frame_%d.bmp", 0);

    // Animations ennemis
    // Demon index 0=fly D, 1=fly G, 2=atk D, 3=atk G, 4=death
    chargerAnim(&anim_demon[0], frames_demon[0], 4, 10,
                "images/demon/right/FLYING_%02d_right.bmp", 0);
    chargerAnim(&anim_demon[1], frames_demon[1], 4, 10,
                "images/demon/left/FLYING_%02d.bmp",  0);
    chargerAnim(&anim_demon[2], frames_demon[2], 8, 8,
                "images/demon/right/ATTACK_%02d_right.bmp", 0);
    chargerAnim(&anim_demon[3], frames_demon[3], 8, 8,
                "images/demon/left/ATTACK_%02d.bmp",  0);
    chargerAnim(&anim_demon[4], frames_demon[4], 6, 5,
                "images/demon/DEATH_%02d.bmp",  0);

    // Slime index 0=walk, 1=attack
    chargerAnim(&anim_slime[0], frames_slime[0], 8, 8,
                "images/green-slime/slime_walk_%02d.bmp",   0);
    chargerAnim(&anim_slime[1], frames_slime[1], 4, 10,
                "images/green-slime/slime_attack_%02d.bmp", 0);

    // Red slime index 0=walk, 1=attack
    chargerAnim(&anim_redslime[0], frames_redslime[0], 8, 6,
                "images/red-slime/walk%d.bmp",   1);
    chargerAnim(&anim_redslime[1], frames_redslime[1], 4, 7,
                "images/red-slime/attack%d.bmp", 1);

    spr_fond_mort = chargerSprite("images/fond_mort.bmp");
    spr_fond_victoire = chargerSprite("images/fond_victoire.bmp");
    spr_fond_menu = chargerSprite("images/fond_menu.bmp");
}

void dessinerTutoriel(JeuEtat *jeu)
{
    if (jeu->niveau_actuel != 0) return;
    
    couleurCourante(255, 255, 255);
    epaisseurDeTrait(2.0f);
    
    afficheChaine("Utilisez les flèches du clavier pour vous déplacer", 14, 100 - jeu->camera_x, 300 - jeu->camera_y);
    afficheChaine("Appuyez 2 fois sur la flèche du haut pour faire un double saut",       14, 1200 - jeu->camera_x, 350 - jeu->camera_y);
    afficheChaine("Appuyez sur la touche E pour faire un dash",       14, 1900 - jeu->camera_x, 250 - jeu->camera_y);
    afficheChaine("Sautez sur le monstre !", 14, 2500 - jeu->camera_x, 300 - jeu->camera_y);
    
    epaisseurDeTrait(1.0f);
}

void dessinerTout(JeuEtat *jeu)
{
    anim_tick++;

    if      (jeu->etat == ETAT_MENU)       { dessinerMenu();              return; }
    else if (jeu->etat == ETAT_AIDE)       { dessinerAide();              return; }
    else if (jeu->etat == ETAT_SELECTION)  { dessinerSelectionNiveau(jeu); return; }
    else if (jeu->etat == ETAT_GAME_OVER)  { dessinerGameOver();          return; }
    else if (jeu->etat == ETAT_VICTOIRE)   { dessinerVictoire(jeu);       return; }

    dessinerFond(jeu);
    dessinerPlateformes(jeu);
    dessinerTutoriel(jeu);
    dessinerObjets(jeu);
    dessinerEnnemis(jeu);
    dessinerJoueur(jeu);
    dessinerHUD(jeu);

    if (jeu->opacite_fondu > 0.0f)
        dessinerFondu(jeu);
}

void dessinerFond(JeuEtat *jeu)
{
    Texture2D **fonds = tex_fonds[themeFond(jeu->niveau_actuel)];

    int i, fond_trouve = 0;
    for (i = 0; i < MAX_BG_LAYERS; i++) {
        if (!fonds[i]) continue;
        fond_trouve = 1;
        int fw = fonds[i]->largeur  > 0 ? fonds[i]->largeur  : LARGEUR_FENETRE;
        int fh = fonds[i]->hauteur  > 0 ? fonds[i]->hauteur  : HAUTEUR_FENETRE;
        int ox = (int)(jeu->camera_x * i * 0.2f) % fw;
        int oy = (int)(jeu->camera_y * i * 0.1f) % fh;
        rectangleSelonTexture(-ox,      -oy,      fonds[i]);
        rectangleSelonTexture(-ox + fw, -oy,      fonds[i]);
        rectangleSelonTexture(-ox,      -oy + fh, fonds[i]);
        rectangleSelonTexture(-ox + fw, -oy + fh, fonds[i]);
    }

    if (!fond_trouve) {
        int couleurs[][3] = {{30,50,80},{15,10,25},{40,30,70},{50,10,10}};
        int idx = (jeu->niveau_actuel >= 1 && jeu->niveau_actuel <= 4)
                  ? jeu->niveau_actuel - 1 : 0;
        effaceFenetre(couleurs[idx][0], couleurs[idx][1], couleurs[idx][2]);
    }
}

// Fonctions de dessin des blocs (statiques, usage interne)
static void dessinerMosaique(Sprite *spr, int x, int y, int larg, int haut)
{
    if (!spr) return;
    int tw = spr->largeur, th = spr->hauteur, tx, ty;
    for (ty = y; ty < y + haut; ty += th)
        for (tx = 0; tx < larg; tx += tw) {
            int dx = x + tx;
            if (dx + tw < 0 || dx > LARGEUR_FENETRE) continue;
            ecrisImageARVB(dx, ty, tw, th, spr->donneesARVB);
        }
}

static void dessinerPlateforme3P(int x, int y, int larg, char type)
{
    Plateforme3P *p = trouverPlateforme(type);
    if (!p || !p->gauche || !p->milieu || !p->droite) {
        couleurCourante(100, 100, 110);
        rectangle(x, y, x + larg, y + 64);
        return;
    }
    int tw = p->milieu->largeur, n = larg / tw, t;
    for (t = 0; t < n; t++) {
        int dx = x + t * tw;
        if (dx + tw < 0 || dx > LARGEUR_FENETRE) continue;
        Sprite *s = (t == 0) ? p->gauche : (t == n-1) ? p->droite : p->milieu;
        ecrisImageARVB(dx, y, s->largeur, s->hauteur, s->donneesARVB);
    }
}

static void dessinerColonne3P(int x, int y, int haut, char type)
{
    Colonne3P *c = trouverColonne(type);
    if (!c || !c->haut || !c->milieu || !c->bas) {
        couleurCourante(100, 100, 110);
        rectangle(x, y, x + 64, y + haut);
        return;
    }
    int th = c->milieu->hauteur, n = haut / th, t;
    for (t = 0; t < n; t++) {
        int dy = y + t * th;
        if (dy + th < 0 || dy > HAUTEUR_FENETRE) continue;
        Sprite *s = (t == 0) ? c->bas : (t == n-1) ? c->haut : c->milieu;
        ecrisImageARVB(x, dy, s->largeur, s->hauteur, s->donneesARVB);
    }
}

static void dessinerDungeon(int x, int y, int larg, int haut, float px, float py)
{
    if (!spr_dungeon_tiles[0]) return;
    int tw = spr_dungeon_tiles[0]->largeur;
    int th = spr_dungeon_tiles[0]->hauteur;
    int tx, ty;
    for (ty = 0; ty < haut; ty += th) {
        for (tx = 0; tx < larg; tx += tw) {
            int dx = x + tx, dy = y + ty;
            if (dx + tw < 0 || dx > LARGEUR_FENETRE) continue;
            if (dy + th < 0 || dy > HAUTEUR_FENETRE) continue;
            int v = ((int)(px+tx) * 73 + (int)(py+ty) * 37) % 4;
            if (v < 0) v = -v;
            Sprite *s = spr_dungeon_tiles[v];
            if (s) ecrisImageARVB(dx, dy, tw, th, s->donneesARVB);
        }
    }
}

void dessinerPlateformes(JeuEtat *jeu)
{
    int i;
    for (i = 0; i < jeu->nb_plateformes; i++) {
        Plateforme *p = &jeu->plateformes[i];
        int x = (int)(p->x - jeu->camera_x);
        int y = (int)(p->y - jeu->camera_y);
        int w = (int)p->largeur, h = (int)p->hauteur;

        if (x + w < 0 || x > LARGEUR_FENETRE) continue;
        if (y + h < 0 || y > HAUTEUR_FENETRE) continue;

        unsigned char t = (unsigned char)p->type;
        if      (t == '#' || t == '=' || t == '_' || t == '-')
            dessinerPlateforme3P(x, y, w, t);
        else if (t == '|')
            dessinerColonne3P(x, y, h, t);
        else if (t == 'D')
            dessinerDungeon(x, y, w, h, p->x, p->y);
        else {
            Sprite *spr = trouverBloc(t);
            if (spr) dessinerMosaique(spr, x, y, w, h);
            else {
                couleurCourante(t == 'X' ? 180 : 100, 30, t == 'X' ? 30 : 100);
                rectangle(x, y, x + w, y + h);
            }
        }
    }
}

void dessinerJoueur(JeuEtat *jeu)
{
    Joueur *j = &jeu->joueur;
    if (!j->vivant) return;
    if (!j->en_mort && j->invulnerable > 0 && (j->invulnerable % 6) < 3) return;

    int x = (int)(j->x - jeu->camera_x);
    int y = (int)(j->y - jeu->camera_y);
    int d = (j->direction == DIR_DROITE);

    /* Choisir l'animation selon l'état */
    AnimSprite *a;
    if      (j->en_mort)  a = &anim_joueur[ANIM_DEATH];
    else if (j->en_dash)  a = &anim_joueur[d ? ANIM_DASH_D : ANIM_DASH_G];
    else if (!j->au_sol)  a = &anim_joueur[d ? ANIM_JUMP_D : ANIM_JUMP_G];
    else if (j->vx != 0)  a = &anim_joueur[d ? ANIM_WALK_D : ANIM_WALK_G];
    else                  a = &anim_joueur[d ? ANIM_IDLE_D : ANIM_IDLE_G];

    if (a->frames[0])
        dessinerAnim(a, x, y);
    else {
        couleurCourante(50, 100, 220);
        rectangle(x, y, x + j->largeur, y + j->hauteur);
    }
}

void dessinerEnnemis(JeuEtat *jeu)
{
    int i;
    for (i = 0; i < jeu->nb_ennemis; i++) {
        Ennemi *e = &jeu->ennemis[i];
        if (!e->vivant) continue;

        int x = (int)(e->x - jeu->camera_x);
        int y = (int)(e->y - jeu->camera_y);
        if (x + e->largeur < 0 || x > LARGEUR_FENETRE) continue;
        if (y + e->hauteur < 0 || y > HAUTEUR_FENETRE) continue;

        /* Sélectionner l'animation selon le type et l'état */
        AnimSprite *a = NULL;
        int d = (e->direction == DIR_DROITE);

        switch (e->type_ennemi) {
            case TYPE_DEMON:
                if (e->en_mort)      a = &anim_demon[4];
                else if (e->en_charge) a = &anim_demon[d ? 2 : 3];
                else                   a = &anim_demon[d ? 0 : 1];
                break;
            case TYPE_SLIME:
                a = &anim_slime[e->en_charge ? 1 : 0];
                break;
            case TYPE_RED_SLIME:
                a = &anim_redslime[e->en_charge ? 1 : 0];
                break;
            default: break;
        }

        if (a && a->frames[0])
            dessinerAnim(a, x, y);
        else {
            couleurCourante(e->en_charge ? 230 : 160, e->en_charge ? 100 : 30, 30);
            rectangle(x, y, x + e->largeur, y + e->hauteur);
        }
    }
}

void dessinerObjets(JeuEtat *jeu)
{
    int i;

    /* Zone de sortie clignotante */
    if (jeu->sortie_x > 0.0f) {
        int sx = (int)(jeu->sortie_x - jeu->camera_x);
        int sy = (int)(jeu->sortie_y - jeu->camera_y);
        if (sx + TILE_SIZE >= 0 && sx <= LARGEUR_FENETRE) {
            int pair = ((int)(jeu->timer * 60) / 30) % 2;
            couleurCourante(pair ? 50 : 30, pair ? 220 : 140, pair ? 80 : 50);
            rectangle(sx, sy, sx + TILE_SIZE, sy + TILE_SIZE * 2);
            couleurCourante(255, 255, 255);
            afficheChaine("SORTIE", 14, sx + 2, sy + TILE_SIZE * 2 + 5);
        }
    }

    /* Pièces avec flottement */
    Sprite *spr_coin = trouverBloc('P');
    for (i = 0; i < jeu->nb_objets; i++) {
        Objet *o = &jeu->objets[i];
        if (o->collectee) continue;

        int x = (int)(o->x - jeu->camera_x);
        int y = (int)(o->y - jeu->camera_y);
        if (x + o->largeur < 0 || x > LARGEUR_FENETRE) continue;

        int t    = anim_tick % 60;
        float fl = 4.0f * (float)(t < 30 ? t : 60 - t) / 30.0f - 2.0f;

        if (spr_coin)
            ecrisImageARVB(x, (int)(y + fl),
                           spr_coin->largeur, spr_coin->hauteur,
                           spr_coin->donneesARVB);
        else {
            couleurCourante(255, 210, 0);
            rectangle(x, y + fl, x + o->largeur, y + fl + o->hauteur);
        }
    }
}

void dessinerHUD(JeuEtat *jeu)
{
    char t[64];
    couleurCourante(0, 0, 0);
    rectangle(0, HAUTEUR_FENETRE - 40, LARGEUR_FENETRE, HAUTEUR_FENETRE);
    couleurCourante(255, 255, 255);
    sprintf(t, "NIVEAU %d", jeu->niveau_actuel);  afficheChaine(t, 18, 20,  HAUTEUR_FENETRE - 30);
    sprintf(t, "VIES: %d",  jeu->joueur.vies);    afficheChaine(t, 18, 200, HAUTEUR_FENETRE - 30);
    sprintf(t, "PIECES: %d",jeu->joueur.pieces);  afficheChaine(t, 18, 400, HAUTEUR_FENETRE - 30);
    epaisseurDeTrait(3.0f);
    sprintf(t, "TEMPS: %d s",(int)jeu->timer);    afficheChaine(t, 18, 650, HAUTEUR_FENETRE - 30);
    epaisseurDeTrait(1.5f);
}

void dessinerFondu(JeuEtat *jeu)
{
    if (jeu->opacite_fondu <= 0.0f) return;
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glColor4ub(0, 0, 0, (unsigned char)jeu->opacite_fondu);
    glRectf(0.0f, 0.0f, (float)LARGEUR_FENETRE, (float)HAUTEUR_FENETRE);
}

void dessinerFondMort(void) {
    if (spr_fond_mort) {
        ecrisImageARVB(0, 0, spr_fond_mort->largeur, spr_fond_mort->hauteur, spr_fond_mort->donneesARVB);
    }
}

void dessinerFondVictoire(void) {
    if (spr_fond_victoire) {
        ecrisImageARVB(0, 0, spr_fond_victoire->largeur, spr_fond_victoire->hauteur, spr_fond_victoire->donneesARVB);
    }
}

void dessinerFondMenu(void) {
    if (spr_fond_menu) {
        ecrisImageARVB(0, 0, spr_fond_menu->largeur, spr_fond_menu->hauteur, spr_fond_menu->donneesARVB);
    }
}