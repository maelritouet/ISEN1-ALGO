#include <stdio.h>
#include <string.h>
#include "gfxlib/GfxLib.h"
#include "gfxlib/BmpLib.h"
#include "rendu.h"
#include "jeu.h"

// ============================================================
//  rendu.c — Module d'affichage (Membre 5)
//
//  Phase 5 : sprites BMP pour le joueur avec animations.
//  Les ennemis, pièces, plateformes restent en rectangles
//  jusqu'à ce qu'on ait leurs sprites.
//
//  Animations joueur :
//  - idle  : 2 frames, change toutes les 20 ticks
//  - walk  : 12 frames, change toutes les 5 ticks
//  - jump  : 2 frames, change toutes les 10 ticks
//
//  À l'oral : "On charge tous les BMP une seule fois au
//  démarrage dans chargerSprites(). À chaque affichage on
//  choisit la bonne frame selon l'état du joueur et on
//  appelle ecrisImage() avec les données RGB du BMP."
// ============================================================

// ------------------------------------------------------------
//  Stockage des sprites chargés en mémoire
//  NULL si le fichier n'a pas pu être chargé
// ------------------------------------------------------------
static DonneesImageRGB *spr_idle_left[2];
static DonneesImageRGB *spr_idle_right[2];
static DonneesImageRGB *spr_walk_left[6];
static DonneesImageRGB *spr_walk_right[6];
static DonneesImageRGB *spr_jump_left[2];
static DonneesImageRGB *spr_jump_right[2];

// Sprites de texture pour les plateformes
static DonneesImageRGB *spr_grass = NULL;
static DonneesImageRGB *spr_dirt  = NULL;

// Compteur global de ticks pour les animations
static int anim_tick = 0;

// ------------------------------------------------------------
//  chargerSprite — Charge un BMP et affiche un warning si manquant
// ------------------------------------------------------------
static DonneesImageRGB *chargerSprite(const char *chemin)
{
    DonneesImageRGB *spr = lisBMPRGB((char *)chemin);
    if (!spr)
        printf("ATTENTION : sprite introuvable : %s\n", chemin);
    return spr;
}

// ------------------------------------------------------------
//  chargerSprites — Appelée UNE SEULE FOIS au démarrage
//  Charge tous les BMP du joueur en mémoire
// ------------------------------------------------------------
void chargerSprites(void)
{
    int i;
    char chemin[128];

    /* Texture des plateformes */
    spr_grass = chargerSprite("images/grass.bmp");
    spr_dirt  = chargerSprite("images/dirt.bmp");

    for (i = 0; i < 2; i++) {
        sprintf(chemin, "images/sprites_hero/idle_left_%02d.bmp", i);
        spr_idle_left[i] = chargerSprite(chemin);

        sprintf(chemin, "images/sprites_hero/idle_right_%02d.bmp", i);
        spr_idle_right[i] = chargerSprite(chemin);

        sprintf(chemin, "images/sprites_hero/jump_left_%02d.bmp", i);
        spr_jump_left[i] = chargerSprite(chemin);

        sprintf(chemin, "images/sprites_hero/jump_right_%02d.bmp", i);
        spr_jump_right[i] = chargerSprite(chemin);
    }

    for (i = 0; i < 6; i++) {
        sprintf(chemin, "images/sprites_hero/walk_left_%02d.bmp", i);
        spr_walk_left[i] = chargerSprite(chemin);

        sprintf(chemin, "images/sprites_hero/walk_right_%02d.bmp", i);
        spr_walk_right[i] = chargerSprite(chemin);
    }
}

// ------------------------------------------------------------
//  dessinerTout — Fonction principale
// ------------------------------------------------------------
void dessinerTout(JeuEtat *jeu)
{
    anim_tick++;

    if (jeu->etat == ETAT_MENU)       { dessinerMenu();                  return; }
    if (jeu->etat == ETAT_SELECTION)  { dessinerSelectionNiveau(jeu);    return; }
    if (jeu->etat == ETAT_GAME_OVER)  { dessinerGameOver();              return; }
    if (jeu->etat == ETAT_VICTOIRE)   { dessinerVictoire();              return; }

    dessinerFond();
    dessinerPlateformes(jeu);
    dessinerObjets(jeu);
    dessinerEnnemis(jeu);
    dessinerJoueur(jeu);
    dessinerHUD(jeu);
}

// ------------------------------------------------------------
//  dessinerFond
// ------------------------------------------------------------
void dessinerFond(void)
{
    effaceFenetre(20, 20, 50);
}

// ------------------------------------------------------------
//  dessinerPlateformes
//
//  Rendu style platformer classique :
//  - Dessus de la plateforme : sprite grass.bmp répété en X
//  - Corps en dessous        : rectangle couleur terre (#7a5230)
//  - Zone mortelle           : rectangle rouge uni
//  - Fallback si BMP absent  : rectangle gris
// ------------------------------------------------------------
void dessinerPlateformes(JeuEtat *jeu)
{
    int i;
    for (i = 0; i < jeu->nb_plateformes; i++)
    {
        Plateforme *p = &jeu->plateformes[i];
        float x_ecran = p->x - jeu->camera_x;

        if (x_ecran + p->largeur < 0 || x_ecran > LARGEUR_FENETRE) continue;

        if (p->mortelle || p->type == 'X')
        {
            /* Zone mortelle : rouge uni */
            couleurCourante(180, 30, 30);
            rectangle(x_ecran, p->y, x_ecran + p->largeur, p->y + p->hauteur);
        }
        else if (p->type == '#')
        {
            /* Bloc standard : herbe sur le dessus, terre en dessous */
            if (spr_grass)
            {
                int tw     = spr_grass->largeurImage;
                int th     = spr_grass->hauteurImage;
                int draw_y = (int)(p->y + p->hauteur) - th;  /* bord haut du tile */
                int tile_x, tile_y;

                /* --- Corps de la plateforme : dirt.bmp --- */
                if (spr_dirt)
                {
                    int dw = spr_dirt->largeurImage;
                    int dh = spr_dirt->hauteurImage;
                    for (tile_y = (int)p->y; tile_y < draw_y; tile_y += dh)
                    {
                        for (tile_x = 0; tile_x < (int)p->largeur; tile_x += dw)
                        {
                            int draw_x = (int)x_ecran + tile_x;
                            if (draw_x + dw < 0 || draw_x > LARGEUR_FENETRE) continue;
                            ecrisImage(draw_x, tile_y, dw, dh, spr_dirt->donneesRGB);
                        }
                    }
                }

                /* --- Dessus : grass.bmp --- */
                for (tile_x = 0; tile_x < (int)p->largeur; tile_x += tw)
                {
                    int draw_x = (int)x_ecran + tile_x;
                    if (draw_x + tw < 0 || draw_x > LARGEUR_FENETRE) continue;
                    ecrisImage(draw_x, draw_y, tw, th, spr_grass->donneesRGB);
                }
            }
            else
            {
                /* Fallback : rectangle gris si BMP absent */
                couleurCourante(100, 100, 110);
                rectangle(x_ecran, p->y, x_ecran + p->largeur, p->y + p->hauteur);
            }
        }
        else if (p->type == 'D')
        {
            /* Bloc pur terre (sans herbe au dessus) */
            if (spr_dirt)
            {
                int dw = spr_dirt->largeurImage;
                int dh = spr_dirt->hauteurImage;
                int tile_x, tile_y;
                for (tile_y = (int)p->y; tile_y < (int)(p->y + p->hauteur); tile_y += dh)
                {
                    for (tile_x = 0; tile_x < (int)p->largeur; tile_x += dw)
                    {
                        int draw_x = (int)x_ecran + tile_x;
                        if (draw_x + dw < 0 || draw_x > LARGEUR_FENETRE) continue;
                        ecrisImage(draw_x, tile_y, dw, dh, spr_dirt->donneesRGB);
                    }
                }
            }
            else
            {
                couleurCourante(90, 60, 30);
                rectangle(x_ecran, p->y, x_ecran + p->largeur, p->y + p->hauteur);
            }
        }
        else
        {
            /* Autre bloc inconnu -> fallback */
            couleurCourante(150, 150, 150);
            rectangle(x_ecran, p->y, x_ecran + p->largeur, p->y + p->hauteur);
        }
    }
}



// ------------------------------------------------------------
//  dessinerJoueur — Affichage avec sprites animés
//
//  États possibles :
//  - En l'air (au_sol == 0)  → animation jump
//  - vx != 0 et au sol       → animation walk
//  - immobile au sol         → animation idle
// ------------------------------------------------------------
void dessinerJoueur(JeuEtat *jeu)
{
    Joueur *j = &jeu->joueur;
    if (!j->vivant) return;

    // Clignotement si invulnérable
    if (j->invulnerable > 0 && (j->invulnerable % 6) < 3) return;

    float x_ecran = j->x - jeu->camera_x;
    float y_ecran = j->y;

    // --- Choisir le tableau de sprites et la frame ---
    DonneesImageRGB **sprites = NULL;
    int nb_frames = 1;
    int vitesse_anim = 5; // Ticks entre chaque frame

    if (!j->au_sol)
    {
        // En l'air → jump
        sprites      = (j->direction == DIR_DROITE) ? spr_jump_right : spr_jump_left;
        nb_frames    = 2;
        vitesse_anim = 10;
    }
    else if (j->vx != 0)
    {
        // Marche → walk (6 frames de 96x48)
        sprites      = (j->direction == DIR_DROITE) ? spr_walk_right : spr_walk_left;
        nb_frames    = 6;
        vitesse_anim = 5;
    }
    else
    {
        // Immobile → idle
        sprites      = (j->direction == DIR_DROITE) ? spr_idle_right : spr_idle_left;
        nb_frames    = 2;
        vitesse_anim = 20;
    }

    // Calcul de la frame courante
    int frame = (anim_tick / vitesse_anim) % nb_frames;

    // --- Affichage ---
    if (sprites && sprites[frame])
    {
        // On a un sprite → on l'affiche
        DonneesImageRGB *spr = sprites[frame];
        ecrisImage((int)x_ecran, (int)y_ecran,
                   spr->largeurImage, spr->hauteurImage,
                   spr->donneesRGB);
    }
    else
    {
        // Fallback : rectangle bleu si sprite manquant
        couleurCourante(50, 100, 220);
        rectangle(x_ecran, y_ecran, x_ecran + j->largeur, y_ecran + j->hauteur);
    }
}

// ------------------------------------------------------------
//  dessinerEnnemis — Rectangles colorés selon le mode
//  Rouge foncé = patrouille, Orange = charge active
// ------------------------------------------------------------
void dessinerEnnemis(JeuEtat *jeu)
{
    int i;
    for (i = 0; i < jeu->nb_ennemis; i++)
    {
        Ennemi *e = &jeu->ennemis[i];
        if (!e->vivant) continue;

        float x_ecran = e->x - jeu->camera_x;
        if (x_ecran + e->largeur < 0 || x_ecran > LARGEUR_FENETRE) continue;

        /* Orange si en charge, rouge foncé en patrouille */
        if (e->en_charge) couleurCourante(230, 100,  20);
        else              couleurCourante(160,  30,  30);

        rectangle(x_ecran, e->y, x_ecran + e->largeur, e->y + e->hauteur);
    }
}

// ------------------------------------------------------------
//  dessinerObjets — Pièces + zone de sortie
// ------------------------------------------------------------
void dessinerObjets(JeuEtat *jeu)
{
    int i;

    // Zone de sortie verte clignotante (position définie par le blueprint)
    if (jeu->sortie_x > 0.0f)
    {
        float sortie_x_ecran = jeu->sortie_x - jeu->camera_x;
        float sortie_y       = jeu->sortie_y;
        float sortie_h       = TILE_SIZE * 2;

        if (sortie_x_ecran + TILE_SIZE >= 0 && sortie_x_ecran <= LARGEUR_FENETRE)
        {
            int tick = (int)(jeu->timer * 60);
            if ((tick / 30) % 2 == 0) couleurCourante(50, 220, 80);
            else                      couleurCourante(30, 140, 50);
            rectangle(sortie_x_ecran, sortie_y,
                      sortie_x_ecran + TILE_SIZE, sortie_y + sortie_h);
            couleurCourante(255, 255, 255);
            afficheChaine("SORTIE", 14, sortie_x_ecran + 2, sortie_y + sortie_h + 5);
        }
    }

    // Pièces
    for (i = 0; i < jeu->nb_objets; i++)
    {
        Objet *o = &jeu->objets[i];
        if (o->collectee) continue;

        float x_ecran = o->x - jeu->camera_x;
        if (x_ecran + o->largeur < 0 || x_ecran > LARGEUR_FENETRE) continue;

        couleurCourante(255, 210, 0);
        rectangle(x_ecran, o->y, x_ecran + o->largeur, o->y + o->hauteur);
    }
}

// ------------------------------------------------------------
//  dessinerHUD
// ------------------------------------------------------------
void dessinerHUD(JeuEtat *jeu)
{
    char texte[64];

    couleurCourante(0, 0, 0);
    rectangle(0, HAUTEUR_FENETRE - 40, LARGEUR_FENETRE, HAUTEUR_FENETRE);

    couleurCourante(255, 255, 255);
    sprintf(texte, "NIVEAU %d", jeu->niveau_actuel);
    afficheChaine(texte, 18, 20, HAUTEUR_FENETRE - 30);

    sprintf(texte, "VIES: %d", jeu->joueur.vies);
    afficheChaine(texte, 18, 200, HAUTEUR_FENETRE - 30);

    sprintf(texte, "PIECES: %d", jeu->joueur.pieces);
    afficheChaine(texte, 18, 400, HAUTEUR_FENETRE - 30);

    sprintf(texte, "TEMPS: %d s", (int)jeu->timer);
    afficheChaine(texte, 18, 650, HAUTEUR_FENETRE - 30);
}

// ------------------------------------------------------------
//  dessinerMenu — Écran d'accueil
// ------------------------------------------------------------
void dessinerMenu(void)
{
    int cx = LARGEUR_FENETRE / 2;
    int cy = HAUTEUR_FENETRE / 2;

    /* Fond dégradé bleu nuit */
    effaceFenetre(10, 12, 35);

    /* Titre */
    couleurCourante(200, 160, 50);
    afficheChaine("MEDIEVAL FANTASY", 48, cx - 310, cy + 80);

    /* Ligne de séparation visuelle */
    couleurCourante(200, 160, 50);
    rectangle(cx - 340, cy + 65, cx + 340, cy + 67);

    /* Option : JOUER */
    couleurCourante(255, 255, 255);
    afficheChaine("[ ENTREE ]  Jouer", 24, cx - 150, cy);

    /* Option : Quitter */
    couleurCourante(180, 180, 180);
    afficheChaine("[ Q ]       Quitter", 20, cx - 140, cy - 50);

    /* Crédits discrets */
    couleurCourante(100, 100, 120);
    afficheChaine("ISEN Mediterranee — CIN1 2026", 14, cx - 190, 60);
}

// ------------------------------------------------------------
//  dessinerSelectionNiveau — Écran de sélection de niveau
//
//  Affiche la liste des niveaux :
//   - Niveau sélectionné : texte or + flèche ">"
//   - Niveaux disponibles non sélectionnés : blanc
//   - Niveaux non disponibles (> nb_niveaux) : gris
// ------------------------------------------------------------
void dessinerSelectionNiveau(JeuEtat *jeu)
{
    /* Noms des niveaux (jusqu'à 3 pour l'instant) */
    const char *noms_niveaux[3] = {
        "Niveau 1  -  Plaines medievales",
        "Niveau 2  -  Donjon souterrain",
        "Niveau 3  -  Forteresse du Dragon"
    };
    const int NB_LIGNES = 3;
    int i;
    int cx = LARGEUR_FENETRE / 2;
    int cy = HAUTEUR_FENETRE / 2;

    /* Fond */
    effaceFenetre(10, 12, 35);

    /* Titre */
    couleurCourante(200, 160, 50);
    afficheChaine("CHOISIR UN NIVEAU", 36, cx - 240, cy + 190);

    /* Ligne de séparation */
    couleurCourante(200, 160, 50);
    rectangle(cx - 340, cy + 177, cx + 340, cy + 179);

    /* Liste des niveaux */
    for (i = 0; i < NB_LIGNES; i++)
    {
        int y_ligne = (cy + 100) - i * 60;  /* empilé du bas vers le haut */
        int selectionne = (i + 1 == jeu->selection_niveau);
        int disponible  = (i + 1 <= jeu->nb_niveaux);

        if (selectionne && disponible)
        {
            /* Sélection courante : or + flèche */
            couleurCourante(255, 210, 50);
            afficheChaine(">", 28, cx - 375, y_ligne);
            afficheChaine(noms_niveaux[i], 26, cx - 340, y_ligne);
        }
        else if (disponible)
        {
            /* Disponible non sélectionné : blanc */
            couleurCourante(200, 200, 200);
            afficheChaine(noms_niveaux[i], 24, cx - 340, y_ligne);
        }
        else
        {
            /* Verrouillé : gris + "(A venir)" */
            couleurCourante(90, 90, 110);
            afficheChaine(noms_niveaux[i], 22, cx - 340, y_ligne);
            afficheChaine("(A venir)", 16, cx + 180, y_ligne);
        }
    }

    /* Instructions de navigation */
    couleurCourante(140, 140, 160);
    afficheChaine("HAUT / BAS  pour naviguer", 16, cx - 180, 140);
    afficheChaine("ENTREE      pour lancer",   16, cx - 180, 115);
    afficheChaine("ECHAP       pour revenir",  16, cx - 180,  90);
}

void dessinerGameOver(void)
{
    int cx = LARGEUR_FENETRE / 2;
    int cy = HAUTEUR_FENETRE / 2;
    effaceFenetre(10, 0, 0);
    couleurCourante(220, 50, 50);
    afficheChaine("GAME OVER", 50, cx - 160, cy + 40);
    couleurCourante(255, 255, 255);
    afficheChaine("Appuie sur ENTREE pour recommencer", 20, cx - 240, cy - 60);
}

void dessinerVictoire(void)
{
    int cx = LARGEUR_FENETRE / 2;
    int cy = HAUTEUR_FENETRE / 2;
    effaceFenetre(0, 20, 10);
    couleurCourante(80, 220, 80);
    afficheChaine("VICTOIRE !", 50, cx - 160, cy + 40);
    couleurCourante(255, 255, 255);
    afficheChaine("Appuie sur ENTREE pour rejouer", 20, cx - 220, cy - 60);
}