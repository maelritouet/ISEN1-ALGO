#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gfxlib/GfxLib.h"
#include "gfxlib/BmpLib.h"
#include "rendu.h"
#include "jeu.h"

// ============================================================
//  rendu.c — Module d'affichage (Membre 5)
//
//  Phase 5 : sprites BMP pour le joueur avec animations.
//  Les ennemis, pièces, plateformes restent en rectangles
//  jusqu'à ce qu'on ait leurs sprites.
//
//  Animations joueur :
//  - idle  : 2 frames, change toutes les 20 ticks
//  - walk  : 12 frames, change toutes les 5 ticks
//  - jump  : 2 frames, change toutes les 10 ticks
//
//  À l'oral : "On charge tous les BMP une seule fois au
//  démarrage dans chargerSprites(). À chaque affichage on
//  choisit la bonne frame selon l'état du joueur et on
//  appelle ecrisImage() avec les données RGB du BMP."
// ============================================================

// ------------------------------------------------------------
//  Stockage des sprites chargés en mémoire
//  NULL si le fichier n'a pas pu être chargé
// ------------------------------------------------------------
static Sprite *spr_idle_left[2];
static Sprite *spr_idle_right[2];
static Sprite *spr_walk_left[6];
static Sprite *spr_walk_right[6];
static Sprite *spr_jump_left[2];
static Sprite *spr_jump_right[2];

// -------------------------------------------------------------------
//  Sprites de texture pour le monde
//
//  Plateformes '#' : rendu en 3 parties (bord gauche, milieu, bord droit)
//  Blocs 'D'       : roche répétée
//  Zones 'X'       : lave répétée
// -------------------------------------------------------------------
static Sprite *spr_platform1 = NULL;  /* bord gauche */
static Sprite *spr_platform2 = NULL;  /* milieu (répété) */
static Sprite *spr_platform3 = NULL;  /* bord droit */
static Sprite *spr_rock      = NULL;  /* bloc de roche (D) */
static Sprite *spr_lava      = NULL;  /* zone mortelle (X) */

/* Nouveaux blocs simples */
static Sprite *spr_bluebricks = NULL; /* 'B' */
static Sprite *spr_dirt       = NULL; /* 'd' */
static Sprite *spr_grassdirt  = NULL; /* 'g' */
static Sprite *spr_gravel     = NULL; /* 'v' */
static Sprite *spr_ice        = NULL; /* 'I' */
static Sprite *spr_planks     = NULL; /* 'p' */
static Sprite *spr_purple1    = NULL; /* '1' */
static Sprite *spr_purple2    = NULL; /* '2' */
static Sprite *spr_redbricks  = NULL; /* 'R' */
static Sprite *spr_sand       = NULL; /* 's' */
static Sprite *spr_snow       = NULL; /* 'W' */
static Sprite *spr_stone      = NULL; /* 'T' */
static Sprite *spr_wood       = NULL; /* 'w' */
static Sprite *spr_coin       = NULL; /* pièce d'or */

/* Fonds de niveaux — un par niveau */
static Sprite *spr_fond_niveau1 = NULL;
static Sprite *spr_fond_niveau2 = NULL;

// -------------------------------------------------------------------
//  Sprites d'ennemis — organisés par type
//
//  Pour ajouter un nouveau type d'ennemi :
//  1. Ajouter un #define TYPE_XXX dans jeu.h
//  2. Ajouter des tableaux de sprites ici
//  3. Charger les BMP dans chargerSprites()
//  4. Ajouter un case dans dessinerEnnemis()
// -------------------------------------------------------------------

// Chevalier Gobelin : 2 frames par direction (marche simple)
#define GOBELIN_NB_FRAMES  2
#define GOBELIN_ANIM_SPEED 15  /* ticks entre chaque frame */
static Sprite *spr_gobelin_left[GOBELIN_NB_FRAMES];
static Sprite *spr_gobelin_right[GOBELIN_NB_FRAMES];

// Slime : 8 frames marche, 4 frames attaque
#define SLIME_WALK_FRAMES   8
#define SLIME_ATTACK_FRAMES 4
static Sprite *spr_slime_walk[SLIME_WALK_FRAMES];
static Sprite *spr_slime_attack[SLIME_ATTACK_FRAMES];

// Compteur global de ticks pour les animations
static int anim_tick = 0;

// -------------------------------------------------------------------
#define TRANSPARENT_R  255
#define TRANSPARENT_G    0
#define TRANSPARENT_B  255

// ------------------------------------------------------------
//  chargerSprite — Charge un BMP, convertit en ARVB (Transparence)
// ------------------------------------------------------------
static Sprite *chargerSprite(const char *chemin)
{
    DonneesImageRGB *bmp = lisBMPRGB((char *)chemin);
    if (!bmp)
    {
        printf("ATTENTION : sprite introuvable : %s\n", chemin);
        return NULL;
    }

    Sprite *spr = (Sprite *)malloc(sizeof(Sprite));
    spr->largeur = bmp->largeurImage;
    spr->hauteur = bmp->hauteurImage;

    int nb_pixels = spr->largeur * spr->hauteur;
    spr->donneesARVB = (int *)malloc(nb_pixels * sizeof(int));

    const unsigned char *src = bmp->donneesRGB;
    unsigned char *dst = (unsigned char *)spr->donneesARVB;

    for (int i = 0; i < nb_pixels; i++)
    {
        unsigned char b = src[0];
        unsigned char v = src[1];
        unsigned char r = src[2];

        dst[0] = b;  /* Bleu  */
        dst[1] = v;  /* Vert  */
        dst[2] = r;  /* Rouge */

        /* Color key : si le pixel est magenta → alpha = 0 (transparent) */
        if (r == TRANSPARENT_R && v == TRANSPARENT_G && b == TRANSPARENT_B)
            dst[3] = 0x00;
        else
            dst[3] = 0xFF;

        src += 3;
        dst += 4;
    }

    libereDonneesImageRGB(&bmp);
    return spr;
}

// ------------------------------------------------------------
//  libererSprites — Libère la mémoire à la fin du jeu
// ------------------------------------------------------------
static void libererSprite(Sprite **spr)
{
    if (*spr)
    {
        free((*spr)->donneesARVB);
        free(*spr);
        *spr = NULL;
    }
}

void libererSprites(void)
{
    int i;
    libererSprite(&spr_platform1);
    libererSprite(&spr_platform2);
    libererSprite(&spr_platform3);
    libererSprite(&spr_rock);
    libererSprite(&spr_lava);

    libererSprite(&spr_bluebricks);
    libererSprite(&spr_dirt);
    libererSprite(&spr_grassdirt);
    libererSprite(&spr_gravel);
    libererSprite(&spr_ice);
    libererSprite(&spr_planks);
    libererSprite(&spr_purple1);
    libererSprite(&spr_purple2);
    libererSprite(&spr_redbricks);
    libererSprite(&spr_sand);
    libererSprite(&spr_snow);
    libererSprite(&spr_stone);
    libererSprite(&spr_wood);
    libererSprite(&spr_coin);
    libererSprite(&spr_fond_niveau1);
    libererSprite(&spr_fond_niveau2);

    for (i = 0; i < 2; i++)
    {
        libererSprite(&spr_idle_left[i]);
        libererSprite(&spr_idle_right[i]);
        libererSprite(&spr_jump_left[i]);
        libererSprite(&spr_jump_right[i]);
    }
    for (i = 0; i < 6; i++)
    {
        libererSprite(&spr_walk_left[i]);
        libererSprite(&spr_walk_right[i]);
    }

    for (i = 0; i < GOBELIN_NB_FRAMES; i++)
    {
        libererSprite(&spr_gobelin_left[i]);
        libererSprite(&spr_gobelin_right[i]);
    }
    for (i = 0; i < SLIME_WALK_FRAMES; i++)
        libererSprite(&spr_slime_walk[i]);
    for (i = 0; i < SLIME_ATTACK_FRAMES; i++)
        libererSprite(&spr_slime_attack[i]);
}

// ------------------------------------------------------------
//  chargerSprites — Appelée UNE SEULE FOIS au démarrage
//  Charge tous les BMP du joueur en mémoire
// ------------------------------------------------------------
void chargerSprites(void)
{
    int i;
    char chemin[128];

    /* Textures du monde */
    spr_platform1 = chargerSprite("images/world/platform1.bmp");
    spr_platform2 = chargerSprite("images/world/platform2.bmp");
    spr_platform3 = chargerSprite("images/world/plateform3.bmp");
    spr_rock      = chargerSprite("images/world/rock.bmp");
    spr_lava      = chargerSprite("images/world/lava.bmp");

    spr_bluebricks = chargerSprite("images/world/bluebricks.bmp");
    spr_dirt       = chargerSprite("images/world/dirt.bmp");
    spr_grassdirt  = chargerSprite("images/world/grassdirt.bmp");
    spr_gravel     = chargerSprite("images/world/gravel.bmp");
    spr_ice        = chargerSprite("images/world/ice.bmp");
    spr_planks     = chargerSprite("images/world/planks.bmp");
    spr_purple1    = chargerSprite("images/world/purple_dongeon_tile_01.bmp");
    spr_purple2    = chargerSprite("images/world/purple_dongeon_tile_02.bmp");
    spr_redbricks  = chargerSprite("images/world/redbricks.bmp");
    spr_sand       = chargerSprite("images/world/sand.bmp");
    spr_snow       = chargerSprite("images/world/snow.bmp");
    spr_stone      = chargerSprite("images/world/stone.bmp");
    spr_wood       = chargerSprite("images/world/wood.bmp");
    spr_coin       = chargerSprite("images/world/coin.bmp");

    /* Fonds de niveaux */
    spr_fond_niveau1 = chargerSprite("images/world/fond_niveau1.bmp");
    spr_fond_niveau2 = chargerSprite("images/world/fond_niveau2.bmp");

    /* --- Sprites du joueur --- */
    for (i = 0; i < 2; i++) {
        sprintf(chemin, "images/sprites_hero/idle_left_%02d.bmp", i);
        spr_idle_left[i] = chargerSprite(chemin);

        sprintf(chemin, "images/sprites_hero/idle_right_%02d.bmp", i);
        spr_idle_right[i] = chargerSprite(chemin);

        sprintf(chemin, "images/sprites_hero/jump_left_%02d.bmp", i);
        spr_jump_left[i] = chargerSprite(chemin);

        sprintf(chemin, "images/sprites_hero/jump_right_%02d.bmp", i);
        spr_jump_right[i] = chargerSprite(chemin);
    }

    for (i = 0; i < 6; i++) {
        sprintf(chemin, "images/sprites_hero/walk_left_%02d.bmp", i);
        spr_walk_left[i] = chargerSprite(chemin);

        sprintf(chemin, "images/sprites_hero/walk_right_%02d.bmp", i);
        spr_walk_right[i] = chargerSprite(chemin);
    }

    /* --- Sprites des ennemis : Chevalier Gobelin --- */
    for (i = 0; i < GOBELIN_NB_FRAMES; i++) {
        sprintf(chemin, "images/knight-gobelin/enemy_green_knight_%02d_left.bmp", i + 1);
        spr_gobelin_left[i] = chargerSprite(chemin);

        sprintf(chemin, "images/knight-gobelin/enemy_green_knight_%02d_right.bmp", i + 1);
        spr_gobelin_right[i] = chargerSprite(chemin);
    }

    /* --- Sprites des ennemis : Slime --- */
    for (i = 0; i < SLIME_WALK_FRAMES; i++) {
        sprintf(chemin, "images/green-slime/slime_walk_%02d.bmp", i);
        spr_slime_walk[i] = chargerSprite(chemin);
    }
    for (i = 0; i < SLIME_ATTACK_FRAMES; i++) {
        sprintf(chemin, "images/green-slime/slime_attack_%02d.bmp", i);
        spr_slime_attack[i] = chargerSprite(chemin);
    }
}

// ------------------------------------------------------------
//  dessinerTout — Fonction principale
// ------------------------------------------------------------
void dessinerTout(JeuEtat *jeu)
{
    anim_tick++;

    if (jeu->etat == ETAT_MENU)       { dessinerMenu();                  return; }
    if (jeu->etat == ETAT_AIDE)       { dessinerAide();                   return; }
    if (jeu->etat == ETAT_SELECTION)  { dessinerSelectionNiveau(jeu);    return; }
    if (jeu->etat == ETAT_GAME_OVER)  { dessinerGameOver();              return; }
    if (jeu->etat == ETAT_VICTOIRE)   { dessinerVictoire(jeu);              return; }

    dessinerFond(jeu);
    dessinerPlateformes(jeu);
    dessinerObjets(jeu);
    dessinerEnnemis(jeu);
    dessinerJoueur(jeu);
    dessinerHUD(jeu);
}

// ------------------------------------------------------------
//  dessinerFond — Arrière-plan du niveau avec parallaxe
//
//  Parallaxe : le fond défile à 20% de la vitesse de la caméra.
//  Effet de profondeur — le fond semble loin derrière le niveau.
//
//  Si le sprite du fond est manquant → couleur unie de fallback.
//
//  Pour ajouter un niveau : ajouter un case + spr_fond_niveauX.
// ------------------------------------------------------------
void dessinerFond(JeuEtat *jeu)
{
    Sprite *fond = NULL;

    /* Choisir le fond selon le niveau actuel */
    switch (jeu->niveau_actuel)
    {
        case 1: fond = spr_fond_niveau1; break;
        case 2: fond = spr_fond_niveau2; break;
        default: fond = spr_fond_niveau1; break;
    }

    if (fond)
    {
        /* Parallaxe : le fond défile à 20% de la vitesse de la caméra.
         *
         * On calcule un offset entre 0 et fond_largeur (modulo).
         * On affiche TOUJOURS deux copies côte à côte :
         *   - Copie 1 à x = -offset_x
         *   - Copie 2 à x = fond_largeur - offset_x
         * Au moins une des deux couvre toujours l'écran entier.
         */
        int fond_largeur = fond->largeur > 0 ? fond->largeur : LARGEUR_FENETRE;
        int offset_x     = (int)(jeu->camera_x * 0.2f) % fond_largeur;
        if (offset_x < 0) offset_x = 0;

        ecrisImageARVB(-offset_x, 0,
                       fond_largeur, HAUTEUR_FENETRE,
                       fond->donneesARVB);
        ecrisImageARVB(fond_largeur - offset_x, 0,
                       fond_largeur, HAUTEUR_FENETRE,
                       fond->donneesARVB);
    }
    else
    {
        /* Fallback : couleur unie selon le niveau */
        switch (jeu->niveau_actuel)
        {
            case 1: effaceFenetre(30, 50, 80);  break; /* Bleu nuit */
            case 2: effaceFenetre(15, 10, 25);  break; /* Violet donjon */
            default: effaceFenetre(20, 20, 50); break;
        }
    }
}

// ------------------------------------------------------------
//  dessinerPlateformes
//
//  Rendu par type de bloc :
//  - '#' : plateforme avec bords (platform1 | platform2×N | platform3)
//  - 'D' : roche répétée (rock.bmp)
//  - 'X' : lave répétée (lava.bmp)
//  - Fallback : rectangle gris
// ------------------------------------------------------------
void dessinerPlateformes(JeuEtat *jeu)
{
    int i;
    for (i = 0; i < jeu->nb_plateformes; i++)
    {
        Plateforme *p = &jeu->plateformes[i];
        float x_ecran = p->x - jeu->camera_x;

        if (x_ecran + p->largeur < 0 || x_ecran > LARGEUR_FENETRE) continue;

        if (p->mortelle || p->type == 'X')
        {
            /* --- Zone mortelle : lave --- */
            if (spr_lava)
            {
                int tw = spr_lava->largeur;
                int th = spr_lava->hauteur;
                int tile_x, tile_y;
                for (tile_y = (int)p->y; tile_y < (int)(p->y + p->hauteur); tile_y += th)
                {
                    for (tile_x = 0; tile_x < (int)p->largeur; tile_x += tw)
                    {
                        int draw_x = (int)x_ecran + tile_x;
                        if (draw_x + tw < 0 || draw_x > LARGEUR_FENETRE) continue;
                        ecrisImageARVB(draw_x, tile_y, tw, th, spr_lava->donneesARVB);
                    }
                }
            }
            else
            {
                couleurCourante(180, 30, 30);
                rectangle(x_ecran, p->y, x_ecran + p->largeur, p->y + p->hauteur);
            }
        }
        else if (p->type == '#')
        {
            /* --- Plateforme avec bords gauche/milieu/droite --- */
            if (spr_platform1 && spr_platform2 && spr_platform3)
            {
                int tw = spr_platform2->largeur;
                int nb_tiles = (int)(p->largeur / tw);
                int t;

                for (t = 0; t < nb_tiles; t++)
                {
                    int draw_x = (int)x_ecran + t * tw;
                    int draw_y = (int)p->y;
                    Sprite *spr;

                    if (draw_x + tw < 0 || draw_x > LARGEUR_FENETRE) continue;

                    if (t == 0)
                        spr = spr_platform1;       /* bord gauche */
                    else if (t == nb_tiles - 1)
                        spr = spr_platform3;       /* bord droit */
                    else
                        spr = spr_platform2;       /* milieu */

                    ecrisImageARVB(draw_x, draw_y,
                               spr->largeur, spr->hauteur,
                               spr->donneesARVB);
                }
            }
            else
            {
                couleurCourante(100, 100, 110);
                rectangle(x_ecran, p->y, x_ecran + p->largeur, p->y + p->hauteur);
            }
        }
        else
        {
            /* --- Autres blocs simples --- */
            Sprite *spr = NULL;
            switch (p->type)
            {
                case 'D': spr = spr_rock; break;
                case 'B': spr = spr_bluebricks; break;
                case 'd': spr = spr_dirt; break;
                case 'g': spr = spr_grassdirt; break;
                case 'v': spr = spr_gravel; break;
                case 'I': spr = spr_ice; break;
                case 'p': spr = spr_planks; break;
                case '1': spr = spr_purple1; break;
                case '2': spr = spr_purple2; break;
                case 'R': spr = spr_redbricks; break;
                case 's': spr = spr_sand; break;
                case 'W': spr = spr_snow; break;
                case 'T': spr = spr_stone; break;
                case 'w': spr = spr_wood; break;
            }

            if (spr)
            {
                int tw = spr->largeur;
                int th = spr->hauteur;
                int tile_x, tile_y;
                for (tile_y = (int)p->y; tile_y < (int)(p->y + p->hauteur); tile_y += th)
                {
                    for (tile_x = 0; tile_x < (int)p->largeur; tile_x += tw)
                    {
                        int draw_x = (int)x_ecran + tile_x;
                        if (draw_x + tw < 0 || draw_x > LARGEUR_FENETRE) continue;
                        ecrisImageARVB(draw_x, tile_y, tw, th, spr->donneesARVB);
                    }
                }
            }
            else
            {
                /* Fallback si sprite non chargé ou inconnu */
                couleurCourante(100, 100, 100);
                rectangle(x_ecran, p->y, x_ecran + p->largeur, p->y + p->hauteur);
            }
        }
    }
}



// ------------------------------------------------------------
//  dessinerJoueur — Affichage avec sprites animés
//
//  États possibles :
//  - En l'air (au_sol == 0)  → animation jump
//  - vx != 0 et au sol       → animation walk
//  - immobile au sol         → animation idle
// ------------------------------------------------------------
void dessinerJoueur(JeuEtat *jeu)
{
    Joueur *j = &jeu->joueur;
    if (!j->vivant) return;

    // Clignotement si invulnérable
    if (j->invulnerable > 0 && (j->invulnerable % 6) < 3) return;

    float x_ecran = j->x - jeu->camera_x;
    float y_ecran = j->y;

    // --- Choisir le tableau de sprites et la frame ---
    Sprite **sprites = NULL;
    int nb_frames = 1;
    int vitesse_anim = 5; // Ticks entre chaque frame

    if (!j->au_sol)
    {
        // En l'air → jump
        sprites      = (j->direction == DIR_DROITE) ? spr_jump_right : spr_jump_left;
        nb_frames    = 2;
        vitesse_anim = 10;
    }
    else if (j->vx != 0)
    {
        // Marche → walk (6 frames de 96x48)
        sprites      = (j->direction == DIR_DROITE) ? spr_walk_right : spr_walk_left;
        nb_frames    = 6;
        vitesse_anim = 5;
    }
    else
    {
        // Immobile → idle
        sprites      = (j->direction == DIR_DROITE) ? spr_idle_right : spr_idle_left;
        nb_frames    = 2;
        vitesse_anim = 20;
    }

    // Calcul de la frame courante
    int frame = (anim_tick / vitesse_anim) % nb_frames;

    // --- Affichage ---
    if (sprites && sprites[frame])
    {
        // On a un sprite → on l'affiche
        Sprite *spr = sprites[frame];
        ecrisImageARVB((int)x_ecran, (int)y_ecran,
                   spr->largeur, spr->hauteur,
                   spr->donneesARVB);
    }
    else
    {
        // Fallback : rectangle bleu si sprite manquant
        couleurCourante(50, 100, 220);
        rectangle(x_ecran, y_ecran, x_ecran + j->largeur, y_ecran + j->hauteur);
    }
}

// ------------------------------------------------------------
//  dessinerEnnemis — Affichage avec sprites animés par type
//
//  Chaque type d'ennemi a son propre set de sprites.
//  Pour ajouter un type : ajouter un case dans le switch ci-dessous.
//  Fallback : rectangle coloré si sprites manquants.
// ------------------------------------------------------------
void dessinerEnnemis(JeuEtat *jeu)
{
    int i;
    for (i = 0; i < jeu->nb_ennemis; i++)
    {
        Ennemi *e = &jeu->ennemis[i];
        if (!e->vivant) continue;

        float x_ecran = e->x - jeu->camera_x;
        if (x_ecran + e->largeur < 0 || x_ecran > LARGEUR_FENETRE) continue;

        /* --- Sélection du sprite selon le type d'ennemi --- */
        Sprite **sprites = NULL;
        int nb_frames    = 1;
        int vitesse_anim = 15;

        switch (e->type_ennemi)
        {
            case TYPE_CHEVALIER_GOBELIN:
                sprites      = (e->direction == DIR_DROITE) ? spr_gobelin_right : spr_gobelin_left;
                nb_frames    = GOBELIN_NB_FRAMES;
                vitesse_anim = GOBELIN_ANIM_SPEED;
                break;

            case TYPE_SLIME:
                if (e->en_charge) {
                    sprites      = spr_slime_attack;
                    nb_frames    = SLIME_ATTACK_FRAMES;
                    vitesse_anim = 10;
                } else {
                    sprites      = spr_slime_walk;
                    nb_frames    = SLIME_WALK_FRAMES;
                    vitesse_anim = 8;
                }
                break;

            default:
                break;
        }

        /* --- Calcul de la frame courante --- */
        int frame = (anim_tick / vitesse_anim) % nb_frames;

        /* --- Affichage --- */
        if (sprites && sprites[frame])
        {
            Sprite *spr = sprites[frame];
            ecrisImageARVB((int)x_ecran, (int)e->y,
                       spr->largeur, spr->hauteur,
                       spr->donneesARVB);
        }
        else
        {
            /* Fallback : rectangle coloré si sprite manquant */
            if (e->en_charge) couleurCourante(230, 100,  20);
            else              couleurCourante(160,  30,  30);
            rectangle(x_ecran, e->y, x_ecran + e->largeur, e->y + e->hauteur);
        }
    }
}

// ------------------------------------------------------------
//  dessinerObjets — Pièces + zone de sortie
// ------------------------------------------------------------
void dessinerObjets(JeuEtat *jeu)
{
    int i;

    // Zone de sortie verte clignotante (position définie par le blueprint)
    if (jeu->sortie_x > 0.0f)
    {
        float sortie_x_ecran = jeu->sortie_x - jeu->camera_x;
        float sortie_y       = jeu->sortie_y;
        float sortie_h       = TILE_SIZE * 2;

        if (sortie_x_ecran + TILE_SIZE >= 0 && sortie_x_ecran <= LARGEUR_FENETRE)
        {
            int tick = (int)(jeu->timer * 60);
            if ((tick / 30) % 2 == 0) couleurCourante(50, 220, 80);
            else                      couleurCourante(30, 140, 50);
            rectangle(sortie_x_ecran, sortie_y,
                      sortie_x_ecran + TILE_SIZE, sortie_y + sortie_h);
            couleurCourante(255, 255, 255);
            afficheChaine("SORTIE", 14, sortie_x_ecran + 2, sortie_y + sortie_h + 5);
        }
    }

    // Pièces — sprite coin avec animation de flottement vertical
    for (i = 0; i < jeu->nb_objets; i++)
    {
        Objet *o = &jeu->objets[i];
        if (o->collectee) continue;

        float x_ecran = o->x - jeu->camera_x;
        if (x_ecran + o->largeur < 0 || x_ecran > LARGEUR_FENETRE) continue;

        /* Flottement : offset sinusoïdal de ±4px toutes les ~60 ticks */
        float flottement = 4.0f * (float)(anim_tick % 60 < 30
                                         ? anim_tick % 30
                                         : 30 - anim_tick % 30) / 15.0f - 4.0f;

        if (spr_coin)
        {
            /* Utiliser les dimensions réelles du sprite plutôt que
             * la hitbox de l'objet — évite l'écrasement de l'image */
            ecrisImageARVB((int)x_ecran,
                           (int)(o->y + flottement),
                           spr_coin->largeur, spr_coin->hauteur,
                           spr_coin->donneesARVB);
        }
        else
        {
            /* Fallback rectangle jaune si coin.bmp manquant */
            couleurCourante(255, 210, 0);
            rectangle(x_ecran, o->y + flottement,
                      x_ecran + o->largeur, o->y + flottement + o->hauteur);
        }
    }
}

// ------------------------------------------------------------
//  dessinerHUD
// ------------------------------------------------------------
void dessinerHUD(JeuEtat *jeu)
{
    char texte[64];

    couleurCourante(0, 0, 0);
    rectangle(0, HAUTEUR_FENETRE - 40, LARGEUR_FENETRE, HAUTEUR_FENETRE);

    couleurCourante(255, 255, 255);
    sprintf(texte, "NIVEAU %d", jeu->niveau_actuel);
    afficheChaine(texte, 18, 20, HAUTEUR_FENETRE - 30);

    sprintf(texte, "VIES: %d", jeu->joueur.vies);
    afficheChaine(texte, 18, 200, HAUTEUR_FENETRE - 30);

    sprintf(texte, "PIECES: %d", jeu->joueur.pieces);
    afficheChaine(texte, 18, 400, HAUTEUR_FENETRE - 30);

    epaisseurDeTrait(3.0f);
    sprintf(texte, "TEMPS: %d s", (int)jeu->timer);
    afficheChaine(texte, 18, 650, HAUTEUR_FENETRE - 30);
    epaisseurDeTrait(1.5f);
}

// ------------------------------------------------------------
//  dessinerMenu — Écran d'accueil
// ------------------------------------------------------------
void dessinerMenu(void)
{
    int cx = LARGEUR_FENETRE / 2;
    int cy = HAUTEUR_FENETRE / 2;

    /* Fond dégradé bleu nuit */
    effaceFenetre(10, 12, 35);

    /* Titre */
    epaisseurDeTrait(6.0f);
    couleurCourante(200, 160, 50);
    afficheChaine("MEDIEVAL FANTASY", 48, cx - 310, cy + 80);

    /* Ligne de séparation visuelle */
    couleurCourante(200, 160, 50);
    rectangle(cx - 340, cy + 65, cx + 340, cy + 67);

    /* Option : JOUER */
    epaisseurDeTrait(4.0f);
    couleurCourante(255, 255, 255);
    afficheChaine("[ ENTREE ]  Jouer", 24, cx - 150, cy);

    /* Option : Quitter */
    couleurCourante(180, 180, 180);
    afficheChaine("[ Q ]       Quitter", 20, cx - 140, cy - 50);

    /* Option : Aide */
    couleurCourante(140, 200, 255);
    afficheChaine("[ H ]       Aide / Touches", 20, cx - 140, cy - 100);

    /* Crédits discrets */
    epaisseurDeTrait(2.5f);
    couleurCourante(100, 100, 120);
    afficheChaine("ISEN Mediterranee — CIN1 2026", 14, cx - 190, 60);

    epaisseurDeTrait(1.0f);
}

// ------------------------------------------------------------
//  dessinerSelectionNiveau — Écran de sélection de niveau
//
//  Affiche la liste des niveaux :
//   - Niveau sélectionné : texte or + flèche ">"
//   - Niveaux disponibles non sélectionnés : blanc
//   - Niveaux non disponibles (> nb_niveaux) : gris
// ------------------------------------------------------------
void dessinerSelectionNiveau(JeuEtat *jeu)
{
    /* Noms des niveaux (jusqu'à 3 pour l'instant) */
    const char *noms_niveaux[3] = {
        "Niveau 1  -  Plaines medievales",
        "Niveau 2  -  Donjon souterrain",
        "Niveau 3  -  Forteresse du Dragon"
    };
    const int NB_LIGNES = 3;
    int i;
    int cx = LARGEUR_FENETRE / 2;
    int cy = HAUTEUR_FENETRE / 2;

    /* Fond */
    effaceFenetre(10, 12, 35);

    /* Titre */
    epaisseurDeTrait(5.0f);
    couleurCourante(200, 160, 50);
    afficheChaine("CHOISIR UN NIVEAU", 36, cx - 240, cy + 190);
    epaisseurDeTrait(3.0f);

    /* Ligne de séparation */
    couleurCourante(200, 160, 50);
    rectangle(cx - 340, cy + 177, cx + 340, cy + 179);

    /* Liste des niveaux */
    for (i = 0; i < NB_LIGNES; i++)
    {
        int y_ligne = (cy + 100) - i * 60;  /* empilé du bas vers le haut */
        int selectionne = (i + 1 == jeu->selection_niveau);
        int disponible  = (i + 1 <= jeu->nb_niveaux);

        if (selectionne && disponible)
        {
            /* Sélection courante : or + flèche */
            couleurCourante(255, 210, 50);
            afficheChaine(">", 28, cx - 375, y_ligne);
            afficheChaine(noms_niveaux[i], 26, cx - 340, y_ligne);
        }
        else if (disponible)
        {
            /* Disponible non sélectionné : blanc */
            couleurCourante(200, 200, 200);
            afficheChaine(noms_niveaux[i], 24, cx - 340, y_ligne);
        }
        else
        {
            /* Verrouillé : gris + "(A venir)" */
            couleurCourante(90, 90, 110);
            afficheChaine(noms_niveaux[i], 22, cx - 340, y_ligne);
            afficheChaine("(A venir)", 16, cx + 180, y_ligne);
        }
    }

    /* Instructions de navigation */
    couleurCourante(140, 140, 160);
    afficheChaine("HAUT / BAS  pour naviguer", 16, cx - 180, 140);
    afficheChaine("ENTREE      pour lancer",   16, cx - 180, 115);
    afficheChaine("ECHAP       pour revenir",  16, cx - 180,  90);
}

// ------------------------------------------------------------
//  dessinerAide — Guide des touches du jeu
// ------------------------------------------------------------
void dessinerAide(void)
{
    int cx = LARGEUR_FENETRE / 2;
    int cy = HAUTEUR_FENETRE / 2;

    /* Fond */
    effaceFenetre(10, 12, 35);

    /* Titre */
    epaisseurDeTrait(5.0f);
    couleurCourante(200, 160, 50);
    afficheChaine("GUIDE DES TOUCHES", 36, cx - 250, cy + 250);

    /* Ligne de séparation */
    couleurCourante(200, 160, 50);
    rectangle(cx - 340, cy + 237, cx + 340, cy + 239);

    /* En-tête : Contrôles en jeu */
    epaisseurDeTrait(4.0f);
    couleurCourante(140, 200, 255);
    afficheChaine("-- Controles en jeu --", 22, cx - 170, cy + 190);

    couleurCourante(255, 255, 255);
    afficheChaine("Fleche Gauche     Aller a gauche",        20, cx - 300, cy + 140);
    afficheChaine("Fleche Droite     Aller a droite",        20, cx - 300, cy + 105);
    afficheChaine("Fleche Haut       Sauter",                20, cx - 300, cy +  70);
    afficheChaine("Espace            Sauter (alternatif)",   20, cx - 300, cy +  35);

    /* En-tête : Navigation menus */
    couleurCourante(140, 200, 255);
    afficheChaine("-- Navigation menus --", 22, cx - 170, cy - 20);

    couleurCourante(255, 255, 255);
    afficheChaine("Entree            Valider / Lancer",      20, cx - 300, cy -  70);
    afficheChaine("Haut / Bas        Naviguer",              20, cx - 300, cy - 105);
    afficheChaine("Echap             Retour / Quitter",      20, cx - 300, cy - 140);
    afficheChaine("Q                 Quitter le jeu",        20, cx - 300, cy - 175);
    afficheChaine("H                 Ouvrir cette aide",     20, cx - 300, cy - 210);

    /* Conseil */
    couleurCourante(200, 160, 50);
    afficheChaine("Astuce : Saute sur les ennemis pour les eliminer !", 18, cx - 280, cy - 290);

    /* Retour */
    epaisseurDeTrait(3.0f);
    couleurCourante(140, 140, 160);
    afficheChaine("ECHAP / ENTREE  pour revenir au menu", 16, cx - 220, 60);

    epaisseurDeTrait(1.0f);
}

void dessinerGameOver(void)
{
    int cx = LARGEUR_FENETRE / 2;
    int cy = HAUTEUR_FENETRE / 2;
    effaceFenetre(10, 0, 0);
    epaisseurDeTrait(6.0f);
    couleurCourante(220, 50, 50);
    afficheChaine("GAME OVER", 50, cx - 160, cy + 40);
    epaisseurDeTrait(3.0f);
    couleurCourante(255, 255, 255);
    afficheChaine("Appuie sur ENTREE pour recommencer", 20, cx - 240, cy - 60);
    epaisseurDeTrait(1.0f);
}

void dessinerVictoire(JeuEtat *jeu)
{
    int cx = LARGEUR_FENETRE / 2;
    int cy = HAUTEUR_FENETRE / 2;
    char texte[64];
    int  ms    = (int)(jeu->timer_complet * 1000);
    int  sec   = ms / 1000;
    int  centi = (ms % 1000) / 10;

    effaceFenetre(0, 20, 10);

    epaisseurDeTrait(6.0f);
    couleurCourante(80, 220, 80);
    afficheChaine("VICTOIRE !", 50, cx - 160, cy + 60);

    epaisseurDeTrait(3.0f);
    couleurCourante(255, 215, 0);
    sprintf(texte, "Temps : %d.%02d s", sec, centi);
    afficheChaine(texte, 28, cx - 110, cy + 10);

    couleurCourante(200, 200, 200);
    sprintf(texte, "Pieces : %d", jeu->joueur.pieces);
    afficheChaine(texte, 22, cx - 80, cy - 40);

    epaisseurDeTrait(2.0f);
    couleurCourante(255, 255, 255);
    afficheChaine("Appuie sur ENTREE pour rejouer", 20, cx - 220, cy - 100);
    epaisseurDeTrait(1.0f);
}