#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <GL/gl.h>
#include "gfxlib/GfxLib.h"
#include "gfxlib/BmpLib.h"
#include "rendu.h"
#include "jeu.h"
#include "menu.h"

static Sprite *spr_idle_left[2];
static Sprite *spr_idle_right[2];
static Sprite *spr_walk_left[6];
static Sprite *spr_walk_right[6];
static Sprite *spr_jump_left[2];
static Sprite *spr_jump_right[2];

// Tableaux pour les plateformes 3 parties (horizontales)
static Sprite *spr_platforms_left[256] = {NULL};
static Sprite *spr_platforms_mid[256]  = {NULL};
static Sprite *spr_platforms_right[256]= {NULL};

// Tableaux pour les colonnes 3 parties (verticales)
static Sprite *spr_columns_top[256]    = {NULL};
static Sprite *spr_columns_mid[256]    = {NULL};
static Sprite *spr_columns_bottom[256] = {NULL};

// Tuiles de donjon (aléatoires)
static Sprite *spr_dungeon_tiles[4]    = {NULL};

static Sprite *spr_blocs[256] = {NULL}; // Lookup table pour tous les autres blocs (et pièces)

#define MAX_BACKGROUND_LAYERS 5
static Texture2D *tex_fond_niv1[MAX_BACKGROUND_LAYERS] = {NULL};
static Texture2D *tex_fond_niv2[MAX_BACKGROUND_LAYERS] = {NULL};
static Texture2D *tex_fond_niv4[MAX_BACKGROUND_LAYERS] = {NULL};

#define GOBELIN_NB_FRAMES  2
#define GOBELIN_ANIM_SPEED 15
static Sprite *spr_gobelin_left[GOBELIN_NB_FRAMES];
static Sprite *spr_gobelin_right[GOBELIN_NB_FRAMES];

#define SLIME_WALK_FRAMES   8
#define SLIME_ATTACK_FRAMES 4
static Sprite *spr_slime_walk[SLIME_WALK_FRAMES]     = {NULL};
static Sprite *spr_slime_attack[SLIME_ATTACK_FRAMES] = {NULL};

#define REDSLIME_WALK_FRAMES   8
#define REDSLIME_ATTACK_FRAMES 4
static Sprite *spr_redslime_walk[REDSLIME_WALK_FRAMES]     = {NULL};
static Sprite *spr_redslime_attack[REDSLIME_ATTACK_FRAMES] = {NULL};

static int anim_tick = 0;

#define TRANSPARENT_R  255
#define TRANSPARENT_G    0
#define TRANSPARENT_B  255

// charge un sprite, et le convertit en ARVB avec transparence
static Sprite *chargerSprite(const char *chemin) {
    DonneesImageRGB *bmp = lisBMPRGB((char *)chemin);
    if (!bmp) {
        printf("ATTENTION : sprite introuvable : %s\n", chemin);
        return NULL;
    }

    Sprite *spr = (Sprite *)malloc(sizeof(Sprite));
    spr->largeur = bmp->largeurImage;
    spr->hauteur = bmp->hauteurImage;

    int nb_pixels = spr->largeur * spr->hauteur;
    spr->donneesARVB = (int *)malloc(nb_pixels * sizeof(int));

    const unsigned char *src = bmp->donneesRGB;
    unsigned char *dst = (unsigned char *)spr->donneesARVB;

    for (int i = 0; i < nb_pixels; i++) {
        unsigned char b = src[0];
        unsigned char v = src[1];
        unsigned char r = src[2];

        dst[0] = b;
        dst[1] = v;
        dst[2] = r;

        if (r == TRANSPARENT_R && v == TRANSPARENT_G && b == TRANSPARENT_B)
            dst[3] = 0x00;
        else
            dst[3] = 0xFF;

        src += 3;
        dst += 4;
    }

    libereDonneesImageRGB(&bmp);
    return spr;
}

// Redimensionne un sprite avec l'algorithme du plus proche voisin
static Sprite* redimensionnerSprite(Sprite *spr, int nv_largeur, int nv_hauteur) {
    if (!spr) return NULL;
    Sprite *res = (Sprite *)malloc(sizeof(Sprite));
    res->largeur = nv_largeur;
    res->hauteur = nv_hauteur;
    res->donneesARVB = (int *)malloc(nv_largeur * nv_hauteur * sizeof(int));

    float scale_x = (float)spr->largeur / nv_largeur;
    float scale_y = (float)spr->hauteur / nv_hauteur;

    for (int y = 0; y < nv_hauteur; y++) {
        int src_y = (int)(y * scale_y);
        for (int x = 0; x < nv_largeur; x++) {
            int src_x = (int)(x * scale_x);
            int pixel = spr->donneesARVB[src_y * spr->largeur + src_x];

            // Inversion Rouge/Bleu pour s'adapter à GL_RGBA (creeTexture2D)
            // alors que chargerSprite produit du format GL_BGRA
            unsigned char *bytes = (unsigned char *)&pixel;
            unsigned char temp = bytes[0];
            bytes[0] = bytes[2];
            bytes[2] = temp;

            res->donneesARVB[y * nv_largeur + x] = pixel;
        }
    }

    // Libérer l'ancien sprite
    free(spr->donneesARVB);
    free(spr);

    return res;
}

//  libère la mémoire à la fin du jeu
static void libererSprite(Sprite **spr) {
    if (*spr) {
        free((*spr)->donneesARVB);
        free(*spr);
        *spr = NULL;
    }
}
// optimisation tableau
void libererSprites(void) {
    int i;
    for (i = 0; i < 256; i++) {
        if (spr_platforms_left[i])  libererSprite(&spr_platforms_left[i]);
        if (spr_platforms_mid[i])   libererSprite(&spr_platforms_mid[i]);
        if (spr_platforms_right[i]) libererSprite(&spr_platforms_right[i]);
        
        if (spr_columns_top[i])     libererSprite(&spr_columns_top[i]);
        if (spr_columns_mid[i])     libererSprite(&spr_columns_mid[i]);
        if (spr_columns_bottom[i])  libererSprite(&spr_columns_bottom[i]);
    }

    for (i = 0; i < 4; i++) {
        if (spr_dungeon_tiles[i]) libererSprite(&spr_dungeon_tiles[i]);
    }

    for (i = 0; i < 256; i++) {
        if (spr_blocs[i]) libererSprite(&spr_blocs[i]);
    }

    for (i = 0; i < MAX_BACKGROUND_LAYERS; i++) {
        if (tex_fond_niv1[i]) libereTexture(&tex_fond_niv1[i]);
        if (tex_fond_niv2[i]) libereTexture(&tex_fond_niv2[i]);
        if (tex_fond_niv4[i]) libereTexture(&tex_fond_niv4[i]);
    }

    for (i = 0; i < 2; i++) {
        libererSprite(&spr_idle_left[i]);
        libererSprite(&spr_idle_right[i]);
        libererSprite(&spr_jump_left[i]);
        libererSprite(&spr_jump_right[i]);
    }
    for (i = 0; i < 6; i++) {
        libererSprite(&spr_walk_left[i]);
        libererSprite(&spr_walk_right[i]);
    }

    for (i = 0; i < GOBELIN_NB_FRAMES; i++) {
        libererSprite(&spr_gobelin_left[i]);
        libererSprite(&spr_gobelin_right[i]);
    }
    for (i = 0; i < SLIME_WALK_FRAMES; i++)
        libererSprite(&spr_slime_walk[i]);
    for (i = 0; i < SLIME_ATTACK_FRAMES; i++)
        libererSprite(&spr_slime_attack[i]);
    for (i = 0; i < REDSLIME_WALK_FRAMES; i++)
        libererSprite(&spr_redslime_walk[i]);
    for (i = 0; i < REDSLIME_ATTACK_FRAMES; i++)
        libererSprite(&spr_redslime_attack[i]);
}

// appelée une fois au démarrage et charge tous les sprites en mémoire
void chargerSprites(void) {
    int i;
    char chemin[128];
    // --- NOUVELLES PLATEFORMES (3 parties) ---
    // ROCHE ('#')
    spr_platforms_left['#']  = chargerSprite("images/world/left-rock-platform.bmp");
    spr_platforms_mid['#']   = chargerSprite("images/world/middle-rock-platform.bmp");
    spr_platforms_right['#'] = chargerSprite("images/world/right-rock-plateform.bmp"); // Faute de frappe volontaire du fichier original

    // HERBE ('=')
    spr_platforms_left['=']  = chargerSprite("images/world/grass_left.bmp");
    spr_platforms_mid['=']   = chargerSprite("images/world/grass_middle.bmp");
    spr_platforms_right['='] = chargerSprite("images/world/grass_right.bmp");

    // TERRE ('_')
    spr_platforms_left['_']  = chargerSprite("images/world/left_dirt.bmp");
    spr_platforms_mid['_']   = chargerSprite("images/world/middle_dirt.bmp");
    spr_platforms_right['_'] = chargerSprite("images/world/right_dirt.bmp");

    // BOIS ('-')
    spr_platforms_left['-']  = chargerSprite("images/world/dungeon/left_wood_platform.bmp");
    spr_platforms_mid['-']   = chargerSprite("images/world/dungeon/middle_wood_platform.bmp");
    spr_platforms_right['-'] = chargerSprite("images/world/dungeon/right_wood_platform.bmp");

    // --- COLONNES VERTICALES ---
    // COLONNE STANDARD ('|')
    spr_columns_top['|']    = chargerSprite("images/world/dungeon/column_ceiling.bmp");
    spr_columns_mid['|']    = chargerSprite("images/world/dungeon/column_middle.bmp");
    spr_columns_bottom['|'] = chargerSprite("images/world/dungeon/column_floor.bmp");

    // --- TUILES DUNGEON ALEATOIRES ('D') ---
    spr_dungeon_tiles[0] = chargerSprite("images/world/dungeon/dungeon_tile1.bmp");
    spr_dungeon_tiles[1] = chargerSprite("images/world/dungeon/dungeon_tile2.bmp");
    spr_dungeon_tiles[2] = chargerSprite("images/world/dungeon/dungeon_tile3.bmp");
    spr_dungeon_tiles[3] = chargerSprite("images/world/dungeon/dungeon_tile4.bmp");

    // --- AUTRES BLOCS UNIQUES ---
    spr_blocs['I'] = chargerSprite("images/world/ice.bmp");
    spr_blocs['X'] = chargerSprite("images/world/lava.bmp");
    spr_blocs['R'] = chargerSprite("images/world/rock.bmp");
    spr_blocs['r'] = chargerSprite("images/world/small_rock.bmp");
    spr_blocs['C'] = chargerSprite("images/world/dungeon/chain.bmp");
    spr_blocs['c'] = chargerSprite("images/world/dungeon/column_ceiling.bmp");
    spr_blocs['m'] = chargerSprite("images/world/dungeon/column_middle.bmp");
    spr_blocs['f'] = chargerSprite("images/world/dungeon/column_floor.bmp");
    spr_blocs['B'] = chargerSprite("images/world/dungeon/crate.bmp");
    spr_blocs['Y'] = chargerSprite("images/world/dungeon/spike_ceiling.bmp");
    spr_blocs['y'] = chargerSprite("images/world/dungeon/spike_floor.bmp");
    spr_blocs['>'] = chargerSprite("images/world/dungeon/spike_left_wall.bmp");
    spr_blocs['<'] = chargerSprite("images/world/dungeon/spike_right_wall.bmp");
    
    // Objets
    spr_blocs['P'] = chargerSprite("images/objects/coin.bmp");

    for (i = 0; i < 5; i++) {
        if (i < 4) {
            sprintf(chemin, "images/world/background/sunset-sky/layer%d.bmp", i + 1);
            Sprite *s1 = chargerSprite(chemin);
            if (s1) {
                Sprite *rs1 = redimensionnerSprite(s1, LARGEUR_FENETRE, HAUTEUR_FENETRE);
                tex_fond_niv1[i] = creeTexture2D(rs1->largeur, rs1->hauteur, rs1->donneesARVB);
                libererSprite(&rs1);
            } else {
                tex_fond_niv1[i] = NULL;
            }

            sprintf(chemin, "images/world/background/night-sky/layer%d.bmp", i + 1);
            Sprite *s2 = chargerSprite(chemin);
            if (s2) {
                Sprite *rs2 = redimensionnerSprite(s2, LARGEUR_FENETRE, HAUTEUR_FENETRE);
                tex_fond_niv2[i] = creeTexture2D(rs2->largeur, rs2->hauteur, rs2->donneesARVB);
                libererSprite(&rs2);
            } else {
                tex_fond_niv2[i] = NULL;
            }
        }
        
        sprintf(chemin, "images/world/background/cave/layer%d.bmp", i + 1);
        Sprite *s4 = chargerSprite(chemin);
        if (s4) {
            // Zoom x1.5 pour éviter les répétitions trop visibles
            int zoom_w = (int)(LARGEUR_FENETRE * 1.5f);
            int zoom_h = (int)(HAUTEUR_FENETRE * 1.5f);
            Sprite *rs4 = redimensionnerSprite(s4, zoom_w, zoom_h);
            tex_fond_niv4[i] = creeTexture2D(rs4->largeur, rs4->hauteur, rs4->donneesARVB);
            libererSprite(&rs4);
        } else {
            tex_fond_niv4[i] = NULL;
        }
    }

    for (i = 0; i < 2; i++) {
        sprintf(chemin, "images/sprites_hero/idle_left_%02d.bmp", i);
        spr_idle_left[i] = chargerSprite(chemin);

        sprintf(chemin, "images/sprites_hero/idle_right_%02d.bmp", i);
        spr_idle_right[i] = chargerSprite(chemin);

        sprintf(chemin, "images/sprites_hero/jump_left_%02d.bmp", i);
        spr_jump_left[i] = chargerSprite(chemin);

        sprintf(chemin, "images/sprites_hero/jump_right_%02d.bmp", i);
        spr_jump_right[i] = chargerSprite(chemin);
    }

    for (i = 0; i < 6; i++) {
        sprintf(chemin, "images/sprites_hero/walk_left_%02d.bmp", i);
        spr_walk_left[i] = chargerSprite(chemin);

        sprintf(chemin, "images/sprites_hero/walk_right_%02d.bmp", i);
        spr_walk_right[i] = chargerSprite(chemin);
    }

    for (i = 0; i < GOBELIN_NB_FRAMES; i++) {
        sprintf(chemin, "images/knight-gobelin/enemy_green_knight_%02d_left.bmp", i + 1);
        spr_gobelin_left[i] = chargerSprite(chemin);

        sprintf(chemin, "images/knight-gobelin/enemy_green_knight_%02d_right.bmp", i + 1);
        spr_gobelin_right[i] = chargerSprite(chemin);
    }

    for (i = 0; i < SLIME_WALK_FRAMES; i++) {
        sprintf(chemin, "images/green-slime/slime_walk_%02d.bmp", i);
        spr_slime_walk[i] = chargerSprite(chemin);
    }
    for (i = 0; i < SLIME_ATTACK_FRAMES; i++) {
        sprintf(chemin, "images/green-slime/slime_attack_%02d.bmp", i);
        spr_slime_attack[i] = chargerSprite(chemin);
    }

    // Chargement Red Slime
    for (i = 0; i < REDSLIME_WALK_FRAMES; i++) {
        sprintf(chemin, "images/red-slime/walk%d.bmp", i + 1); // 1-indexed
        spr_redslime_walk[i] = chargerSprite(chemin);
    }
    for (i = 0; i < REDSLIME_ATTACK_FRAMES; i++) {
        sprintf(chemin, "images/red-slime/attack%d.bmp", i + 1); // 1-indexed
        spr_redslime_attack[i] = chargerSprite(chemin);
    }
}

void dessinerTout(JeuEtat *jeu) {
    anim_tick++;

    if (jeu->etat == ETAT_MENU)            { dessinerMenu(); }
    else if (jeu->etat == ETAT_AIDE)       { dessinerAide(); }
    else if (jeu->etat == ETAT_SELECTION)  { dessinerSelectionNiveau(jeu); }
    else if (jeu->etat == ETAT_GAME_OVER)  { dessinerGameOver(); }
    else if (jeu->etat == ETAT_VICTOIRE)   { dessinerVictoire(jeu); }
    else {

    dessinerFond(jeu);
    dessinerMilieuPlan(jeu);
    dessinerPlateformes(jeu);
    dessinerObjets(jeu);
    dessinerEnnemis(jeu);
    dessinerJoueur(jeu);
    dessinerHUD(jeu);
    }

    if (jeu->opacite_fondu > 0.0f) {
        dessinerFondu(jeu);
    }
}

//  Arrière-plan du niveau avec parallaxe multicouches
void dessinerFond(JeuEtat *jeu) {
    Texture2D **fonds = NULL;

    switch (jeu->niveau_actuel) {
        case 1: fonds = tex_fond_niv1; break;
        case 2: fonds = tex_fond_niv2; break;
        case 3: fonds = tex_fond_niv1; break; // Le niveau 3 utilise le fond "sunset"
        case 4: fonds = tex_fond_niv4; break; // Le niveau 4 utilise le fond "cave"
        default: fonds = tex_fond_niv1; break;
    }

    int fond_trouve = 0;

    for (int i = 0; i < MAX_BACKGROUND_LAYERS; i++) {
        if (fonds[i] != NULL) {
            fond_trouve = 1;
            int fond_largeur = fonds[i]->largeur > 0 ? fonds[i]->largeur : LARGEUR_FENETRE;

            // Calcul du parallaxe: layer 1 est fixe (i=0), les autres bougent un peu.
            float parallax = (float)i * 0.2f;
            float parallax_y = (float)i * 0.1f; // Vertical parallax is usually slower

            int fond_hauteur = fonds[i]->hauteur > 0 ? fonds[i]->hauteur : HAUTEUR_FENETRE;

            // Calcul du décalage (offset) de l'image pour que ça boucle parfaitement
            int offset_x = (int)(jeu->camera_x * parallax) % fond_largeur;
            int offset_y = (int)(jeu->camera_y * parallax_y) % fond_hauteur;

            rectangleSelonTexture(-offset_x, -offset_y, fonds[i]);
            rectangleSelonTexture(-offset_x + fond_largeur, -offset_y, fonds[i]);
            rectangleSelonTexture(-offset_x, -offset_y + fond_hauteur, fonds[i]);
            rectangleSelonTexture(-offset_x + fond_largeur, -offset_y + fond_hauteur, fonds[i]);
        }
    }

    if (!fond_trouve) {
        switch (jeu->niveau_actuel) {
            case 1: effaceFenetre(30, 50, 80);  break;
            case 2: effaceFenetre(15, 10, 25);  break;
            case 3: effaceFenetre(40, 30, 70);  break;
            case 4: effaceFenetre(50, 10, 10);  break;
            default: effaceFenetre(20, 20, 50); break;
        }
    }
}

void dessinerMilieuPlan(JeuEtat *jeu) {
    // Désactivé pour nettoyer l'écran et améliorer les performances
}

//Rendu selon bloc :
static void dessinerSpriteMosaique(Sprite *spr, int x_ecran, int y_world, int largeur, int hauteur) {
    if (!spr) return;
    int tw = spr->largeur;
    int th = spr->hauteur;
    int tile_x, tile_y;
    for (tile_y = y_world; tile_y < y_world + hauteur; tile_y += th) {
        for (tile_x = 0; tile_x < largeur; tile_x += tw) {
            int draw_x = x_ecran + tile_x;
            if (draw_x + tw < 0 || draw_x > LARGEUR_FENETRE) continue;
            ecrisImageARVB(draw_x, tile_y, tw, th, spr->donneesARVB);
        }
    }
}

static void dessinerPlateforme3Parties(float x_ecran, float y_world, float largeur, unsigned char type) {
    Sprite *sl = spr_platforms_left[type];
    Sprite *sm = spr_platforms_mid[type];
    Sprite *sr = spr_platforms_right[type];

    if (sl && sm && sr) {
        int tw = sm->largeur;
        int nb_tiles = (int)(largeur / tw);
        int t;

        for (t = 0; t < nb_tiles; t++) {
            int draw_x = (int)x_ecran + t * tw;
            int draw_y = (int)y_world;
            Sprite *spr;

            if (draw_x + tw < 0 || draw_x > LARGEUR_FENETRE) continue;

            if (t == 0)                   spr = sl;
            else if (t == nb_tiles - 1)   spr = sr;
            else                          spr = sm;

            ecrisImageARVB(draw_x, draw_y, spr->largeur, spr->hauteur, spr->donneesARVB);
        }
    }
    else {
        couleurCourante(100, 100, 110);
        rectangle(x_ecran, y_world, x_ecran + largeur, y_world + 64);
    }
}

static void dessinerColonne3Parties(float x_ecran, float y_world, float hauteur, unsigned char type) {
    Sprite *st = spr_columns_top[type];
    Sprite *sm = spr_columns_mid[type];
    Sprite *sb = spr_columns_bottom[type];

    if (st && sm && sb) {
        int th = sm->hauteur;
        int nb_tiles = (int)(hauteur / th);
        int t;

        for (t = 0; t < nb_tiles; t++) {
            int draw_x = (int)x_ecran;
            int draw_y = (int)y_world + t * th;
            Sprite *spr;

            if (draw_y + th < 0 || draw_y > HAUTEUR_FENETRE) continue;

            if (t == 0)                   spr = sb; // Y part du bas
            else if (t == nb_tiles - 1)   spr = st;
            else                          spr = sm;

            ecrisImageARVB(draw_x, draw_y, spr->largeur, spr->hauteur, spr->donneesARVB);
        }
    }
    else {
        couleurCourante(100, 100, 110);
        rectangle(x_ecran, y_world, x_ecran + 64, y_world + hauteur);
    }
}

static void dessinerDungeonMosaique(float x_ecran, float y_ecran, float largeur, float hauteur, float p_x, float p_y) {
    if (!spr_dungeon_tiles[0]) return;
    int tw = spr_dungeon_tiles[0]->largeur;
    int th = spr_dungeon_tiles[0]->hauteur;
    int tile_x, tile_y_offset;
    
    for (tile_y_offset = 0; tile_y_offset < hauteur; tile_y_offset += th) {
        for (tile_x = 0; tile_x < largeur; tile_x += tw) {
            int draw_x = (int)x_ecran + tile_x;
            int draw_y = (int)y_ecran + tile_y_offset;
            
            if (draw_x + tw < 0 || draw_x > LARGEUR_FENETRE) continue;
            if (draw_y + th < 0 || draw_y > HAUTEUR_FENETRE) continue;
            
            // Calcul pseudo-aléatoire basé sur les coordonnées fixes du monde
            int world_x = (int)p_x + tile_x;
            int world_y = (int)p_y + tile_y_offset;
            int variant = (world_x * 73 + world_y * 37) % 4;
            if (variant < 0) variant = -variant;
            
            Sprite *spr = spr_dungeon_tiles[variant];
            if (spr) ecrisImageARVB(draw_x, draw_y, tw, th, spr->donneesARVB);
        }
    }
}

void dessinerPlateformes(JeuEtat *jeu) {
    int i;
    for (i = 0; i < jeu->nb_plateformes; i++) {
        Plateforme *p = &jeu->plateformes[i];
        float x_ecran = p->x - jeu->camera_x;
        float y_ecran = p->y - jeu->camera_y;

        if (x_ecran + p->largeur < 0 || x_ecran > LARGEUR_FENETRE) continue; //culling
        if (y_ecran + p->hauteur < 0 || y_ecran > HAUTEUR_FENETRE) continue; // vertical culling

        if (p->type == 'X') {
            Sprite *spr_lava = spr_blocs['X'];
            if (spr_lava) dessinerSpriteMosaique(spr_lava, (int)x_ecran, (int)y_ecran, (int)p->largeur, (int)p->hauteur);
            else { couleurCourante(180, 30, 30); rectangle(x_ecran, y_ecran, x_ecran + p->largeur, y_ecran + p->hauteur); }
        }
        else if (p->type == '#' || p->type == '=' || p->type == '_' || p->type == '-') {
            dessinerPlateforme3Parties(x_ecran, y_ecran, p->largeur, (unsigned char)p->type);
        }
        else if (p->type == '|') {
            dessinerColonne3Parties(x_ecran, y_ecran, p->hauteur, (unsigned char)p->type);
        }
        else if (p->type == 'D') {
            dessinerDungeonMosaique(x_ecran, y_ecran, p->largeur, p->hauteur, p->x, p->y);
        }
        else {
            Sprite *spr = spr_blocs[(unsigned char)p->type];
            if (spr) dessinerSpriteMosaique(spr, (int)x_ecran, (int)y_ecran, (int)p->largeur, (int)p->hauteur);
            else { couleurCourante(100, 100, 100); rectangle(x_ecran, y_ecran, x_ecran + p->largeur, y_ecran + p->hauteur); }
        }
    }
}

//Etats possibles :
// jump
// walk
// idle
// A FAIRE : death
// A FAIRE : hit
void dessinerJoueur(JeuEtat *jeu) {
    Joueur *j = &jeu->joueur;
    if (!j->vivant) return;

    //invulnérabilité
    if (j->invulnerable > 0 && (j->invulnerable % 6) < 3) return;

    float x_ecran = j->x - jeu->camera_x;
    float y_ecran = j->y - jeu->camera_y;

    Sprite **sprites = NULL;
    int nb_frames = 1;
    int vitesse_anim = 5;

    if (!j->au_sol) {
        sprites      = (j->direction == DIR_DROITE) ? spr_jump_right : spr_jump_left;
        nb_frames    = 2;
        vitesse_anim = 10;
    }
    else if (j->vx != 0) {
        sprites      = (j->direction == DIR_DROITE) ? spr_walk_right : spr_walk_left;
        nb_frames    = 6;
        vitesse_anim = 5;
    }
    else {
        sprites      = (j->direction == DIR_DROITE) ? spr_idle_right : spr_idle_left;
        nb_frames    = 2;
        vitesse_anim = 20;
    }

    // Calcul frame courante
    int frame = (anim_tick / vitesse_anim) % nb_frames;

    // affichage
    if (sprites && sprites[frame]) {
        Sprite *spr = sprites[frame];
        ecrisImageARVB((int)x_ecran, (int)y_ecran,
                   spr->largeur, spr->hauteur,
                   spr->donneesARVB);
    }
    else {
        couleurCourante(50, 100, 220);
        rectangle(x_ecran, y_ecran, x_ecran + j->largeur, y_ecran + j->hauteur);
    }
}

void dessinerEnnemis(JeuEtat *jeu) {
    int i;
    for (i = 0; i < jeu->nb_ennemis; i++) {
        Ennemi *e = &jeu->ennemis[i];
        if (!e->vivant) continue;

        float x_ecran = e->x - jeu->camera_x;
        float y_ecran = e->y - jeu->camera_y;

        if (x_ecran + e->largeur < 0 || x_ecran > LARGEUR_FENETRE) continue;
        if (y_ecran + e->hauteur < 0 || y_ecran > HAUTEUR_FENETRE) continue;

        Sprite **sprites = NULL;
        int nb_frames    = 1;
        int vitesse_anim = 15;

        switch (e->type_ennemi) {
            case TYPE_CHEVALIER_GOBELIN:
                sprites      = (e->direction == DIR_DROITE) ? spr_gobelin_right : spr_gobelin_left;
                nb_frames    = GOBELIN_NB_FRAMES;
                vitesse_anim = GOBELIN_ANIM_SPEED;
                break;

            case TYPE_SLIME:
                if (e->en_charge) {
                    sprites      = spr_slime_attack;
                    nb_frames    = SLIME_ATTACK_FRAMES;
                    vitesse_anim = 10;
                } else {
                    sprites      = spr_slime_walk;
                    nb_frames    = SLIME_WALK_FRAMES;
                    vitesse_anim = 8;
                }
                break;

            case TYPE_RED_SLIME:
                // Red slime is more dangerous -> faster animation
                if (e->en_charge) {
                    sprites      = spr_redslime_attack;
                    nb_frames    = REDSLIME_ATTACK_FRAMES;
                    vitesse_anim = 7;
                } else {
                    sprites      = spr_redslime_walk;
                    nb_frames    = REDSLIME_WALK_FRAMES;
                    vitesse_anim = 6;
                }
                break;

            default:
                break;
        }

        int frame = (anim_tick / vitesse_anim) % nb_frames;

        if (sprites && sprites[frame]) {
            Sprite *spr = sprites[frame];
            ecrisImageARVB((int)x_ecran, (int)y_ecran,
                       spr->largeur, spr->hauteur,
                       spr->donneesARVB);
        }
        else {
            if (e->en_charge) couleurCourante(230, 100,  20);
            else              couleurCourante(160,  30,  30);
            rectangle(x_ecran, y_ecran, x_ecran + e->largeur, y_ecran + e->hauteur);
        }
    }
}

void dessinerObjets(JeuEtat *jeu) {
    int i;

    // sortie verte clignotante
    if (jeu->sortie_x > 0.0f) {
        float sortie_x_ecran = jeu->sortie_x - jeu->camera_x;
        float sortie_y_ecran = jeu->sortie_y - jeu->camera_y;
        float sortie_h       = TILE_SIZE * 2;

        if (sortie_x_ecran + TILE_SIZE >= 0 && sortie_x_ecran <= LARGEUR_FENETRE) {
            int tick = (int)(jeu->timer * 60);
            if ((tick / 30) % 2 == 0) couleurCourante(50, 220, 80);
            else                      couleurCourante(30, 140, 50);
            rectangle(sortie_x_ecran, sortie_y_ecran,
                      sortie_x_ecran + TILE_SIZE, sortie_y_ecran + sortie_h);
            couleurCourante(255, 255, 255);
            afficheChaine("SORTIE", 14, sortie_x_ecran + 2, sortie_y_ecran + sortie_h + 5);
        }
    }

    // coin
    for (i = 0; i < jeu->nb_objets; i++) {
        Objet *o = &jeu->objets[i];
        if (o->collectee) continue;

        float x_ecran = o->x - jeu->camera_x;
        float y_ecran = o->y - jeu->camera_y;
        if (x_ecran + o->largeur < 0 || x_ecran > LARGEUR_FENETRE) continue;
        if (y_ecran + o->hauteur < 0 || y_ecran > HAUTEUR_FENETRE) continue;

        // flottement offset de ±4px toutes les ~60 ticks
        float flottement = 4.0f * (float)(anim_tick % 60 < 30
                                         ? anim_tick % 30
                                         : 30 - anim_tick % 30) / 15.0f - 4.0f;

        if (spr_blocs['P']) {
            ecrisImageARVB((int)x_ecran,
                           (int)(y_ecran + flottement),
                           spr_blocs['P']->largeur, spr_blocs['P']->hauteur,
                           spr_blocs['P']->donneesARVB);
        }
        else {
            // Fallback
            couleurCourante(255, 210, 0);
            rectangle(x_ecran, y_ecran + flottement,
                      x_ecran + o->largeur, y_ecran + flottement + o->hauteur);
        }
    }
}

void dessinerHUD(JeuEtat *jeu) {
    char texte[64];

    couleurCourante(0, 0, 0);
    rectangle(0, HAUTEUR_FENETRE - 40, LARGEUR_FENETRE, HAUTEUR_FENETRE);

    couleurCourante(255, 255, 255);
    sprintf(texte, "NIVEAU %d", jeu->niveau_actuel);
    afficheChaine(texte, 18, 20, HAUTEUR_FENETRE - 30);

    sprintf(texte, "VIES: %d", jeu->joueur.vies);
    afficheChaine(texte, 18, 200, HAUTEUR_FENETRE - 30);

    sprintf(texte, "PIECES: %d", jeu->joueur.pieces);
    afficheChaine(texte, 18, 400, HAUTEUR_FENETRE - 30);

    epaisseurDeTrait(3.0f);
    sprintf(texte, "TEMPS: %d s", (int)jeu->timer);
    afficheChaine(texte, 18, 650, HAUTEUR_FENETRE - 30);
    epaisseurDeTrait(1.5f);
}

void dessinerFondu(JeuEtat *jeu) {
    if (jeu->opacite_fondu <= 0.0f) return;

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glColor4ub(0, 0, 0, (unsigned char)jeu->opacite_fondu);

    glRectf(0.0f, 0.0f, (float)LARGEUR_FENETRE, (float)HAUTEUR_FENETRE);
}
