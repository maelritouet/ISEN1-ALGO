#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <GL/gl.h>
#include "gfxlib/GfxLib.h"
#include "gfxlib/BmpLib.h"
#include "rendu.h"
#include "jeu.h"
#include "menu.h"

//  rendu.c — Module d'affichage
//
//  Principe général :
//  - chargerSprite()  : charge un BMP et le convertit en ARVB
//  - spr_blocs[]      : table de lookup char→sprite pour les blocs
//  - AnimSprite       : struct regroupant frames + métadonnées
//  - chargerAnim()    : charge une animation entière en boucle
//  - libererAnim()    : libère une animation entière en boucle
//  - dessinerAnim()   : choisit la bonne frame et l'affiche

//  Constantes
#define TRANSPARENT_R  255
#define TRANSPARENT_G    0
#define TRANSPARENT_B  255
#define MAX_BG_LAYERS  5

//  Struct AnimSprite — regroupe un tableau de frames + config
//  Au lieu d'avoir spr_walk_left[6], spr_walk_right[6],
//  spr_idle_left[2]... séparément, on met tout dans une struct.
//  Résultat : chargerSprites/libererSprites/dessinerJoueur
//  deviennent des boucles simples.

typedef struct {
    Sprite **frames;    /* Tableau de pointeurs vers les frames */
    int      nb;        /* Nombre de frames */
    int      vitesse;   /* Ticks entre chaque frame */
} AnimSprite;

//  Animations du joueur — regroupées dans un tableau indexé
//  par état. L'index correspond à un état de jeu :
//    0 = idle droite,  1 = idle gauche
//    2 = walk droite,  3 = walk gauche
//    4 = jump droite,  5 = jump gauche
//    6 = dash droite,  7 = dash gauche

#define ANIM_IDLE_D  0
#define ANIM_IDLE_G  1
#define ANIM_WALK_D  2
#define ANIM_WALK_G  3
#define ANIM_JUMP_D  4
#define ANIM_JUMP_G  5
#define ANIM_DASH_D  6
#define ANIM_DASH_G  7
#define NB_ANIMS_JOUEUR 8

static Sprite     *frames_joueur[NB_ANIMS_JOUEUR][8]; 
static AnimSprite  anim_joueur[NB_ANIMS_JOUEUR];

//  Animations des ennemis — un tableau par type/état
//    Gobelin : 0=droite, 1=gauche
//    Slime   : 0=walk,   1=attack
//    Redslime: 0=walk,   1=attack
#define NB_ANIMS_GOBELIN  2
#define NB_ANIMS_SLIME    2
#define NB_ANIMS_REDSLIME 2

static Sprite     *frames_gobelin[NB_ANIMS_GOBELIN][4];
static AnimSprite  anim_gobelin[NB_ANIMS_GOBELIN];

static Sprite     *frames_slime[NB_ANIMS_SLIME][8];
static AnimSprite  anim_slime[NB_ANIMS_SLIME];

static Sprite     *frames_redslime[NB_ANIMS_REDSLIME][8];
static AnimSprite  anim_redslime[NB_ANIMS_REDSLIME];


//  Sprites de blocs/plateformes
static Sprite *spr_platforms_left[256]   = {NULL};
static Sprite *spr_platforms_mid[256]    = {NULL};
static Sprite *spr_platforms_right[256]  = {NULL};
static Sprite *spr_columns_top[256]      = {NULL};
static Sprite *spr_columns_mid[256]      = {NULL};
static Sprite *spr_columns_bottom[256]   = {NULL};
static Sprite *spr_dungeon_tiles[4]      = {NULL};
static Sprite *spr_blocs[256]            = {NULL};


//  Fonds de niveaux
static Texture2D *tex_fond_niv1[MAX_BG_LAYERS] = {NULL};
static Texture2D *tex_fond_niv2[MAX_BG_LAYERS] = {NULL};
static Texture2D *tex_fond_niv4[MAX_BG_LAYERS] = {NULL};

static int anim_tick = 0;


// Charge un BMP et le convertit en ARVB avec transparence en magenta pure 
static Sprite *chargerSprite(const char *chemin)
{
    DonneesImageRGB *bmp = lisBMPRGB((char *)chemin);
    if (!bmp) {
        printf("ATTENTION : sprite introuvable : %s\n", chemin);
        return NULL;
    }
    Sprite *spr      = (Sprite *)malloc(sizeof(Sprite));
    spr->largeur     = bmp->largeurImage;
    spr->hauteur     = bmp->hauteurImage;
    int nb           = spr->largeur * spr->hauteur;
    spr->donneesARVB = (int *)malloc(nb * sizeof(int));

    const unsigned char *src = bmp->donneesRGB;
    unsigned char       *dst = (unsigned char *)spr->donneesARVB;
    int i;
    for (i = 0; i < nb; i++) {
        unsigned char b = src[0], v = src[1], r = src[2];
        dst[0] = b; dst[1] = v; dst[2] = r;
        dst[3] = (r == TRANSPARENT_R && v == TRANSPARENT_G && b == TRANSPARENT_B)
                 ? 0x00 : 0xFF;
        src += 3; dst += 4;
    }
    libereDonneesImageRGB(&bmp);
    return spr;
}

/* Redimensionne un sprite (nearest-neighbor) et libère l'original */
static Sprite *redimensionnerSprite(Sprite *spr, int nw, int nh)
{
    if (!spr) return NULL;
    Sprite *res      = (Sprite *)malloc(sizeof(Sprite));
    res->largeur     = nw;
    res->hauteur     = nh;
    res->donneesARVB = (int *)malloc(nw * nh * sizeof(int));
    float sx = (float)spr->largeur / nw;
    float sy = (float)spr->hauteur / nh;
    int x, y;
    for (y = 0; y < nh; y++) {
        int src_y = (int)(y * sy);
        for (x = 0; x < nw; x++) {
            int px = spr->donneesARVB[(int)(x * sx) + src_y * spr->largeur];
            /* swap R/B pour compatibilité GL_RGBA */
            unsigned char *b = (unsigned char *)&px;
            unsigned char t = b[0]; b[0] = b[2]; b[2] = t;
            res->donneesARVB[y * nw + x] = px;
        }
    }
    free(spr->donneesARVB); free(spr);
    return res;
}

static void libererSprite(Sprite **spr)
{
    if (*spr) { free((*spr)->donneesARVB); free(*spr); *spr = NULL; }
}

// charge n frames d'une animation 
static void chargerAnim(AnimSprite *a, Sprite **tab, int nb, int vitesse,
                        const char *fmt, int debut_index)
{
    int i;
    char chemin[128];
    a->frames  = tab;
    a->nb      = nb;
    a->vitesse = vitesse;
    for (i = 0; i < nb; i++) {
        sprintf(chemin, fmt, debut_index + i);
        tab[i] = chargerSprite(chemin);
    }
}

static void libererAnim(AnimSprite *a)
{
    int i;
    for (i = 0; i < a->nb; i++)
        libererSprite(&a->frames[i]);
}

// Calcule la frame courante et affiche le sprite à (x, y)
static void dessinerAnim(AnimSprite *a, int x, int y)
{
    if (!a || a->nb == 0) return;
    int frame = (anim_tick / a->vitesse) % a->nb;
    Sprite *spr = a->frames[frame];
    if (spr)
        ecrisImageARVB(x, y, spr->largeur, spr->hauteur, spr->donneesARVB);
}

//  libererSprites / chargerSprites
void libererSprites(void)
{
    int i;

    for (i = 0; i < NB_ANIMS_JOUEUR; i++)
        libererAnim(&anim_joueur[i]);

    for (i = 0; i < NB_ANIMS_GOBELIN;  i++) libererAnim(&anim_gobelin[i]);
    for (i = 0; i < NB_ANIMS_SLIME;    i++) libererAnim(&anim_slime[i]);
    for (i = 0; i < NB_ANIMS_REDSLIME; i++) libererAnim(&anim_redslime[i]);

    for (i = 0; i < 256; i++) {
        libererSprite(&spr_platforms_left[i]);
        libererSprite(&spr_platforms_mid[i]);
        libererSprite(&spr_platforms_right[i]);
        libererSprite(&spr_columns_top[i]);
        libererSprite(&spr_columns_mid[i]);
        libererSprite(&spr_columns_bottom[i]);
        libererSprite(&spr_blocs[i]);
    }
    for (i = 0; i < 4; i++)
        libererSprite(&spr_dungeon_tiles[i]);

    for (i = 0; i < MAX_BG_LAYERS; i++) {
        if (tex_fond_niv1[i]) libereTexture(&tex_fond_niv1[i]);
        if (tex_fond_niv2[i]) libereTexture(&tex_fond_niv2[i]);
        if (tex_fond_niv4[i]) libereTexture(&tex_fond_niv4[i]);
    }
}

void chargerSprites(void)
{
    int i;
    char chemin[128];

    // # roche
    spr_platforms_left['#']  = chargerSprite("images/world/left-rock-platform.bmp");
    spr_platforms_mid['#']   = chargerSprite("images/world/middle-rock-platform.bmp");
    spr_platforms_right['#'] = chargerSprite("images/world/right-rock-plateform.bmp");
    // = herbe
    spr_platforms_left['=']  = chargerSprite("images/world/grass_left.bmp");
    spr_platforms_mid['=']   = chargerSprite("images/world/grass_middle.bmp");
    spr_platforms_right['='] = chargerSprite("images/world/grass_right.bmp");
    // _ terre
    spr_platforms_left['_']  = chargerSprite("images/world/left_dirt.bmp");
    spr_platforms_mid['_']   = chargerSprite("images/world/middle_dirt.bmp");
    spr_platforms_right['_'] = chargerSprite("images/world/right_dirt.bmp");
    // - bois
    spr_platforms_left['-']  = chargerSprite("images/world/dungeon/left_wood_platform.bmp");
    spr_platforms_mid['-']   = chargerSprite("images/world/dungeon/middle_wood_platform.bmp");
    spr_platforms_right['-'] = chargerSprite("images/world/dungeon/right_wood_platform.bmp");

    // | :colonnes
    spr_columns_top['|']    = chargerSprite("images/world/dungeon/column_ceiling.bmp");
    spr_columns_mid['|']    = chargerSprite("images/world/dungeon/column_middle.bmp");
    spr_columns_bottom['|'] = chargerSprite("images/world/dungeon/column_floor.bmp");

    // D : tuiles donjon random
    for (i = 0; i < 4; i++) {
        sprintf(chemin, "images/world/dungeon/dungeon_tile%d.bmp", i + 1);
        spr_dungeon_tiles[i] = chargerSprite(chemin);
    }

    // blocs simples
    spr_blocs['I'] = chargerSprite("images/world/ice.bmp");
    spr_blocs['X'] = chargerSprite("images/world/lava.bmp");
    spr_blocs['R'] = chargerSprite("images/world/rock.bmp");
    spr_blocs['r'] = chargerSprite("images/world/small_rock.bmp");
    spr_blocs['C'] = chargerSprite("images/world/dungeon/chain.bmp");
    spr_blocs['c'] = chargerSprite("images/world/dungeon/column_ceiling.bmp");
    spr_blocs['m'] = chargerSprite("images/world/dungeon/column_middle.bmp");
    spr_blocs['f'] = chargerSprite("images/world/dungeon/column_floor.bmp");
    spr_blocs['B'] = chargerSprite("images/world/dungeon/crate.bmp");
    spr_blocs['Y'] = chargerSprite("images/world/dungeon/spike_ceiling.bmp");
    spr_blocs['y'] = chargerSprite("images/world/dungeon/spike_floor.bmp");
    spr_blocs['>'] = chargerSprite("images/world/dungeon/spike_left_wall.bmp");
    spr_blocs['<'] = chargerSprite("images/world/dungeon/spike_right_wall.bmp");
    spr_blocs['P'] = chargerSprite("images/objects/coin.bmp");

    // background
    struct { const char *nom; int couches; Texture2D **dest; } bgs[] = {
        {"mountaign", 4, tex_fond_niv1},
        {"night-sky", 4, tex_fond_niv2},
        {"cave",      5, tex_fond_niv4}
    };
    int b;
    for (b = 0; b < 3; b++) {
        for (i = 0; i < bgs[b].couches && i < MAX_BG_LAYERS; i++) {
            sprintf(chemin, "images/world/background/%s/layer%d.bmp", bgs[b].nom, i + 1);
            Sprite *s = chargerSprite(chemin);
            if (s) {
                s = redimensionnerSprite(s, (int)(LARGEUR_FENETRE * 1.5f), (int)(HAUTEUR_FENETRE * 1.5f));
                bgs[b].dest[i] = creeTexture2D(s->largeur, s->hauteur, s->donneesARVB);
                libererSprite(&s);
            }
        }
    }

    // Animations joueur via chargerAnim()
    // chargerAnim(structure, tableau_frames, nb_frames, vitesse, format, index_depart)
    chargerAnim(&anim_joueur[ANIM_IDLE_D], frames_joueur[ANIM_IDLE_D], 2, 20,
                "images/sprites_hero/idle_right_%02d.bmp", 0);
    chargerAnim(&anim_joueur[ANIM_IDLE_G], frames_joueur[ANIM_IDLE_G], 2, 20,
                "images/sprites_hero/idle_left_%02d.bmp",  0);
    chargerAnim(&anim_joueur[ANIM_WALK_D], frames_joueur[ANIM_WALK_D], 6, 5,
                "images/sprites_hero/walk_right_%02d.bmp", 0);
    chargerAnim(&anim_joueur[ANIM_WALK_G], frames_joueur[ANIM_WALK_G], 6, 5,
                "images/sprites_hero/walk_left_%02d.bmp",  0);
    chargerAnim(&anim_joueur[ANIM_JUMP_D], frames_joueur[ANIM_JUMP_D], 2, 10,
                "images/sprites_hero/jump_right_%02d.bmp", 0);
    chargerAnim(&anim_joueur[ANIM_JUMP_G], frames_joueur[ANIM_JUMP_G], 2, 10,
                "images/sprites_hero/jump_left_%02d.bmp",  0);
    chargerAnim(&anim_joueur[ANIM_DASH_D], frames_joueur[ANIM_DASH_D], 8, 2,
                "images/sprites_hero/dash/dash%d-right.bmp", 1);
    chargerAnim(&anim_joueur[ANIM_DASH_G], frames_joueur[ANIM_DASH_G], 8, 2,
                "images/sprites_hero/dash/dash%d-left.bmp",  1);

    // Animations ennemis
    // Gobelin index 0=droite, 1=gauche
    chargerAnim(&anim_gobelin[0], frames_gobelin[0], 2, 15,
                "images/knight-gobelin/enemy_green_knight_%02d_right.bmp", 1);
    chargerAnim(&anim_gobelin[1], frames_gobelin[1], 2, 15,
                "images/knight-gobelin/enemy_green_knight_%02d_left.bmp",  1);

    // Slime index 0=walk, 1=attack
    chargerAnim(&anim_slime[0], frames_slime[0], 8, 8,
                "images/green-slime/slime_walk_%02d.bmp",   0);
    chargerAnim(&anim_slime[1], frames_slime[1], 4, 10,
                "images/green-slime/slime_attack_%02d.bmp", 0);

    // Red slime index 0=walk, 1=attack
    chargerAnim(&anim_redslime[0], frames_redslime[0], 8, 6,
                "images/red-slime/walk%d.bmp",   1);
    chargerAnim(&anim_redslime[1], frames_redslime[1], 4, 7,
                "images/red-slime/attack%d.bmp", 1);
}


void dessinerTout(JeuEtat *jeu)
{
    anim_tick++;

    if      (jeu->etat == ETAT_MENU)       { dessinerMenu();              return; }
    else if (jeu->etat == ETAT_AIDE)       { dessinerAide();              return; }
    else if (jeu->etat == ETAT_SELECTION)  { dessinerSelectionNiveau(jeu); return; }
    else if (jeu->etat == ETAT_GAME_OVER)  { dessinerGameOver();          return; }
    else if (jeu->etat == ETAT_VICTOIRE)   { dessinerVictoire(jeu);       return; }

    dessinerFond(jeu);
    dessinerPlateformes(jeu);
    dessinerObjets(jeu);
    dessinerEnnemis(jeu);
    dessinerJoueur(jeu);
    dessinerHUD(jeu);

    if (jeu->opacite_fondu > 0.0f)
        dessinerFondu(jeu);
}

void dessinerFond(JeuEtat *jeu)
{
    Texture2D **fonds = NULL;
    switch (jeu->niveau_actuel) {
        case 1: case 3: fonds = tex_fond_niv1; break;
        case 2:         fonds = tex_fond_niv2; break;
        case 4:         fonds = tex_fond_niv4; break;
        default:        fonds = tex_fond_niv1; break;
    }

    int i, fond_trouve = 0;
    for (i = 0; i < MAX_BG_LAYERS; i++) {
        if (!fonds[i]) continue;
        fond_trouve = 1;
        int fw = fonds[i]->largeur  > 0 ? fonds[i]->largeur  : LARGEUR_FENETRE;
        int fh = fonds[i]->hauteur  > 0 ? fonds[i]->hauteur  : HAUTEUR_FENETRE;
        // Layer 0 fixe, chaque layer suivant défile un peu plus vite
        int ox = (int)(jeu->camera_x * i * 0.2f) % fw;
        int oy = (int)(jeu->camera_y * i * 0.1f) % fh;
        rectangleSelonTexture(-ox,      -oy,      fonds[i]);
        rectangleSelonTexture(-ox + fw, -oy,      fonds[i]);
        rectangleSelonTexture(-ox,      -oy + fh, fonds[i]);
        rectangleSelonTexture(-ox + fw, -oy + fh, fonds[i]);
    }

    if (!fond_trouve) {
        int couleurs[][3] = {{30,50,80},{15,10,25},{40,30,70},{50,10,10}};
        int idx = (jeu->niveau_actuel >= 1 && jeu->niveau_actuel <= 4)
                  ? jeu->niveau_actuel - 1 : 0;
        effaceFenetre(couleurs[idx][0], couleurs[idx][1], couleurs[idx][2]);
    }
}

// Fonctions de dessin des blocs (statiques, usage interne)
static void dessinerMosaique(Sprite *spr, int x, int y, int larg, int haut)
{
    if (!spr) return;
    int tw = spr->largeur, th = spr->hauteur, tx, ty;
    for (ty = y; ty < y + haut; ty += th)
        for (tx = 0; tx < larg; tx += tw) {
            int dx = x + tx;
            if (dx + tw < 0 || dx > LARGEUR_FENETRE) continue;
            ecrisImageARVB(dx, ty, tw, th, spr->donneesARVB);
        }
}

static void dessinerPlateforme3P(int x, int y, int larg, unsigned char type)
{
    Sprite *sl = spr_platforms_left[type];
    Sprite *sm = spr_platforms_mid[type];
    Sprite *sr = spr_platforms_right[type];
    if (!sl || !sm || !sr) {
        couleurCourante(100, 100, 110);
        rectangle(x, y, x + larg, y + 64);
        return;
    }
    int tw = sm->largeur, n = larg / tw, t;
    for (t = 0; t < n; t++) {
        int dx = x + t * tw;
        if (dx + tw < 0 || dx > LARGEUR_FENETRE) continue;
        Sprite *s = (t == 0) ? sl : (t == n-1) ? sr : sm;
        ecrisImageARVB(dx, y, s->largeur, s->hauteur, s->donneesARVB);
    }
}

static void dessinerColonne3P(int x, int y, int haut, unsigned char type)
{
    Sprite *st = spr_columns_top[type];
    Sprite *sm = spr_columns_mid[type];
    Sprite *sb = spr_columns_bottom[type];
    if (!st || !sm || !sb) {
        couleurCourante(100, 100, 110);
        rectangle(x, y, x + 64, y + haut);
        return;
    }
    int th = sm->hauteur, n = haut / th, t;
    for (t = 0; t < n; t++) {
        int dy = y + t * th;
        if (dy + th < 0 || dy > HAUTEUR_FENETRE) continue;
        Sprite *s = (t == 0) ? sb : (t == n-1) ? st : sm;
        ecrisImageARVB(x, dy, s->largeur, s->hauteur, s->donneesARVB);
    }
}

static void dessinerDungeon(int x, int y, int larg, int haut, float px, float py)
{
    if (!spr_dungeon_tiles[0]) return;
    int tw = spr_dungeon_tiles[0]->largeur;
    int th = spr_dungeon_tiles[0]->hauteur;
    int tx, ty;
    for (ty = 0; ty < haut; ty += th) {
        for (tx = 0; tx < larg; tx += tw) {
            int dx = x + tx, dy = y + ty;
            if (dx + tw < 0 || dx > LARGEUR_FENETRE) continue;
            if (dy + th < 0 || dy > HAUTEUR_FENETRE) continue;
            int v = ((int)(px+tx) * 73 + (int)(py+ty) * 37) % 4;
            if (v < 0) v = -v;
            Sprite *s = spr_dungeon_tiles[v];
            if (s) ecrisImageARVB(dx, dy, tw, th, s->donneesARVB);
        }
    }
}

void dessinerPlateformes(JeuEtat *jeu)
{
    int i;
    for (i = 0; i < jeu->nb_plateformes; i++) {
        Plateforme *p = &jeu->plateformes[i];
        int x = (int)(p->x - jeu->camera_x);
        int y = (int)(p->y - jeu->camera_y);
        int w = (int)p->largeur, h = (int)p->hauteur;

        if (x + w < 0 || x > LARGEUR_FENETRE) continue;
        if (y + h < 0 || y > HAUTEUR_FENETRE) continue;

        unsigned char t = (unsigned char)p->type;
        if      (t == '#' || t == '=' || t == '_' || t == '-')
            dessinerPlateforme3P(x, y, w, t);
        else if (t == '|')
            dessinerColonne3P(x, y, h, t);
        else if (t == 'D')
            dessinerDungeon(x, y, w, h, p->x, p->y);
        else {
            Sprite *spr = spr_blocs[t];
            if (spr) dessinerMosaique(spr, x, y, w, h);
            else {
                couleurCourante(t == 'X' ? 180 : 100, 30, t == 'X' ? 30 : 100);
                rectangle(x, y, x + w, y + h);
            }
        }
    }
}

void dessinerJoueur(JeuEtat *jeu)
{
    Joueur *j = &jeu->joueur;
    if (!j->vivant) return;
    if (j->invulnerable > 0 && (j->invulnerable % 6) < 3) return;

    int x = (int)(j->x - jeu->camera_x);
    int y = (int)(j->y - jeu->camera_y);
    int d = (j->direction == DIR_DROITE);

    /* Choisir l'animation selon l'état */
    AnimSprite *a;
    if      (j->en_dash)  a = &anim_joueur[d ? ANIM_DASH_D : ANIM_DASH_G];
    else if (!j->au_sol)  a = &anim_joueur[d ? ANIM_JUMP_D : ANIM_JUMP_G];
    else if (j->vx != 0)  a = &anim_joueur[d ? ANIM_WALK_D : ANIM_WALK_G];
    else                  a = &anim_joueur[d ? ANIM_IDLE_D : ANIM_IDLE_G];

    if (a->frames[0])
        dessinerAnim(a, x, y);
    else {
        couleurCourante(50, 100, 220);
        rectangle(x, y, x + j->largeur, y + j->hauteur);
    }
}

void dessinerEnnemis(JeuEtat *jeu)
{
    int i;
    for (i = 0; i < jeu->nb_ennemis; i++) {
        Ennemi *e = &jeu->ennemis[i];
        if (!e->vivant) continue;

        int x = (int)(e->x - jeu->camera_x);
        int y = (int)(e->y - jeu->camera_y);
        if (x + e->largeur < 0 || x > LARGEUR_FENETRE) continue;
        if (y + e->hauteur < 0 || y > HAUTEUR_FENETRE) continue;

        /* Sélectionner l'animation selon le type et l'état */
        AnimSprite *a = NULL;
        int d = (e->direction == DIR_DROITE);

        switch (e->type_ennemi) {
            case TYPE_CHEVALIER_GOBELIN:
                a = &anim_gobelin[d ? 0 : 1];
                break;
            case TYPE_SLIME:
                a = &anim_slime[e->en_charge ? 1 : 0];
                break;
            case TYPE_RED_SLIME:
                a = &anim_redslime[e->en_charge ? 1 : 0];
                break;
            default: break;
        }

        if (a && a->frames[0])
            dessinerAnim(a, x, y);
        else {
            couleurCourante(e->en_charge ? 230 : 160, e->en_charge ? 100 : 30, 30);
            rectangle(x, y, x + e->largeur, y + e->hauteur);
        }
    }
}

void dessinerObjets(JeuEtat *jeu)
{
    int i;

    /* Zone de sortie clignotante */
    if (jeu->sortie_x > 0.0f) {
        int sx = (int)(jeu->sortie_x - jeu->camera_x);
        int sy = (int)(jeu->sortie_y - jeu->camera_y);
        if (sx + TILE_SIZE >= 0 && sx <= LARGEUR_FENETRE) {
            int pair = ((int)(jeu->timer * 60) / 30) % 2;
            couleurCourante(pair ? 50 : 30, pair ? 220 : 140, pair ? 80 : 50);
            rectangle(sx, sy, sx + TILE_SIZE, sy + TILE_SIZE * 2);
            couleurCourante(255, 255, 255);
            afficheChaine("SORTIE", 14, sx + 2, sy + TILE_SIZE * 2 + 5);
        }
    }

    /* Pièces avec flottement */
    Sprite *spr_coin = spr_blocs['P'];
    for (i = 0; i < jeu->nb_objets; i++) {
        Objet *o = &jeu->objets[i];
        if (o->collectee) continue;

        int x = (int)(o->x - jeu->camera_x);
        int y = (int)(o->y - jeu->camera_y);
        if (x + o->largeur < 0 || x > LARGEUR_FENETRE) continue;

        int t    = anim_tick % 60;
        float fl = 4.0f * (float)(t < 30 ? t : 60 - t) / 30.0f - 2.0f;

        if (spr_coin)
            ecrisImageARVB(x, (int)(y + fl),
                           spr_coin->largeur, spr_coin->hauteur,
                           spr_coin->donneesARVB);
        else {
            couleurCourante(255, 210, 0);
            rectangle(x, y + fl, x + o->largeur, y + fl + o->hauteur);
        }
    }
}

void dessinerHUD(JeuEtat *jeu)
{
    char t[64];
    couleurCourante(0, 0, 0);
    rectangle(0, HAUTEUR_FENETRE - 40, LARGEUR_FENETRE, HAUTEUR_FENETRE);
    couleurCourante(255, 255, 255);
    sprintf(t, "NIVEAU %d", jeu->niveau_actuel);  afficheChaine(t, 18, 20,  HAUTEUR_FENETRE - 30);
    sprintf(t, "VIES: %d",  jeu->joueur.vies);    afficheChaine(t, 18, 200, HAUTEUR_FENETRE - 30);
    sprintf(t, "PIECES: %d",jeu->joueur.pieces);  afficheChaine(t, 18, 400, HAUTEUR_FENETRE - 30);
    epaisseurDeTrait(3.0f);
    sprintf(t, "TEMPS: %d s",(int)jeu->timer);    afficheChaine(t, 18, 650, HAUTEUR_FENETRE - 30);
    epaisseurDeTrait(1.5f);
}

void dessinerFondu(JeuEtat *jeu)
{
    if (jeu->opacite_fondu <= 0.0f) return;
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glColor4ub(0, 0, 0, (unsigned char)jeu->opacite_fondu);
    glRectf(0.0f, 0.0f, (float)LARGEUR_FENETRE, (float)HAUTEUR_FENETRE);
}