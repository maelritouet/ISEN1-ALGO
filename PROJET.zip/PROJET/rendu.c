/*
 * rendu.c - Affichage graphique complet
 *
 * Fonctionnalités :
 *   [OBLIGATOIRE] Affichage joueur, ennemis, objets, plateformes
 *   [OBLIGATOIRE] Orientation des sprites selon direction
 *   [OBLIGATOIRE] HUD : niveau, timer, vies, pièces
 *   [OBLIGATOIRE] Écrans menu, game over, victoire
 *   [BONUS]       Clignotement joueur invulnérable
 *   [BONUS]       Couleurs différentes par type d'ennemi
 *   [BONUS]       Indicateur clé/porte
 *   [BONUS]       Affichage score
 *
 * NOTE : Pour l'instant tout est dessiné avec des rectangles colorés.
 * Quand les sprites BMP seront disponibles, remplacer dessineRect*()
 * par ecrisImage() avec les DonneesImageRGB chargées via lisBMPRGB().
 *
 * Membre 5 - Rendu graphique & HUD
 */

#include <stdio.h>
#include "gfxlib/GfxLib.h"
#include "gfxlib/BmpLib.h"
#include "jeu.h"
#include "rendu.h"
#include "ennemi.h"   /* Pour TYPE_GOBELIN, TYPE_SQUELETTE, TYPE_BOSS */
#include "objets.h"   /* Pour nbPiecesRestantes() */

/* =========================================================
 *  Sprites BMP (NULL tant que les fichiers ne sont pas fournis)
 *  Pour charger : image = lisBMPRGB("images/joueur.bmp");
 *  Pour afficher : ecrisImage(x, y, image->largeurImage, image->hauteurImage, image->donneesRGB);
 * ========================================================= */
static DonneesImageRGB *sprite_joueur_droite = NULL;
static DonneesImageRGB *sprite_joueur_gauche = NULL;
static DonneesImageRGB *sprite_gobelin       = NULL;
static DonneesImageRGB *sprite_squelette     = NULL;
static DonneesImageRGB *sprite_boss          = NULL;
static DonneesImageRGB *sprite_piece         = NULL;
static DonneesImageRGB *sprite_powerup       = NULL;
static DonneesImageRGB *sprite_cle           = NULL;
static DonneesImageRGB *sprite_porte         = NULL;

/* =========================================================
 *  Compteur global de frames (pour animations/clignotement)
 * ========================================================= */
static int frame_count = 0;

/* =========================================================
 *  initialiseRendu()
 *
 *  Appelée depuis main.c lors de l'événement Initialisation.
 *  Tente de charger les sprites BMP.
 *  Si un fichier n'existe pas, le sprite reste NULL
 *  et on utilisera le rectangle coloré de remplacement.
 * ========================================================= */
void initialiseRendu(void)
{
    /* Tentative de chargement des sprites */
    sprite_joueur_droite = lisBMPRGB("images/joueur_droite.bmp");
    sprite_joueur_gauche = lisBMPRGB("images/joueur_gauche.bmp");
    sprite_gobelin       = lisBMPRGB("images/gobelin.bmp");
    sprite_squelette     = lisBMPRGB("images/squelette.bmp");
    sprite_boss          = lisBMPRGB("images/boss.bmp");
    sprite_piece         = lisBMPRGB("images/piece.bmp");
    sprite_powerup       = lisBMPRGB("images/powerup.bmp");
    sprite_cle           = lisBMPRGB("images/cle.bmp");
    sprite_porte         = lisBMPRGB("images/porte.bmp");

    /* On informe si les sprites ont été chargés */
    printf("[Rendu] Sprites : joueur=%s gobelin=%s squelette=%s boss=%s\n",
           sprite_joueur_droite ? "OK" : "placeholder",
           sprite_gobelin       ? "OK" : "placeholder",
           sprite_squelette     ? "OK" : "placeholder",
           sprite_boss          ? "OK" : "placeholder");
}

/* =========================================================
 *  libereRendu()
 * ========================================================= */
void libereRendu(void)
{
    libereDonneesImageRGB(&sprite_joueur_droite);
    libereDonneesImageRGB(&sprite_joueur_gauche);
    libereDonneesImageRGB(&sprite_gobelin);
    libereDonneesImageRGB(&sprite_squelette);
    libereDonneesImageRGB(&sprite_boss);
    libereDonneesImageRGB(&sprite_piece);
    libereDonneesImageRGB(&sprite_powerup);
    libereDonneesImageRGB(&sprite_cle);
    libereDonneesImageRGB(&sprite_porte);
}

/* =========================================================
 *  Fonctions utilitaires internes
 * ========================================================= */

/* Convertit une coordonnée du monde en coordonnée écran (applique la caméra) */
static float mondeVersEcranX(float x_monde) { return x_monde - jeu.camera.x; }
static float mondeVersEcranY(float y_monde) { return y_monde; }

/* Dessine un sprite BMP si disponible, sinon un rectangle coloré */
static void dessineSprite(DonneesImageRGB *sprite,
                          float x_ecran, float y_ecran,
                          float largeur, float hauteur,
                          int r, int g, int b)
{
    int xi = (int)x_ecran;
    int yi = (int)y_ecran;

    if (sprite != NULL)
    {
        /* Affiche le vrai sprite BMP */
        ecrisImage(xi, yi, sprite->largeurImage, sprite->hauteurImage, sprite->donneesRGB);
    }
    else
    {
        /* Placeholder rectangle coloré */
        couleurCourante(r, g, b);
        rectangle(x_ecran, y_ecran, x_ecran + largeur, y_ecran + hauteur);
    }
}

/* =========================================================
 *  dessineJoueur()
 * ========================================================= */
static void dessineJoueur(void)
{
    Joueur *j = &jeu.joueur;
    if (!j->vivant) return;

    /* Clignotement quand invulnérable : affiche 1 frame sur 2 */
    if (j->invulnerable > 0 && (frame_count % 6) < 3) return;

    float ex = mondeVersEcranX(j->x);
    float ey = mondeVersEcranY(j->y);

    /* Choisir le sprite selon la direction */
    DonneesImageRGB *sprite = (j->direction > 0) ? sprite_joueur_droite : sprite_joueur_gauche;

    dessineSprite(sprite, ex, ey,
                  TAILLE_JOUEUR_L, TAILLE_JOUEUR_H,
                  70, 130, 255);   /* Bleu roi = couleur placeholder */

    /* Petite tête (cercle simulé par un petit carré) pour rendre lisible */
    if (sprite == NULL)
    {
        couleurCourante(255, 220, 160);  /* Chair */
        rectangle(ex + 6, ey + TAILLE_JOUEUR_H - 16,
                  ex + TAILLE_JOUEUR_L - 6, ey + TAILLE_JOUEUR_H);
    }
}

/* =========================================================
 *  dessineEnnemis()
 * ========================================================= */
static void dessineEnnemis(void)
{
    int i;
    for (i = 0; i < NB_ENNEMIS; i++)
    {
        Ennemi *e = &jeu.ennemis[i];
        if (!e->vivant) continue;

        float ex = mondeVersEcranX(e->x);
        float ey = mondeVersEcranY(e->y);

        /* Ne pas dessiner si hors écran */
        if (ex + TAILLE_ENNEMI_L < 0 || ex > LARGEUR_FENETRE) continue;

        switch (e->type)
        {
            case TYPE_GOBELIN:
                dessineSprite(sprite_gobelin, ex, ey,
                              TAILLE_ENNEMI_L, TAILLE_ENNEMI_H,
                              80, 160, 60);   /* Vert gobelin */
                /* Yeux rouges si en attaque */
                if (e->attaque && sprite_gobelin == NULL)
                {
                    couleurCourante(255, 0, 0);
                    rectangle(ex + 4, ey + TAILLE_ENNEMI_H - 12,
                              ex + 10, ey + TAILLE_ENNEMI_H - 6);
                    rectangle(ex + TAILLE_ENNEMI_L - 10, ey + TAILLE_ENNEMI_H - 12,
                              ex + TAILLE_ENNEMI_L - 4, ey + TAILLE_ENNEMI_H - 6);
                }
                break;

            case TYPE_SQUELETTE:
                dessineSprite(sprite_squelette, ex, ey,
                              TAILLE_ENNEMI_L, TAILLE_ENNEMI_H,
                              220, 220, 210);  /* Blanc os */
                break;

            case TYPE_BOSS:
                /* Le boss est plus grand */
                dessineSprite(sprite_boss, ex, ey - 20,
                              TAILLE_ENNEMI_L * 2, TAILLE_ENNEMI_H + 20,
                              180, 30, 30);   /* Rouge sang */
                break;
        }

        /* Petite barre de santé au-dessus (optionnel, uniquement pour boss) */
        if (e->type == TYPE_BOSS && sprite_boss == NULL)
        {
            couleurCourante(200, 50, 50);
            rectangle(ex - 10, ey + TAILLE_ENNEMI_H + 25,
                      ex + TAILLE_ENNEMI_L + 10, ey + TAILLE_ENNEMI_H + 32);
        }
    }
}

/* =========================================================
 *  dessineObjets()
 * ========================================================= */
static void dessineObjets(void)
{
    int i;
    for (i = 0; i < NB_PIECES; i++)
    {
        Objet *o = &jeu.objets[i];
        if (o->collectee) continue;

        float ex = mondeVersEcranX(o->x);
        float ey = mondeVersEcranY(o->y);

        if (ex < -32 || ex > LARGEUR_FENETRE + 32) continue;

        /* Animation légère : oscillation verticale */
        float anim_y = ey + (float)(frame_count % 60 < 30 ? (frame_count % 30) / 10 : (30 - frame_count % 30) / 10);

        switch (o->type)
        {
            case OBJET_PIECE:
                dessineSprite(sprite_piece,
                              ex - TAILLE_PIECE / 2, anim_y - TAILLE_PIECE / 2,
                              TAILLE_PIECE, TAILLE_PIECE,
                              255, 215, 0);  /* Or */
                break;

            case OBJET_POWERUP:
                dessineSprite(sprite_powerup,
                              ex - 12, anim_y - 12,
                              24, 24,
                              255, 80, 200);  /* Rose magique */
                break;

            case OBJET_CLE:
                dessineSprite(sprite_cle,
                              ex - 12, anim_y - 12,
                              24, 24,
                              255, 200, 0);  /* Jaune doré */
                /* Halo lumineux */
                if (sprite_cle == NULL)
                {
                    couleurCourante(255, 240, 100);
                    rectangle(ex - 14, anim_y - 14, ex + 14, anim_y + 14);
                    couleurCourante(255, 200, 0);
                    rectangle(ex - 10, anim_y - 10, ex + 10, anim_y + 10);
                }
                break;
        }
    }
}

/* =========================================================
 *  dessinePlateformes()
 * ========================================================= */
static void dessinePlateformes(void)
{
    int i;
    for (i = 0; i < NB_PLATEFORMES; i++)
    {
        Plateforme *p = &jeu.plateformes[i];
        if (!p->active) continue;

        float ex = mondeVersEcranX(p->x);
        float ey = mondeVersEcranY(p->y);

        if (ex + p->largeur < 0 || ex > LARGEUR_FENETRE) continue;

        if (p->mortelle)
        {
            /* Lave : rouge-orange animée */
            int pulse = (frame_count % 40 < 20) ? 0 : 20;
            couleurCourante(220 + pulse, 60, 0);
            rectangle(ex, ey, ex + p->largeur, ey + p->hauteur);
            /* Petites flammes simulées */
            couleurCourante(255, 140 + pulse, 0);
            rectangle(ex + 10, ey + p->hauteur,
                      ex + 20, ey + p->hauteur + 8);
            rectangle(ex + 40, ey + p->hauteur,
                      ex + 50, ey + p->hauteur + 6);
        }
        else
        {
            /* Plateforme normale : brun pierre médiéval */
            couleurCourante(100, 75, 50);
            rectangle(ex, ey, ex + p->largeur, ey + p->hauteur);
            /* Liseré du dessus plus clair */
            couleurCourante(150, 120, 85);
            rectangle(ex, ey + p->hauteur - 5,
                      ex + p->largeur, ey + p->hauteur);
        }
    }
}

/* =========================================================
 *  dessinePorteFinNiveau()
 * ========================================================= */
static void dessinePorteFinNiveau(void)
{
    float ex = mondeVersEcranX(3550.0f);
    float ey = 0.0f;

    if (ex < -80 || ex > LARGEUR_FENETRE) return;

    if (sprite_porte != NULL)
    {
        ecrisImage((int)ex, (int)ey,
                   sprite_porte->largeurImage,
                   sprite_porte->hauteurImage,
                   sprite_porte->donneesRGB);
    }
    else
    {
        /* Porte placeholder */
        int a_cle = jeu.joueur.a_cle;
        /* Cadre */
        couleurCourante(80, 50, 20);
        rectangle(ex, ey, ex + 50, ey + 100);
        /* Panneau de porte */
        couleurCourante(a_cle ? 180 : 120, a_cle ? 120 : 80, a_cle ? 50 : 50);
        rectangle(ex + 5, ey + 5, ex + 45, ey + 95);
        /* Serrure */
        couleurCourante(a_cle ? 255 : 80, a_cle ? 215 : 80, a_cle ? 0 : 80);
        rectangle(ex + 18, ey + 45, ex + 32, ey + 58);
    }
}

/* =========================================================
 *  dessineFond()
 *  Fond de ciel dégradé simulé
 * ========================================================= */
static void dessineFond(void)
{
    /* Ciel */
    couleurCourante(30, 20, 60);   /* Nuit médiévale */
    rectangle(0, 0, LARGEUR_FENETRE, HAUTEUR_FENETRE);

    /* Quelques étoiles (fixes, positions arbitraires) */
    couleurCourante(255, 255, 200);
    epaisseurDeTrait(2);
    point(100, 650); point(250, 680); point(400, 660);
    point(550, 700); point(700, 640); point(850, 670);
    point(1000,690); point(1150,655); point(1250,675);
    point(180, 620); point(320, 630); point(600,610);
    epaisseurDeTrait(1);

    /* Lune */
    couleurCourante(240, 240, 200);
    rectangle(1150, 640, 1190, 680);

    /* Sol de fond (herbe/pierre sombre) */
    couleurCourante(40, 55, 30);
    rectangle(0, 0, LARGEUR_FENETRE, 30);
}

/* =========================================================
 *  dessineHUD()
 *  Interface : niveau, timer, vies, pièces, score
 * ========================================================= */
static void dessineHUD(void)
{
    char texte[64];
    Joueur *j = &jeu.joueur;

    /* Barre HUD en haut */
    couleurCourante(0, 0, 0);
    rectangle(0, HAUTEUR_FENETRE - 50, LARGEUR_FENETRE, HAUTEUR_FENETRE);
    couleurCourante(30, 20, 60);
    rectangle(0, HAUTEUR_FENETRE - 48, LARGEUR_FENETRE, HAUTEUR_FENETRE - 2);

    /* Ligne de séparation */
    couleurCourante(180, 150, 80);
    epaisseurDeTrait(2);
    ligne(0, HAUTEUR_FENETRE - 50, LARGEUR_FENETRE, HAUTEUR_FENETRE - 50);
    epaisseurDeTrait(1);

    /* --- Niveau --- */
    sprintf(texte, "NIVEAU %d/%d", jeu.niveau_actuel, NB_NIVEAUX);
    couleurCourante(180, 150, 80);
    afficheChaine(texte, 18, 10, HAUTEUR_FENETRE - 36);

    /* --- Timer --- */
    int secondes = (int)jeu.timer;
    sprintf(texte, "TEMPS: %3ds", secondes);
    /* Rouge si moins de 20 secondes */
    if (secondes <= 20)
        couleurCourante(255, 60, 60);
    else
        couleurCourante(200, 220, 255);
    afficheChaine(texte, 18, 250, HAUTEUR_FENETRE - 36);

    /* --- Vies --- */
    int v;
    couleurCourante(255, 80, 80);
    afficheChaine("VIES:", 18, 480, HAUTEUR_FENETRE - 36);
    for (v = 0; v < j->vies && v < 5; v++)
    {
        /* Coeur dessiné comme un petit carré rouge */
        couleurCourante(220, 30, 30);
        rectangle(570 + v * 26, HAUTEUR_FENETRE - 38,
                  590 + v * 26, HAUTEUR_FENETRE - 18);
    }

    /* --- Pièces --- */
    sprintf(texte, "PIECES: %d", j->pieces);
    couleurCourante(255, 215, 0);
    afficheChaine(texte, 18, 730, HAUTEUR_FENETRE - 36);

    /* --- Score --- */
    sprintf(texte, "SCORE: %d", jeu.score);
    couleurCourante(100, 220, 100);
    afficheChaine(texte, 18, 980, HAUTEUR_FENETRE - 36);

    /* --- Indicateur clé --- */
    if (j->a_cle)
    {
        couleurCourante(255, 215, 0);
        afficheChaine("[CLE]", 16, 1180, HAUTEUR_FENETRE - 36);
    }
}

/* =========================================================
 *  dessineJeu()  — appelée par main.c à chaque Affichage
 * ========================================================= */
void dessineJeu(void)
{
    frame_count++;

    /* 1. Fond */
    dessineFond();

    /* 2. Plateformes (monde) */
    dessinePlateformes();

    /* 3. Porte de fin */
    dessinePorteFinNiveau();

    /* 4. Objets */
    dessineObjets();

    /* 5. Ennemis */
    dessineEnnemis();

    /* 6. Joueur (au premier plan) */
    dessineJoueur();

    /* 7. HUD (par-dessus tout) */
    dessineHUD();
}

/* =========================================================
 *  dessineMenu()
 * ========================================================= */
void dessineMenu(void)
{
    frame_count++;

    /* Fond sombre médiéval */
    effaceFenetre(15, 10, 35);

    /* Étoiles */
    couleurCourante(255, 255, 200);
    epaisseurDeTrait(2);
    point(150, 600); point(400, 650); point(700, 580);
    point(900, 620); point(1100, 600); point(300, 560);
    epaisseurDeTrait(1);

    /* Titre principal */
    couleurCourante(180, 150, 80);
    epaisseurDeTrait(3);
    afficheChaine("DONJON MEDIEVAL", 40, 340, 520);
    epaisseurDeTrait(1);

    /* Sous-titre */
    couleurCourante(140, 120, 180);
    afficheChaine("Un jeu de plateforme medieval fantasy", 18, 370, 460);

    /* Instructions */
    couleurCourante(200, 200, 200);
    afficheChaine("Appuyez sur ENTREE pour commencer", 20, 390, 350);
    afficheChaine("Appuyez sur ECHAP pour quitter", 16, 420, 310);

    /* Contrôles */
    couleurCourante(160, 160, 160);
    afficheChaine("CONTROLES :", 16, 200, 240);
    afficheChaine("Fleche GAUCHE/DROITE  ou  Q/D  :  Se deplacer", 14, 200, 215);
    afficheChaine("Fleche HAUT  ou  Z  ou  ESPACE  :  Sauter (x2 = double saut)", 14, 200, 192);
    afficheChaine("SHIFT  :  Courir", 14, 200, 170);
    afficheChaine("ECHAP  :  Menu / Quitter", 14, 200, 148);

    /* Objectif */
    couleurCourante(255, 215, 0);
    afficheChaine("OBJECTIF : Trouvez la cle et atteignez la porte de sortie !", 15, 230, 100);

    /* Animation : "Appuyez..." qui clignote */
    if ((frame_count / 30) % 2 == 0)
    {
        couleurCourante(255, 215, 0);
        afficheChaine("> ENTREE <", 22, 530, 350);
    }

    /* Crédits */
    couleurCourante(80, 80, 100);
    afficheChaine("ISEN Mediterranee - CIN1/BIOST1 - 2026", 12, 440, 30);
}

/* =========================================================
 *  dessineGameOver()
 * ========================================================= */
void dessineGameOver(void)
{
    char texte[64];

    effaceFenetre(30, 5, 5);

    /* Titre */
    couleurCourante(220, 30, 30);
    epaisseurDeTrait(4);
    afficheChaine("GAME OVER", 50, 430, 450);
    epaisseurDeTrait(1);

    /* Score final */
    sprintf(texte, "Score final : %d", jeu.score);
    couleurCourante(255, 215, 0);
    afficheChaine(texte, 24, 490, 370);

    sprintf(texte, "Pieces collectees : %d", jeu.joueur.pieces);
    couleurCourante(200, 200, 200);
    afficheChaine(texte, 18, 510, 320);

    sprintf(texte, "Niveau atteint : %d / %d", jeu.niveau_actuel, NB_NIVEAUX);
    afficheChaine(texte, 18, 510, 290);

    /* Retour */
    if ((frame_count / 25) % 2 == 0)
    {
        couleurCourante(255, 150, 150);
        afficheChaine("Appuyez sur n'importe quelle touche...", 16, 430, 220);
    }
    frame_count++;
}

/* =========================================================
 *  dessineVictoire()
 * ========================================================= */
void dessineVictoire(void)
{
    char texte[64];

    /* Fond doré */
    effaceFenetre(20, 15, 5);

    /* Titre */
    couleurCourante(255, 215, 0);
    epaisseurDeTrait(4);
    afficheChaine("VICTOIRE !", 52, 420, 470);
    epaisseurDeTrait(1);

    couleurCourante(220, 200, 120);
    afficheChaine("Le donjon est vaincu !", 26, 450, 410);

    /* Score */
    sprintf(texte, "Score final : %d", jeu.score);
    couleurCourante(255, 240, 100);
    afficheChaine(texte, 24, 490, 350);

    sprintf(texte, "Pieces : %d   Vies restantes : %d",
            jeu.joueur.pieces, jeu.joueur.vies);
    couleurCourante(200, 220, 200);
    afficheChaine(texte, 18, 440, 300);

    /* Retour menu */
    if ((frame_count / 25) % 2 == 0)
    {
        couleurCourante(255, 215, 0);
        afficheChaine("Appuyez sur n'importe quelle touche...", 16, 430, 230);
    }

    /* Étoiles animées */
    int s;
    for (s = 0; s < 20; s++)
    {
        int px = (s * 137 + frame_count) % LARGEUR_FENETRE;
        int py = (s * 79  + frame_count / 2) % HAUTEUR_FENETRE;
        couleurCourante(255, 215, 0);
        epaisseurDeTrait(3);
        point((float)px, (float)py);
        epaisseurDeTrait(1);
    }

    frame_count++;
}
