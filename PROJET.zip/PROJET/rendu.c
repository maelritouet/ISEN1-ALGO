#include <stdio.h>
#include <string.h>
#include "gfxlib/GfxLib.h"
#include "gfxlib/BmpLib.h"
#include "rendu.h"
#include "jeu.h"

// ============================================================
//  rendu.c — Module d'affichage (Membre 5)
//
//  Phase 5 : sprites BMP pour le joueur avec animations.
//  Les ennemis, pièces, plateformes restent en rectangles
//  jusqu'à ce qu'on ait leurs sprites.
//
//  Animations joueur :
//  - idle  : 2 frames, change toutes les 20 ticks
//  - walk  : 12 frames, change toutes les 5 ticks
//  - jump  : 2 frames, change toutes les 10 ticks
//
//  À l'oral : "On charge tous les BMP une seule fois au
//  démarrage dans chargerSprites(). À chaque affichage on
//  choisit la bonne frame selon l'état du joueur et on
//  appelle ecrisImage() avec les données RGB du BMP."
// ============================================================

// ------------------------------------------------------------
//  Stockage des sprites chargés en mémoire
//  NULL si le fichier n'a pas pu être chargé
// ------------------------------------------------------------
static DonneesImageRGB *spr_idle_left[2];
static DonneesImageRGB *spr_idle_right[2];
static DonneesImageRGB *spr_walk_left[6];
static DonneesImageRGB *spr_walk_right[6];
static DonneesImageRGB *spr_jump_left[2];
static DonneesImageRGB *spr_jump_right[2];

// Compteur global de ticks pour les animations
static int anim_tick = 0;

// ------------------------------------------------------------
//  chargerSprite — Charge un BMP et affiche un warning si manquant
// ------------------------------------------------------------
static DonneesImageRGB *chargerSprite(const char *chemin)
{
    DonneesImageRGB *spr = lisBMPRGB((char *)chemin);
    if (!spr)
        printf("ATTENTION : sprite introuvable : %s\n", chemin);
    return spr;
}

// ------------------------------------------------------------
//  chargerSprites — Appelée UNE SEULE FOIS au démarrage
//  Charge tous les BMP du joueur en mémoire
// ------------------------------------------------------------
void chargerSprites(void)
{
    int i;
    char chemin[128];

    for (i = 0; i < 2; i++) {
        sprintf(chemin, "images/sprites_hero/idle_left_%02d.bmp", i);
        spr_idle_left[i] = chargerSprite(chemin);

        sprintf(chemin, "images/sprites_hero/idle_right_%02d.bmp", i);
        spr_idle_right[i] = chargerSprite(chemin);

        sprintf(chemin, "images/sprites_hero/jump_left_%02d.bmp", i);
        spr_jump_left[i] = chargerSprite(chemin);

        sprintf(chemin, "images/sprites_hero/jump_right_%02d.bmp", i);
        spr_jump_right[i] = chargerSprite(chemin);
    }

    for (i = 0; i < 6; i++) {
        sprintf(chemin, "images/sprites_hero/walk_left_%02d.bmp", i);
        spr_walk_left[i] = chargerSprite(chemin);

        sprintf(chemin, "images/sprites_hero/walk_right_%02d.bmp", i);
        spr_walk_right[i] = chargerSprite(chemin);
    }
}

// ------------------------------------------------------------
//  dessinerTout — Fonction principale
// ------------------------------------------------------------
void dessinerTout(JeuEtat *jeu)
{
    anim_tick++;

    if (jeu->etat == ETAT_MENU)    { dessinerMenu();    return; }
    if (jeu->etat == ETAT_GAME_OVER) { dessinerGameOver(); return; }
    if (jeu->etat == ETAT_VICTOIRE)  { dessinerVictoire(); return; }

    dessinerFond();
    dessinerPlateformes(jeu);
    dessinerObjets(jeu);
    dessinerEnnemis(jeu);
    dessinerJoueur(jeu);
    dessinerHUD(jeu);
}

// ------------------------------------------------------------
//  dessinerFond
// ------------------------------------------------------------
void dessinerFond(void)
{
    effaceFenetre(20, 20, 50);
}

// ------------------------------------------------------------
//  dessinerPlateformes
// ------------------------------------------------------------
void dessinerPlateformes(JeuEtat *jeu)
{
    int i;
    for (i = 0; i < jeu->nb_plateformes; i++)
    {
        Plateforme *p = &jeu->plateformes[i];
        float x_ecran = p->x - jeu->camera_x;

        if (x_ecran + p->largeur < 0 || x_ecran > LARGEUR_FENETRE) continue;

        if (p->mortelle) couleurCourante(180, 30, 30);
        else             couleurCourante(100, 100, 110);

        rectangle(x_ecran, p->y, x_ecran + p->largeur, p->y + p->hauteur);
    }
}

// ------------------------------------------------------------
//  dessinerJoueur — Affichage avec sprites animés
//
//  États possibles :
//  - En l'air (au_sol == 0)  → animation jump
//  - vx != 0 et au sol       → animation walk
//  - immobile au sol         → animation idle
// ------------------------------------------------------------
void dessinerJoueur(JeuEtat *jeu)
{
    Joueur *j = &jeu->joueur;
    if (!j->vivant) return;

    // Clignotement si invulnérable
    if (j->invulnerable > 0 && (j->invulnerable % 6) < 3) return;

    float x_ecran = j->x - jeu->camera_x;
    float y_ecran = j->y;

    // --- Choisir le tableau de sprites et la frame ---
    DonneesImageRGB **sprites = NULL;
    int nb_frames = 1;
    int vitesse_anim = 5; // Ticks entre chaque frame

    if (!j->au_sol)
    {
        // En l'air → jump
        sprites      = (j->direction == DIR_DROITE) ? spr_jump_right : spr_jump_left;
        nb_frames    = 2;
        vitesse_anim = 10;
    }
    else if (j->vx != 0)
    {
        // Marche → walk (6 frames de 96x48)
        sprites      = (j->direction == DIR_DROITE) ? spr_walk_right : spr_walk_left;
        nb_frames    = 6;
        vitesse_anim = 5;
    }
    else
    {
        // Immobile → idle
        sprites      = (j->direction == DIR_DROITE) ? spr_idle_right : spr_idle_left;
        nb_frames    = 2;
        vitesse_anim = 20;
    }

    // Calcul de la frame courante
    int frame = (anim_tick / vitesse_anim) % nb_frames;

    // --- Affichage ---
    if (sprites && sprites[frame])
    {
        // On a un sprite → on l'affiche
        DonneesImageRGB *spr = sprites[frame];
        ecrisImage((int)x_ecran, (int)y_ecran,
                   spr->largeurImage, spr->hauteurImage,
                   spr->donneesRGB);
    }
    else
    {
        // Fallback : rectangle bleu si sprite manquant
        couleurCourante(50, 100, 220);
        rectangle(x_ecran, y_ecran, x_ecran + j->largeur, y_ecran + j->hauteur);
    }
}

// ------------------------------------------------------------
//  dessinerEnnemis — Rectangles rouges (sprites à venir)
// ------------------------------------------------------------
void dessinerEnnemis(JeuEtat *jeu)
{
    int i;
    for (i = 0; i < jeu->nb_ennemis; i++)
    {
        Ennemi *e = &jeu->ennemis[i];
        if (!e->vivant) continue;

        float x_ecran = e->x - jeu->camera_x;
        if (x_ecran + e->largeur < 0 || x_ecran > LARGEUR_FENETRE) continue;

        couleurCourante(160, 30, 30);
        rectangle(x_ecran, e->y, x_ecran + e->largeur, e->y + e->hauteur);
    }
}

// ------------------------------------------------------------
//  dessinerObjets — Pièces + zone de sortie
// ------------------------------------------------------------
void dessinerObjets(JeuEtat *jeu)
{
    int i;

    // Zone de sortie verte clignotante
    float sortie_x = 2700.0f - jeu->camera_x;
    if (sortie_x + 80 >= 0 && sortie_x <= LARGEUR_FENETRE)
    {
        int tick = (int)(jeu->timer * 60);
        if ((tick / 30) % 2 == 0) couleurCourante(50, 220, 80);
        else                      couleurCourante(30, 140, 50);
        rectangle(sortie_x, 100, sortie_x + 80, 200);
        couleurCourante(255, 255, 255);
        afficheChaine("SORTIE", 14, sortie_x + 10, 210);
    }

    // Pièces
    for (i = 0; i < jeu->nb_objets; i++)
    {
        Objet *o = &jeu->objets[i];
        if (o->collectee) continue;

        float x_ecran = o->x - jeu->camera_x;
        if (x_ecran + o->largeur < 0 || x_ecran > LARGEUR_FENETRE) continue;

        couleurCourante(255, 210, 0);
        rectangle(x_ecran, o->y, x_ecran + o->largeur, o->y + o->hauteur);
    }
}

// ------------------------------------------------------------
//  dessinerHUD
// ------------------------------------------------------------
void dessinerHUD(JeuEtat *jeu)
{
    char texte[64];

    couleurCourante(0, 0, 0);
    rectangle(0, HAUTEUR_FENETRE - 40, LARGEUR_FENETRE, HAUTEUR_FENETRE);

    couleurCourante(255, 255, 255);
    sprintf(texte, "NIVEAU %d", jeu->niveau_actuel);
    afficheChaine(texte, 18, 20, HAUTEUR_FENETRE - 30);

    sprintf(texte, "VIES: %d", jeu->joueur.vies);
    afficheChaine(texte, 18, 200, HAUTEUR_FENETRE - 30);

    sprintf(texte, "PIECES: %d", jeu->joueur.pieces);
    afficheChaine(texte, 18, 400, HAUTEUR_FENETRE - 30);

    sprintf(texte, "TEMPS: %d s", (int)jeu->timer);
    afficheChaine(texte, 18, 650, HAUTEUR_FENETRE - 30);
}

// ------------------------------------------------------------
//  Écrans menu / game over / victoire
// ------------------------------------------------------------
void dessinerMenu(void)
{
    effaceFenetre(10, 10, 30);
    couleurCourante(200, 160, 50);
    afficheChaine("MEDIEVAL FANTASY", 40, 380, 400);
    couleurCourante(255, 255, 255);
    afficheChaine("Appuie sur ENTREE pour jouer", 20, 440, 300);
    afficheChaine("Q pour quitter", 16, 560, 250);
}

void dessinerGameOver(void)
{
    effaceFenetre(10, 0, 0);
    couleurCourante(220, 50, 50);
    afficheChaine("GAME OVER", 50, 480, 400);
    couleurCourante(255, 255, 255);
    afficheChaine("Appuie sur ENTREE pour recommencer", 20, 400, 300);
}

void dessinerVictoire(void)
{
    effaceFenetre(0, 20, 10);
    couleurCourante(80, 220, 80);
    afficheChaine("VICTOIRE !", 50, 480, 400);
    couleurCourante(255, 255, 255);
    afficheChaine("Appuie sur ENTREE pour rejouer", 20, 420, 300);
}