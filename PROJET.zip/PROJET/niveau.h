/*
 * niveau.h - Déclarations du module niveau et caméra
 *
 * Ce module gère :
 *   - Le chargement des plateformes pour chaque niveau
 *   - Le scrolling horizontal (caméra)
 *   - Les précipices (zones mortelles)
 *
 * Membre 2 - Niveau & caméra
 */

#ifndef NIVEAU_H
#define NIVEAU_H

#include "jeu.h"

/* Largeur totale d'un niveau (plus grand que l'écran) */
#define LARGEUR_NIVEAU      4000.0f

/* Distance max du joueur avant que la caméra ne le suive */
#define SEUIL_CAMERA_DROITE 800.0f   /* Pixels depuis le bord gauche de la vue */
#define SEUIL_CAMERA_GAUCHE 300.0f   /* Pixels depuis le bord gauche de la vue */

/* Prototypes */
void initialiseNiveau(int numero);
void miseAJourCamera(void);

/* Renvoie la position X du début du niveau (dans le monde) */
float debutNiveau(void);

/* Renvoie la position X de la fin du niveau (porte de sortie) */
float finNiveau(void);

#endif /* NIVEAU_H */
