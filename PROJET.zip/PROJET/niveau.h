#ifndef NIVEAU_H
#define NIVEAU_H

#include "jeu.h"

//  niveau.h - Module niveau & caméra

// Charge le niveau 
void initialiserNiveau(JeuEtat *jeu);

// Met à jour la position de la caméra selon le joueur
void mettreAJourCamera(JeuEtat *jeu);

// Récupère la hitbox d'une plateforme (en ignorant les marges transparentes)
void getPlatformHitbox(Plateforme *p, float *px, float *py, float *pw, float *ph);

#endif
