#ifndef NIVEAU_H
#define NIVEAU_H

#include "jeu.h"

// ============================================================
//  niveau.h — Module niveau & caméra (Membre 2)
// ============================================================

// Charge le niveau (place les plateformes dans le tableau)
void initialiserNiveau(JeuEtat *jeu);

// Met à jour la position de la caméra selon le joueur
void mettreAJourCamera(JeuEtat *jeu);

#endif
