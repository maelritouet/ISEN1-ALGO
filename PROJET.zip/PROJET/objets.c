#include "objets.h"
#include "joueur.h"
#include "niveau.h"
#include "ennemi.h"
#include "jeu.h"

// ============================================================
//  objets.c — Module objets & game logic (Membre 4)
//
//  Ce module gère :
//  - Les pièces d'or à collecter dans le niveau
//  - Le bonus à 10 pièces (+1 vie)
//  - La condition de victoire (zone de sortie en fin de niveau)
//  - L'initialisation globale du jeu
//
//  À l'oral : "À chaque tick on teste si le joueur touche
//  une pièce non collectée — si oui on l'active et on
//  incrémente le compteur. On teste aussi si le joueur
//  atteint la zone de sortie pour déclencher la victoire."
// ============================================================

// ------------------------------------------------------------
//  Zone de sortie du niveau — position hardcodée en fin de niveau
//  Le joueur doit atteindre cette zone pour gagner.
// ------------------------------------------------------------
#define SORTIE_X      2700.0f
#define SORTIE_Y       100.0f
#define SORTIE_LARG     80.0f
#define SORTIE_HAUT    100.0f

// ------------------------------------------------------------
//  initialiserObjets — Place les pièces dans le niveau
// ------------------------------------------------------------
void initialiserObjets(JeuEtat *jeu)
{
    int n = 0;

    // Macro locale pour ajouter une pièce proprement
    #define PIECE(px, py) \
        jeu->objets[n].x        = (px); \
        jeu->objets[n].y        = (py); \
        jeu->objets[n].collectee = 0;   \
        jeu->objets[n].type     = 0;    \
        jeu->objets[n].largeur  = 20;   \
        jeu->objets[n].hauteur  = 20;   \
        n++;

    // --- Zone de départ ---
    PIECE(200.0f, 140.0f)
    PIECE(250.0f, 140.0f)
    PIECE(300.0f, 140.0f)

    // --- Sur la première plateforme haute ---
    PIECE(180.0f, 220.0f)
    PIECE(280.0f, 220.0f)

    // --- Au-dessus du précipice ---
    PIECE(720.0f, 260.0f)
    PIECE(780.0f, 260.0f)

    // --- Après le premier précipice ---
    PIECE(950.0f,  140.0f)
    PIECE(1050.0f, 140.0f)
    PIECE(1150.0f, 140.0f)

    // --- Sur les plateformes hautes ---
    PIECE(1000.0f, 240.0f)
    PIECE(1200.0f, 340.0f)

    // --- Zone du deuxième précipice ---
    PIECE(1320.0f, 300.0f)
    PIECE(1480.0f, 240.0f)

    // --- Zone finale ---
    PIECE(1700.0f, 140.0f)
    PIECE(1900.0f, 140.0f)
    PIECE(2100.0f, 140.0f)
    PIECE(1950.0f, 320.0f)
    PIECE(2400.0f, 140.0f)
    PIECE(2600.0f, 140.0f)

    #undef PIECE

    jeu->nb_objets = n;
}

// ------------------------------------------------------------
//  initialiserJeu — Remet le jeu à zéro complet
//  Appelée au démarrage et à chaque "recommencer"
// ------------------------------------------------------------
void initialiserJeu(JeuEtat *jeu)
{
    jeu->etat          = ETAT_MENU;
    jeu->niveau_actuel = 1;
    jeu->timer         = 0.0f;
    jeu->camera_x      = 0.0f;
    jeu->nb_objets     = 0;

    initialiserNiveau(jeu);
    initialiserJoueur(jeu);
    initialiserEnnemis(jeu);
    initialiserObjets(jeu);
}

// ------------------------------------------------------------
//  estEnContact — Test de collision AABB simple
//  Retourne 1 si les deux rectangles se chevauchent
// ------------------------------------------------------------
static int estEnContact(float ax, float ay, float aw, float ah,
                         float bx, float by, float bw, float bh)
{
    if (ax + aw <= bx) return 0;
    if (ax >= bx + bw) return 0;
    if (ay + ah <= by) return 0;
    if (ay >= by + bh) return 0;
    return 1;
}

// ------------------------------------------------------------
//  mettreAJourObjets — Appelée à chaque tick depuis main.c
//
//  1. Vérifie si le joueur collecte une pièce
//  2. Applique le bonus tous les PIECES_POUR_BONUS pièces
//  3. Vérifie si le joueur atteint la sortie
// ------------------------------------------------------------
void mettreAJourObjets(JeuEtat *jeu)
{
    Joueur *j = &jeu->joueur;
    int i;

    if (!j->vivant) return;

    // --- 1. Collecte des pièces ---
    for (i = 0; i < jeu->nb_objets; i++)
    {
        Objet *o = &jeu->objets[i];

        if (o->collectee) continue;

        if (estEnContact(j->x, j->y, j->largeur, j->hauteur,
                         o->x, o->y, o->largeur, o->hauteur))
        {
            o->collectee = 1;
            j->pieces++;

            // --- 2. Bonus tous les PIECES_POUR_BONUS pièces ---
            // On utilise le modulo : si pieces est un multiple
            // de PIECES_POUR_BONUS, on accorde +1 vie
            if (j->pieces % PIECES_POUR_BONUS == 0)
            {
                j->vies++;
            }
        }
    }

    // --- 3. Condition de victoire : atteindre la sortie ---
    if (estEnContact(j->x, j->y, j->largeur, j->hauteur,
                     SORTIE_X, SORTIE_Y, SORTIE_LARG, SORTIE_HAUT))
    {
        jeu->etat = ETAT_VICTOIRE;
    }
}