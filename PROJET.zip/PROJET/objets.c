/*
 * objets.c - Gestion des objets et logique de jeu
 *
 * Fonctionnalités implémentées :
 *   [OBLIGATOIRE] Pièces à collecter
 *   [OBLIGATOIRE] Bonus quand le joueur collecte N pièces (vie gagnée)
 *   [OBLIGATOIRE] Plusieurs types d'objets (pièce, powerup, clé)
 *   [BONUS]       Clé qui ouvre la porte de fin
 *   [BONUS]       Sauvegarde des 10 meilleurs temps (fichier scores.dat)
 *   [BONUS]       Transition de niveau automatique
 *
 * Membre 4 - Objets & game logic
 */

#include <stdio.h>
#include <string.h>   /* Pour memset() */
#include <math.h>     /* Pour fabsf() */
#include "jeu.h"
#include "objets.h"
#include "niveau.h"   /* Pour finNiveau() */
#include "joueur.h"   /* Pour initialiseJoueur() */
#include "ennemi.h"   /* Pour initialiseEnnemis() */

/* =========================================================
 *  Données de spawn des objets par niveau
 *
 *  Format : { x, y, collectee, type }
 * ========================================================= */

static Objet spawn_objets_niveau1[NB_PIECES] = {
    /* Pièces sur les plateformes */
    { 220.0f,  180.0f, 0, OBJET_PIECE   },
    { 260.0f,  180.0f, 0, OBJET_PIECE   },
    { 520.0f,  280.0f, 0, OBJET_PIECE   },
    { 560.0f,  280.0f, 0, OBJET_PIECE   },
    { 720.0f,  210.0f, 0, OBJET_PIECE   },
    { 1020.0f, 150.0f, 0, OBJET_PIECE   },
    { 1220.0f, 250.0f, 0, OBJET_PIECE   },
    { 1620.0f, 180.0f, 0, OBJET_PIECE   },
    { 1920.0f, 280.0f, 0, OBJET_PIECE   },
    { 2120.0f, 380.0f, 0, OBJET_PIECE   },
    { 2420.0f, 230.0f, 0, OBJET_PIECE   },
    { 2620.0f, 330.0f, 0, OBJET_PIECE   },
    { 2820.0f, 210.0f, 0, OBJET_PIECE   },
    { 3020.0f, 310.0f, 0, OBJET_PIECE   },
    /* Power-ups (récupère une vie) */
    { 1400.0f, 330.0f, 0, OBJET_POWERUP },
    { 2800.0f, 40.0f,  0, OBJET_POWERUP },
    /* Quelques pièces au sol */
    { 400.0f,  40.0f,  0, OBJET_PIECE   },
    { 1700.0f, 40.0f,  0, OBJET_PIECE   },
    { 2300.0f, 40.0f,  0, OBJET_PIECE   },
    /* Clé de la porte de fin */
    { 3000.0f, 310.0f, 0, OBJET_CLE     },
};

static Objet spawn_objets_niveau2[NB_PIECES] = {
    { 120.0f,  230.0f, 0, OBJET_PIECE   },
    { 320.0f,  380.0f, 0, OBJET_PIECE   },
    { 560.0f,  280.0f, 0, OBJET_PIECE   },
    { 770.0f,  330.0f, 0, OBJET_PIECE   },
    { 970.0f,  210.0f, 0, OBJET_PIECE   },
    { 1120.0f, 380.0f, 0, OBJET_PIECE   },
    { 1320.0f, 230.0f, 0, OBJET_PIECE   },
    { 1520.0f, 330.0f, 0, OBJET_PIECE   },
    { 1820.0f, 180.0f, 0, OBJET_PIECE   },
    { 2020.0f, 310.0f, 0, OBJET_PIECE   },
    { 2220.0f, 410.0f, 0, OBJET_PIECE   },
    { 2520.0f, 230.0f, 0, OBJET_PIECE   },
    { 2720.0f, 40.0f,  0, OBJET_PIECE   },
    { 3120.0f, 40.0f,  0, OBJET_PIECE   },
    { 700.0f,  330.0f, 0, OBJET_POWERUP },
    { 2000.0f, 310.0f, 0, OBJET_POWERUP },
    { 400.0f,  40.0f,  0, OBJET_PIECE   },
    { 1400.0f, 40.0f,  0, OBJET_PIECE   },
    { 2400.0f, 40.0f,  0, OBJET_PIECE   },
    { 3000.0f, 40.0f,  0, OBJET_CLE     },
};

static Objet spawn_objets_niveau3[NB_PIECES] = {
    { 120.0f,  230.0f, 0, OBJET_PIECE   },
    { 270.0f,  380.0f, 0, OBJET_PIECE   },
    { 570.0f,  280.0f, 0, OBJET_PIECE   },
    { 720.0f,  410.0f, 0, OBJET_PIECE   },
    { 970.0f,  230.0f, 0, OBJET_PIECE   },
    { 1120.0f, 350.0f, 0, OBJET_PIECE   },
    { 1320.0f, 210.0f, 0, OBJET_PIECE   },
    { 1520.0f, 330.0f, 0, OBJET_PIECE   },
    { 1770.0f, 230.0f, 0, OBJET_PIECE   },
    { 1970.0f, 380.0f, 0, OBJET_PIECE   },
    { 2420.0f, 40.0f,  0, OBJET_PIECE   },
    { 2620.0f, 40.0f,  0, OBJET_PIECE   },
    { 2800.0f, 40.0f,  0, OBJET_PIECE   },
    { 3150.0f, 40.0f,  0, OBJET_PIECE   },
    { 500.0f,  280.0f, 0, OBJET_POWERUP },
    { 2600.0f, 40.0f,  0, OBJET_POWERUP },
    { 200.0f,  40.0f,  0, OBJET_PIECE   },
    { 1000.0f, 40.0f,  0, OBJET_PIECE   },
    { 2100.0f, 40.0f,  0, OBJET_PIECE   },
    { 3050.0f, 40.0f,  0, OBJET_CLE     },
};

/* =========================================================
 *  Tableau des meilleurs scores (bonus)
 *  Chaque entrée = temps de complétion en secondes
 *  On garde les 10 meilleurs (= les plus bas)
 * ========================================================= */
#define NB_SCORES_MAX   10
#define FICHIER_SCORES  "scores.dat"

static float meilleurs_scores[NB_SCORES_MAX];

/* =========================================================
 *  initialiseObjets()
 * ========================================================= */
void initialiseObjets(void)
{
    int i;
    Objet *source;

    switch (jeu.niveau_actuel)
    {
        case 1: source = spawn_objets_niveau1; break;
        case 2: source = spawn_objets_niveau2; break;
        case 3: source = spawn_objets_niveau3; break;
        default: source = spawn_objets_niveau1; break;
    }

    for (i = 0; i < NB_PIECES; i++)
    {
        jeu.objets[i] = source[i];
    }
}

/* =========================================================
 *  distanceObjetJoueur()
 *
 *  Distance entre le centre de l'objet et le centre du joueur.
 *  On utilise la distance de Chebyshev (max des deux deltas)
 *  pour simplifier : pas de racine carrée nécessaire.
 * ========================================================= */
static float distanceObjetJoueur(int i)
{
    Joueur *j = &jeu.joueur;
    Objet  *o = &jeu.objets[i];

    /* Centre du joueur */
    float jx = j->x + TAILLE_JOUEUR_L / 2.0f;
    float jy = j->y + TAILLE_JOUEUR_H / 2.0f;

    /* Delta */
    float dx = fabsf(o->x - jx);
    float dy = fabsf(o->y - jy);

    /* Distance de Chebyshev : simple et sans sqrt */
    return (dx > dy) ? dx : dy;
}

/* =========================================================
 *  verifiePorteFinNiveau()
 *
 *  Vérifie si le joueur a atteint la porte de fin.
 *  Pour l'ouvrir, il faut avoir la clé (a_cle == 1).
 *  Si oui : passage au niveau suivant ou victoire.
 * ========================================================= */
static void verifiePorteFinNiveau(void)
{
    Joueur *j    = &jeu.joueur;
    float x_porte = finNiveau();

    /* Le joueur doit avoir la clé ET atteindre la porte */
    if (!j->a_cle) return;

    if (j->x + TAILLE_JOUEUR_L > x_porte)
    {
        /* Niveau terminé ! */
        /* Calculer le temps mis */
        float temps_ecoule = (float)TIMER_NIVEAU - jeu.timer;
        printf("[Objets] Niveau %d termine en %.1f secondes\n",
               jeu.niveau_actuel, temps_ecoule);

        /* Ajouter des points bonus selon le temps restant */
        jeu.score += (int)(jeu.timer * 10);

        /* Sauvegarder le score */
        sauvegardeScores();

        if (jeu.niveau_actuel < NB_NIVEAUX)
        {
            /* Passer au niveau suivant */
            jeu.niveau_actuel++;
            initialiseNiveau(jeu.niveau_actuel);
            /* On garde les vies et les pièces du joueur */
            j->x           = 100.0f;
            j->y           = 200.0f;
            j->vx          = 0.0f;
            j->vy          = 0.0f;
            j->invulnerable = 0;
            j->vivant      = 1;
            j->a_cle       = 0;
            initialiseEnnemis();
            initialiseObjets();
        }
        else
        {
            /* Dernier niveau terminé → victoire ! */
            jeu.etat = ETAT_VICTOIRE;
        }
    }
}

/* =========================================================
 *  miseAJourObjets()
 *
 *  Appelée chaque frame.
 *  Vérifie si le joueur est proche d'un objet non collecté.
 *  Si oui : applique l'effet et marque l'objet comme collecté.
 * ========================================================= */
void miseAJourObjets(void)
{
    int i;
    Joueur *j = &jeu.joueur;

    for (i = 0; i < NB_PIECES; i++)
    {
        Objet *o = &jeu.objets[i];

        if (o->collectee) continue; /* Déjà ramassé */

        /* Vérifier la proximité */
        if (distanceObjetJoueur(i) > RAYON_COLLECTE) continue;

        /* --- L'objet est collecté ! --- */
        o->collectee = 1;

        switch (o->type)
        {
            case OBJET_PIECE:
                j->pieces++;
                jeu.score += 10;
                printf("[Objets] Piece ramassee ! Total: %d\n", j->pieces);

                /* Toutes les PIECES_PAR_VIE pièces → vie supplémentaire */
                if (j->pieces % PIECES_PAR_VIE == 0)
                {
                    j->vies++;
                    printf("[Objets] VIE BONUS ! Vies: %d\n", j->vies);
                }
                break;

            case OBJET_POWERUP:
                /* Restaure une vie */
                j->vies++;
                jeu.score += 50;
                printf("[Objets] Power-up ! Vies: %d\n", j->vies);
                break;

            case OBJET_CLE:
                j->a_cle = 1;
                jeu.score += 200;
                printf("[Objets] CLE ramassee ! La porte est debloquee.\n");
                break;
        }
    }

    /* Vérifier si le joueur atteint la porte de fin */
    verifiePorteFinNiveau();
}

/* =========================================================
 *  nbPiecesRestantes()
 * ========================================================= */
int nbPiecesRestantes(void)
{
    int i, count = 0;
    for (i = 0; i < NB_PIECES; i++)
    {
        if (!jeu.objets[i].collectee && jeu.objets[i].type == OBJET_PIECE)
            count++;
    }
    return count;
}

/* =========================================================
 *  sauvegardeScores()
 *
 *  [BONUS] Sauvegarde les 10 meilleurs temps dans un fichier.
 *  Le temps est stocké en secondes (float).
 * ========================================================= */
void sauvegardeScores(void)
{
    int i, j_idx;
    float temps = (float)TIMER_NIVEAU - jeu.timer;
    FILE *f;

    /* Charger d'abord les scores existants */
    chargeScores();

    /* Insérer le nouveau temps dans le tableau trié (ordre croissant = meilleur d'abord) */
    for (i = 0; i < NB_SCORES_MAX; i++)
    {
        if (temps < meilleurs_scores[i] || meilleurs_scores[i] == 0.0f)
        {
            /* Décaler les scores suivants */
            for (j_idx = NB_SCORES_MAX - 1; j_idx > i; j_idx--)
            {
                meilleurs_scores[j_idx] = meilleurs_scores[j_idx - 1];
            }
            meilleurs_scores[i] = temps;
            break;
        }
    }

    /* Écrire dans le fichier */
    f = fopen(FICHIER_SCORES, "wb");
    if (f != NULL)
    {
        fwrite(meilleurs_scores, sizeof(float), NB_SCORES_MAX, f);
        fclose(f);
        printf("[Scores] Scores sauvegardes.\n");
    }
    else
    {
        printf("[Scores] Impossible d'ecrire le fichier scores.\n");
    }
}

/* =========================================================
 *  chargeScores()
 *
 *  [BONUS] Charge les scores depuis le fichier.
 * ========================================================= */
void chargeScores(void)
{
    FILE *f = fopen(FICHIER_SCORES, "rb");

    /* Initialiser à 0 (0 = emplacement vide) */
    int i;
    for (i = 0; i < NB_SCORES_MAX; i++)
        meilleurs_scores[i] = 0.0f;

    if (f != NULL)
    {
        fread(meilleurs_scores, sizeof(float), NB_SCORES_MAX, f);
        fclose(f);
    }
}
