#include "objets.h"
#include "joueur.h"
#include "niveau.h"
#include "jeu.h"

// ============================================================
//  objets.c — Module objets & game logic (Membre 4)
//
//  Ce module gère :
//  - Les pièces d'or à collecter dans le niveau
//  - Le bonus à 10 pièces (+1 vie)
//  - La condition de victoire (zone de sortie en fin de niveau)
//  - L'initialisation globale du jeu
//
//  À l'oral : "À chaque tick on teste si le joueur touche
//  une pièce non collectée — si oui on l'active et on
//  incrémente le compteur. On teste aussi si le joueur
//  atteint la zone de sortie pour déclencher la victoire."
// ============================================================

// ------------------------------------------------------------
//  initialiserObjets
//
//  IMPORTANT : avec le système blueprint, les pièces et la
//  zone de sortie sont déjà placées par chargerNiveauDepuisBlueprint()
//  dans niveau.c. Cette fonction est conservée pour compatibilité
//  mais ne fait rien de plus.
// ------------------------------------------------------------
void initialiserObjets(JeuEtat *jeu)
{
    (void)jeu; /* Le blueprint a déjà tout placé */
}

// ------------------------------------------------------------
//  initialiserJeu — Remet le jeu à zéro complet
//  Appelée au démarrage et à chaque "recommencer"
// ------------------------------------------------------------
void initialiserJeu(JeuEtat *jeu)
{
    jeu->timer         = 0.0f;
    jeu->camera_x      = 0.0f;
    jeu->sortie_x      = 0.0f;
    jeu->sortie_y      = 0.0f;
    jeu->nb_objets     = 0;

    /* initialiserNiveau() appelle chargerNiveauDepuisBlueprint()
     * qui place plateformes, ennemis, pièces ET la sortie.
     * On initialise le joueur après pour respecter le spawn 'S'. */
    initialiserNiveau(jeu);
    initialiserJoueur(jeu);
}

// ------------------------------------------------------------
//  estEnContact — Test de collision AABB simple
//  Retourne 1 si les deux rectangles se chevauchent
// ------------------------------------------------------------
static int estEnContact(float ax, float ay, float aw, float ah,
                         float bx, float by, float bw, float bh)
{
    if (ax + aw <= bx) return 0;
    if (ax >= bx + bw) return 0;
    if (ay + ah <= by) return 0;
    if (ay >= by + bh) return 0;
    return 1;
}

// ------------------------------------------------------------
//  mettreAJourObjets — Appelée à chaque tick depuis main.c
// ------------------------------------------------------------
void mettreAJourObjets(JeuEtat *jeu)
{
    Joueur *j = &jeu->joueur;
    int i;

    if (!j->vivant) return;

    // --- 1. Collecte des pièces ---
    for (i = 0; i < jeu->nb_objets; i++)
    {
        Objet *o = &jeu->objets[i];
        if (o->collectee) continue;

        if (estEnContact(j->x, j->y, j->largeur, j->hauteur,
                         o->x, o->y, o->largeur, o->hauteur))
        {
            o->collectee = 1;
            j->pieces++;
            if (j->pieces % PIECES_POUR_BONUS == 0)
                j->vies++;
        }
    }

    // --- 2. Condition de victoire : atteindre la sortie ---
    if (jeu->sortie_x > 0.0f)
    {
        if (estEnContact(j->x, j->y, j->largeur, j->hauteur,
                         jeu->sortie_x, jeu->sortie_y, TILE_SIZE, TILE_SIZE * 2))
        {
            jeu->timer_complet = jeu->timer;
            jeu->etat = ETAT_VICTOIRE;
        }
    }
}