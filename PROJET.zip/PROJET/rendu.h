#ifndef RENDU_H
#define RENDU_H

#include "jeu.h"

//  rendu.h - affichage
//  Ce module s'occupe uniquement de dessiner 
//  -> lit les données dans JeuEtat mais n'en modifie aucune

typedef struct {
    int largeur;
    int hauteur;
    int *donneesARVB;
} Sprite;

void chargerSprites(void);
void libererSprites(void);

void dessinerTout(JeuEtat *jeu);

void dessinerFond(JeuEtat *jeu);
void dessinerFondu(JeuEtat *jeu);
void dessinerPlateformes(JeuEtat *jeu);
void dessinerJoueur(JeuEtat *jeu);
void dessinerEnnemis(JeuEtat *jeu);
void dessinerObjets(JeuEtat *jeu);
void dessinerHUD(JeuEtat *jeu);

void dessinerFondVictoire(void);
void dessinerFondMort(void);
void dessinerFondMenu(void);
#endif