/*
 * rendu.h - Déclarations du module rendu graphique
 *
 * Ce module gère TOUT l'affichage du jeu :
 *   - Les différents écrans (menu, jeu, game over, victoire)
 *   - Le HUD (vies, timer, pièces, niveau)
 *   - Les sprites (joueur, ennemis, objets, plateformes)
 *   - Le chargement des images BMP
 *
 * Membre 5 - Rendu graphique & HUD
 */

#ifndef RENDU_H
#define RENDU_H

#include "jeu.h"

/* Prototypes publics */

/* Charge toutes les images BMP au démarrage */
void initialiseRendu(void);

/* Libère la mémoire des images en fin de programme */
void libereRendu(void);

/* Dessine l'écran de menu principal */
void dessineMenu(void);

/* Dessine la partie en cours (monde + HUD) */
void dessineJeu(void);

/* Dessine l'écran game over */
void dessineGameOver(void);

/* Dessine l'écran de victoire */
void dessineVictoire(void);

#endif /* RENDU_H */
