#ifndef RENDU_H
#define RENDU_H

#include "jeu.h"

// ============================================================
//  rendu.h — Module d'affichage (Membre 5)
//
//  Ce module s'occupe UNIQUEMENT de dessiner.
//  Il lit les données dans JeuEtat mais n'en modifie aucune.
// ============================================================

// Charge tous les sprites BMP en mémoire (à appeler une seule fois au démarrage)
void chargerSprites(void);

// Fonction principale : dessine tout l'écran à partir de l'état du jeu
void dessinerTout(JeuEtat *jeu);

// Sous-fonctions internes (appelées par dessinerTout)
void dessinerFond(void);
void dessinerPlateformes(JeuEtat *jeu);
void dessinerJoueur(JeuEtat *jeu);
void dessinerEnnemis(JeuEtat *jeu);
void dessinerObjets(JeuEtat *jeu);
void dessinerHUD(JeuEtat *jeu);
void dessinerMenu(void);
void dessinerGameOver(void);
void dessinerVictoire(void);

#endif