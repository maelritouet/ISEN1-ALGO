#ifndef RENDU_H
#define RENDU_H

#include "jeu.h"

// ============================================================
//  rendu.h — Module d'affichage (Membre 5)
//
//  Ce module s'occupe UNIQUEMENT de dessiner.
//  Il lit les données dans JeuEtat mais n'en modifie aucune.
// ============================================================

// Structure optimisée pour les sprites avec transparence (ARVB)
typedef struct {
    int largeur;
    int hauteur;
    int *donneesARVB;
} Sprite;

// Charge tous les sprites BMP en mémoire (à appeler une seule fois au démarrage)
void chargerSprites(void);

// Libère la mémoire allouée pour les sprites (à appeler en quittant)
void libererSprites(void);

// Fonction principale : dessine tout l'écran à partir de l'état du jeu
void dessinerTout(JeuEtat *jeu);

// Sous-fonctions internes (appelées par dessinerTout)
void dessinerFond(JeuEtat *jeu);
void dessinerPlateformes(JeuEtat *jeu);
void dessinerJoueur(JeuEtat *jeu);
void dessinerEnnemis(JeuEtat *jeu);
void dessinerObjets(JeuEtat *jeu);
void dessinerHUD(JeuEtat *jeu);
void dessinerMenu(void);
void dessinerAide(void);
void dessinerSelectionNiveau(JeuEtat *jeu);
void dessinerGameOver(void);
void dessinerVictoire(JeuEtat *jeu);

#endif